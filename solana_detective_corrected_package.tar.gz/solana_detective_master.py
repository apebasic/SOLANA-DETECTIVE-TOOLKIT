#!/usr/bin/env python3
"""
SOLANA DETECTIVE MASTER TOOLKIT
===============================
Lean, portable script for all Solana blockchain analysis queries.
Designed to work across multiple AI conversations with zero context dependency.

USAGE EXAMPLES:
- "Net SOL for wallet X on token Y" → calculate_wallet_net_sol(wallet, token)
- "Find cross-token wallets for tokens A,B,C" → find_cross_token_wallets([A,B,C])
- "Check if wallet X is a bot" → detect_bot_behavior(wallet)
- "Wallets that bought token X between time Y and Z" → get_timeframe_buyers(token, start, end)

CRITICAL KNOWLEDGE EMBEDDED:
- Use 'volumeSol' field for SOL amounts, NOT 'volume' field
- Bot detection: >10 transactions per token = likely bot
- API rate limiting and error handling built-in
"""

import requests
import json
import time
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SolanaDetective:
    """
    Master class for all Solana blockchain analysis.
    Self-contained with all necessary knowledge and methods.
    """
    
    def __init__(self, api_key: str = None):
        """Initialize with API configuration."""
        self.api_key = api_key or self._load_api_key()
        self.base_url = "https://data.solanatracker.io"
        self.headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 0.1  # 100ms between requests
    
    def _load_api_key(self) -> str:
        """Load API key from config file."""
        try:
            with open('/home/ubuntu/config.json', 'r') as f:
                config = json.load(f)
                return config.get('api_key', '')
        except:
            return ""
    
    def _rate_limit(self):
        """Enforce rate limiting between API calls."""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        self.last_request_time = time.time()
    
    def _make_request(self, endpoint: str, params: Dict = None) -> Dict:
        """
        Make API request with error handling and rate limiting.
        
        Args:
            endpoint: API endpoint (e.g., '/tokens/info')
            params: Query parameters
            
        Returns:
            JSON response data
        """
        self._rate_limit()
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {}
    
    # ==========================================
    # CORE API ENDPOINT WRAPPERS
    # ==========================================
    
    def get_token_info(self, token_address: str) -> Dict:
        """Get basic token information and pools."""
        return self._make_request(f"/tokens/{token_address}")
    
    def get_wallet_trades_for_token(self, token_address: str, wallet_address: str) -> List[Dict]:
        """Get all trades for a specific wallet on a specific token."""
        data = self._make_request(f"/trades/{token_address}/by-wallet/{wallet_address}")
        return data.get('trades', [])
    
    def get_pool_trades(self, token_address: str, pool_address: str, 
                       time_from: int = None, time_to: int = None, limit: int = 250) -> List[Dict]:
        """Get trades from a specific pool with optional time filtering."""
        params = {'limit': limit}
        if time_from:
            params['time_from'] = time_from
        if time_to:
            params['time_to'] = time_to
            
        data = self._make_request(f"/trades/{token_address}/{pool_address}", params)
        return data.get('trades', [])
    
    def get_first_buyers(self, token_address: str, limit: int = 100) -> List[Dict]:
        """Get first buyers of a token."""
        data = self._make_request(f"/first-buyers/{token_address}", {'limit': limit})
        # Handle both list and dict responses
        if isinstance(data, list):
            return data
        return data.get('buyers', []) if isinstance(data, dict) else []
    
    # ==========================================
    # HIGH-LEVEL ANALYSIS FUNCTIONS
    # ==========================================
    
    def calculate_wallet_net_sol(self, wallet_address: str, token_address: str) -> Dict:
        """
        Calculate net SOL volume for wallet trading a token.
        
        CRITICAL: Uses 'volumeSol' field from API response!
        
        Returns:
            {
                'buy_count': int,
                'sell_count': int,
                'buy_volume_sol': float,
                'sell_volume_sol': float,
                'net_sol': float,
                'transactions': List[Dict]
            }
        """
        trades = self.get_wallet_trades_for_token(token_address, wallet_address)
        
        buy_count = 0
        sell_count = 0
        buy_volume_sol = 0.0
        sell_volume_sol = 0.0
        
        for trade in trades:
            if trade.get('type') == 'buy':
                buy_count += 1
                buy_volume_sol += float(trade.get('volumeSol', 0))
            elif trade.get('type') == 'sell':
                sell_count += 1
                sell_volume_sol += float(trade.get('volumeSol', 0))
        
        return {
            'wallet': wallet_address,
            'token': token_address,
            'buy_count': buy_count,
            'sell_count': sell_count,
            'buy_volume_sol': buy_volume_sol,
            'sell_volume_sol': sell_volume_sol,
            'net_sol': buy_volume_sol - sell_volume_sol,
            'total_transactions': buy_count + sell_count,
            'transactions': trades
        }
    
    def detect_bot_behavior(self, wallet_address: str, token_address: str) -> Dict:
        """
        Detect if wallet shows bot-like behavior for a specific token.
        
        Bot indicators:
        - High transaction count (>10 per token)
        - High frequency trading
        - Consistent patterns
        
        Returns:
            {
                'is_likely_bot': bool,
                'confidence': float,
                'reasons': List[str],
                'transaction_count': int
            }
        """
        analysis = self.calculate_wallet_net_sol(wallet_address, token_address)
        
        transaction_count = analysis['total_transactions']
        reasons = []
        confidence = 0.0
        
        # High transaction count indicator
        if transaction_count > 50:
            reasons.append(f"Very high transaction count: {transaction_count}")
            confidence += 0.8
        elif transaction_count > 20:
            reasons.append(f"High transaction count: {transaction_count}")
            confidence += 0.6
        elif transaction_count > 10:
            reasons.append(f"Moderate transaction count: {transaction_count}")
            confidence += 0.3
        
        # Perfect buy/sell ratio indicator
        buy_count = analysis['buy_count']
        sell_count = analysis['sell_count']
        if buy_count > 0 and sell_count > 0:
            ratio = abs(buy_count - sell_count) / max(buy_count, sell_count)
            if ratio < 0.1 and transaction_count > 10:
                reasons.append("Near-perfect buy/sell ratio")
                confidence += 0.4
        
        # High volume indicator
        total_volume = analysis['buy_volume_sol'] + analysis['sell_volume_sol']
        if total_volume > 1000:
            reasons.append(f"Very high trading volume: {total_volume:.2f} SOL")
            confidence += 0.3
        
        is_likely_bot = confidence > 0.5
        
        return {
            'wallet': wallet_address,
            'token': token_address,
            'is_likely_bot': is_likely_bot,
            'confidence': min(confidence, 1.0),
            'reasons': reasons,
            'transaction_count': transaction_count,
            'analysis': analysis
        }
    
    def find_cross_token_wallets(self, token_addresses: List[str], min_tokens: int = 2) -> Dict:
        """
        Find wallets that have traded multiple tokens from the list.
        
        Args:
            token_addresses: List of token contract addresses
            min_tokens: Minimum number of tokens a wallet must have traded
            
        Returns:
            {
                'cross_token_wallets': List[Dict],
                'summary': Dict
            }
        """
        wallet_token_map = {}
        
        for token in token_addresses:
            logger.info(f"Analyzing token: {token}")
            
            # Get first buyers for this token
            buyers = self.get_first_buyers(token, limit=100)
            
            for buyer in buyers:
                wallet = buyer.get('wallet', '')
                if wallet:
                    if wallet not in wallet_token_map:
                        wallet_token_map[wallet] = []
                    wallet_token_map[wallet].append({
                        'token': token,
                        'first_buy_time': buyer.get('first_buy_time'),
                        'volume': buyer.get('volume', 0)
                    })
        
        # Filter wallets that traded minimum number of tokens
        cross_token_wallets = []
        for wallet, tokens in wallet_token_map.items():
            if len(tokens) >= min_tokens:
                cross_token_wallets.append({
                    'wallet': wallet,
                    'token_count': len(tokens),
                    'tokens': tokens,
                    'total_volume': sum(t.get('volume', 0) for t in tokens)
                })
        
        # Sort by token count and volume
        cross_token_wallets.sort(key=lambda x: (x['token_count'], x['total_volume']), reverse=True)
        
        return {
            'cross_token_wallets': cross_token_wallets,
            'summary': {
                'total_wallets_analyzed': len(wallet_token_map),
                'cross_token_wallets_found': len(cross_token_wallets),
                'tokens_analyzed': len(token_addresses)
            }
        }
    
    def get_timeframe_buyers(self, token_address: str, start_time: int, end_time: int) -> Dict:
        """
        Get all wallets that bought a token within a specific timeframe.
        
        Args:
            token_address: Token contract address
            start_time: Unix timestamp (start of timeframe)
            end_time: Unix timestamp (end of timeframe)
            
        Returns:
            {
                'buyers': List[str],  # wallet addresses
                'timeframe': Dict,
                'summary': Dict
            }
        """
        # Get token info to find pools
        token_info = self.get_token_info(token_address)
        pools = token_info.get('pools', [])
        
        if not pools:
            return {
                'buyers': [],
                'timeframe': {'start': start_time, 'end': end_time},
                'summary': {'error': 'No pools found for token'}
            }
        
        # Use the most liquid pool
        main_pool = max(pools, key=lambda p: float(p.get('liquidity', {}).get('usd', 0)))
        pool_address = main_pool.get('poolId', '')
        
        if not pool_address:
            return {
                'buyers': [],
                'timeframe': {'start': start_time, 'end': end_time},
                'summary': {'error': 'No valid pool address found'}
            }
        
        # Get trades in timeframe
        trades = self.get_pool_trades(token_address, pool_address, start_time, end_time)
        
        # Extract unique buyer wallets
        buyers = set()
        for trade in trades:
            if trade.get('type') == 'buy':
                wallet = trade.get('wallet', '')
                if wallet:
                    buyers.add(wallet)
        
        return {
            'buyers': list(buyers),
            'timeframe': {
                'start': start_time,
                'end': end_time,
                'start_readable': datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S UTC'),
                'end_readable': datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S UTC')
            },
            'summary': {
                'unique_buyers': len(buyers),
                'total_trades_analyzed': len(trades),
                'pool_used': pool_address,
                'pool_liquidity_usd': main_pool.get('liquidity', {}).get('usd', 0)
            }
        }
    
    # ==========================================
    # NATURAL LANGUAGE QUERY INTERFACE
    # ==========================================
    
    def process_query(self, query: str, **kwargs) -> Dict:
        """
        Process natural language queries and route to appropriate functions.
        
        Examples:
        - "net sol wallet ABC token XYZ"
        - "cross token wallets ABC XYZ DEF"
        - "bot check wallet ABC token XYZ"
        - "timeframe buyers token ABC start 1234567890 end 1234567999"
        """
        query_lower = query.lower()
        
        if "net sol" in query_lower:
            wallet = kwargs.get('wallet', '')
            token = kwargs.get('token', '')
            if wallet and token:
                return self.calculate_wallet_net_sol(wallet, token)
        
        elif "cross token" in query_lower:
            tokens = kwargs.get('tokens', [])
            min_tokens = kwargs.get('min_tokens', 2)
            if tokens:
                return self.find_cross_token_wallets(tokens, min_tokens)
        
        elif "bot check" in query_lower:
            wallet = kwargs.get('wallet', '')
            token = kwargs.get('token', '')
            if wallet and token:
                return self.detect_bot_behavior(wallet, token)
        
        elif "timeframe buyers" in query_lower:
            token = kwargs.get('token', '')
            start_time = kwargs.get('start_time', 0)
            end_time = kwargs.get('end_time', 0)
            if token and start_time and end_time:
                return self.get_timeframe_buyers(token, start_time, end_time)
        
        return {'error': 'Query not recognized', 'query': query}

# ==========================================
# UTILITY FUNCTIONS
# ==========================================

def est_to_unix_timestamp(year: int, month: int, day: int, hour: int, minute: int = 0) -> int:
    """Convert EST time to Unix timestamp."""
    from datetime import datetime, timezone, timedelta
    est = timezone(timedelta(hours=-5))
    dt = datetime(year, month, day, hour, minute, tzinfo=est)
    return int(dt.timestamp())

def utc_to_unix_timestamp(year: int, month: int, day: int, hour: int, minute: int = 0) -> int:
    """Convert UTC time to Unix timestamp."""
    from datetime import datetime, timezone
    dt = datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
    return int(dt.timestamp())

# ==========================================
# EXAMPLE USAGE
# ==========================================

if __name__ == "__main__":
    # Initialize detective
    detective = SolanaDetective()
    
    # Example 1: Calculate net SOL for a wallet on a token
    result = detective.calculate_wallet_net_sol(
        "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D",
        "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    )
    print("Net SOL Analysis:", json.dumps(result, indent=2))
    
    # Example 2: Check if wallet is a bot
    bot_check = detective.detect_bot_behavior(
        "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D",
        "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    )
    print("Bot Detection:", json.dumps(bot_check, indent=2))
    
    # Example 3: Find cross-token wallets
    tokens = [
        "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",  # PFP
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",  # GIRLIES
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk"   # SYN
    ]
    cross_analysis = detective.find_cross_token_wallets(tokens)
    print("Cross-token Analysis:", json.dumps(cross_analysis, indent=2))

