#!/usr/bin/env python3
"""
KOL Alt Wallet Detection Tool
Analyzes transaction patterns to identify potential alt/backdoor wallets
"""

import requests
import json
from datetime import datetime
from collections import defaultdict, Counter
import time

class KOLAltDetector:
    def __init__(self, api_key):
        self.api_key = api_key
        self.headers = {'x-api-key': api_key, 'accept': 'application/json'}
        self.base_url = 'https://data.solanatracker.io'
        
    def get_wallet_trades(self, wallet_address):
        """Get wallet trades to find when they first bought each token"""
        url = f'{self.base_url}/wallet/{wallet_address}/trades'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                data = response.json()
                return data.get('trades', [])
            else:
                print(f"❌ Error getting wallet trades: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting wallet trades: {e}")
            return []
    
    def get_first_buyers(self, token_address):
        """Get first buyers for a token"""
        url = f'{self.base_url}/first-buyers/{token_address}'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Error getting first buyers for {token_address}: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting first buyers: {e}")
            return []
    
    def find_kol_first_buy_time(self, wallet_trades, token_address):
        """Find when the KOL first bought a specific token"""
        first_buy_time = None
        
        for trade in wallet_trades:
            # Check if this trade involves buying the target token
            # KOL buys token when 'to' address is the token address
            to_addr = trade.get('to', {}).get('address')
            from_addr = trade.get('from', {}).get('address')
            
            if to_addr == token_address:  # KOL is buying this token
                trade_time = trade.get('time')
                if trade_time and (first_buy_time is None or trade_time < first_buy_time):
                    first_buy_time = trade_time
        
        return first_buy_time
    
    def analyze_token(self, kol_wallet, token_address, token_name="Unknown"):
        """Analyze a single token for early buyers before KOL"""
        print(f"\n🔍 Analyzing token: {token_name} ({token_address})")
        
        # Get KOL's trades
        print("  📊 Getting KOL's transaction history...")
        kol_trades = self.get_wallet_trades(kol_wallet)
        
        if not kol_trades:
            print("  ❌ Could not get KOL trades")
            return []
        
        # Find KOL's first buy time for this token
        kol_first_buy = self.find_kol_first_buy_time(kol_trades, token_address)
        
        if not kol_first_buy:
            print("  ❌ KOL never bought this token")
            return []
        
        kol_first_buy_date = datetime.fromtimestamp(kol_first_buy / 1000)
        print(f"  ✅ KOL first bought on: {kol_first_buy_date}")
        
        # Get first buyers
        print("  📊 Getting first buyers...")
        first_buyers = self.get_first_buyers(token_address)
        
        if not first_buyers:
            print("  ❌ Could not get first buyers")
            return []
        
        print(f"  ✅ Found {len(first_buyers)} first buyers")
        
        # Filter buyers who bought before KOL
        early_buyers = []
        for buyer in first_buyers:
            buyer_time = buyer.get('first_buy_time')
            if buyer_time and buyer_time < kol_first_buy:
                buyer_date = datetime.fromtimestamp(buyer_time / 1000)
                time_advantage = (kol_first_buy - buyer_time) / 1000 / 60  # minutes
                
                early_buyers.append({
                    'wallet': buyer['wallet'],
                    'first_buy_time': buyer_time,
                    'first_buy_date': buyer_date,
                    'time_advantage_minutes': time_advantage,
                    'volume_usd': buyer.get('first_buy', {}).get('volume_usd', 0),
                    'holding': buyer.get('holding', 0),
                    'total_invested': buyer.get('total_invested', 0),
                    'token': token_address,
                    'token_name': token_name
                })
        
        print(f"  🎯 Found {len(early_buyers)} wallets that bought before KOL")
        return early_buyers
    
    def cross_reference_wallets(self, all_early_buyers):
        """Find wallets that appear across multiple tokens"""
        wallet_appearances = defaultdict(list)
        
        # Group by wallet
        for buyer in all_early_buyers:
            wallet_appearances[buyer['wallet']].append(buyer)
        
        # Find suspicious wallets (appear in 2+ tokens)
        suspicious_wallets = {}
        for wallet, appearances in wallet_appearances.items():
            if len(appearances) >= 2:  # Appears in 2+ tokens
                total_invested = sum(a['total_invested'] for a in appearances)
                avg_time_advantage = sum(a['time_advantage_minutes'] for a in appearances) / len(appearances)
                tokens = [a['token_name'] for a in appearances]
                
                suspicious_wallets[wallet] = {
                    'wallet': wallet,
                    'frequency': len(appearances),
                    'tokens': tokens,
                    'total_invested': total_invested,
                    'avg_time_advantage_minutes': avg_time_advantage,
                    'appearances': appearances,
                    'consistency_score': len(appearances) / len(set(a['token'] for a in all_early_buyers if a['wallet'] == wallet))
                }
        
        return suspicious_wallets
    
    def calculate_suspicion_scores(self, suspicious_wallets):
        """Calculate suspicion scores for ranking"""
        scored_wallets = []
        
        for wallet_data in suspicious_wallets.values():
            # Scoring factors
            frequency_score = wallet_data['frequency'] * 25  # 25 points per token
            consistency_score = wallet_data['consistency_score'] * 20  # 20 points for consistency
            volume_score = min(wallet_data['total_invested'] * 100, 30)  # Up to 30 points for volume
            timing_score = min(wallet_data['avg_time_advantage_minutes'] / 60, 25)  # Up to 25 points for timing
            
            total_score = frequency_score + consistency_score + volume_score + timing_score
            
            wallet_data['suspicion_score'] = total_score
            wallet_data['frequency_score'] = frequency_score
            wallet_data['consistency_score'] = consistency_score
            wallet_data['volume_score'] = volume_score
            wallet_data['timing_score'] = timing_score
            
            scored_wallets.append(wallet_data)
        
        # Sort by suspicion score
        scored_wallets.sort(key=lambda x: x['suspicion_score'], reverse=True)
        return scored_wallets
    
    def run_analysis(self, kol_wallet, tokens):
        """Run the complete analysis"""
        print(f"🕵️ KOL Alt Wallet Detection Analysis")
        print(f"📍 Target KOL Wallet: {kol_wallet}")
        print(f"🎯 Analyzing {len(tokens)} tokens")
        print("=" * 60)
        
        all_early_buyers = []
        
        # Analyze each token
        for i, token_info in enumerate(tokens, 1):
            if isinstance(token_info, dict):
                token_address = token_info['address']
                token_name = token_info.get('name', f'Token {i}')
            else:
                token_address = token_info
                token_name = f'Token {i}'
            
            early_buyers = self.analyze_token(kol_wallet, token_address, token_name)
            all_early_buyers.extend(early_buyers)
            
            # Small delay to be nice to the API
            time.sleep(1)
        
        if not all_early_buyers:
            print("\n❌ No early buyers found across any tokens")
            return
        
        print(f"\n📊 ANALYSIS SUMMARY")
        print(f"Total early buyers found: {len(all_early_buyers)}")
        print(f"Unique wallets: {len(set(b['wallet'] for b in all_early_buyers))}")
        
        # Cross-reference wallets
        print(f"\n🔍 Cross-referencing wallets across tokens...")
        suspicious_wallets = self.cross_reference_wallets(all_early_buyers)
        
        if not suspicious_wallets:
            print("❌ No wallets found across multiple tokens")
            return
        
        print(f"✅ Found {len(suspicious_wallets)} suspicious wallets")
        
        # Calculate scores
        scored_wallets = self.calculate_suspicion_scores(suspicious_wallets)
        
        # Display results
        print(f"\n🚨 SUSPICIOUS WALLETS RANKED BY SUSPICION SCORE")
        print("=" * 80)
        
        for i, wallet in enumerate(scored_wallets[:10], 1):  # Top 10
            print(f"\n#{i} WALLET: {wallet['wallet']}")
            print(f"   🎯 Suspicion Score: {wallet['suspicion_score']:.1f}/100")
            print(f"   📊 Frequency: {wallet['frequency']} tokens")
            print(f"   🎪 Tokens: {', '.join(wallet['tokens'])}")
            print(f"   💰 Total Invested: ${wallet['total_invested']:.4f}")
            print(f"   ⏰ Avg Time Advantage: {wallet['avg_time_advantage_minutes']:.1f} minutes")
            print(f"   📈 Consistency: {wallet['consistency_score']:.1f}%")
            
            print(f"   📋 Score Breakdown:")
            print(f"      Frequency: {wallet['frequency_score']:.1f}")
            print(f"      Consistency: {wallet['consistency_score']:.1f}")
            print(f"      Volume: {wallet['volume_score']:.1f}")
            print(f"      Timing: {wallet['timing_score']:.1f}")
        
        return scored_wallets

def main():
    # Configuration
    API_KEY = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    KOL_WALLET = "suqh5sHtr8HyJ7q8scBimULPkPpA557prMG47xCHQfK"
    
    TOKENS = [
        {"address": "2zBpPCeCge75KrdscAeaEpdzRpvvbJ7q6XcV9xeKpump", "name": "Token 1"},
        {"address": "EKk5jUgWno1Y9sCNKgLeHgUbxXm9jPnVaP9fkEw1uV9m", "name": "Token 2"}
    ]
    
    # Run analysis
    detector = KOLAltDetector(API_KEY)
    results = detector.run_analysis(KOL_WALLET, TOKENS)
    
    if results:
        print(f"\n✅ Analysis complete! Found {len(results)} suspicious wallets.")
        print(f"🎯 Top recommendation: {results[0]['wallet']} (Score: {results[0]['suspicion_score']:.1f})")
    else:
        print(f"\n❌ No suspicious patterns found.")

if __name__ == "__main__":
    main()

