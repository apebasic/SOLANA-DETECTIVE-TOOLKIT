#!/usr/bin/env python3
"""
Cross Reference Analysis
Cross-reference 神经蛙 sellers with Mortgage candidates
"""

import pandas as pd
import json
from datetime import datetime, timezone

def parse_csv_timestamp(timestamp_str: str) -> int:
    """Parse CSV timestamp string to Unix timestamp"""
    dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
    return int(dt.timestamp() * 1000)

def utc_to_unix_timestamp(year: int, month: int, day: int, 
                         hour: int, minute: int, second: int = 0) -> int:
    """Convert UTC time to Unix timestamp"""
    dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)

def determine_transaction_type(row: pd.Series, token_address: str) -> str:
    """Determine if transaction is buy or sell based on token flow"""
    token1 = row['Token1']
    token2 = row['Token2']
    sol_address = "So11111111111111111111111111111111111111112"
    
    if token1 == token_address and token2 == sol_address:
        return 'sell'  # Token -> SOL = SELL
    elif token1 == sol_address and token2 == token_address:
        return 'buy'   # SOL -> Token = BUY
    elif token1 == token_address or token2 == token_address:
        if token1 == token_address:
            return 'sell'  # User is giving away the token
        else:
            return 'buy'   # User is receiving the token
    
    return 'unknown'

def main():
    print("🔄 CROSS-REFERENCE ANALYSIS")
    print("=" * 50)
    
    # Load previous Mortgage results
    try:
        with open('/home/ubuntu/csv_analysis_results.json', 'r') as f:
            results = json.load(f)
            mortgage_wallets = set(results['mortgage']['intersection_wallets'])
            print(f"📊 Loaded {len(mortgage_wallets)} Mortgage candidate wallets")
    except:
        print("❌ Could not load Mortgage results")
        return
    
    # Analyze 神经蛙 sellers in sell timeframe
    print("\n🐸 ANALYZING 神经蛙 SELLERS")
    
    csv_path = "/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751059035337.csv"
    df = pd.read_csv(csv_path)
    
    neural_frog_token = "4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk"
    
    # Parse timestamps
    df['timestamp_unix'] = df['Human Time'].apply(parse_csv_timestamp)
    
    # Sell timeframe: June 27, 5:50-6:05 AM UTC
    sell_start = utc_to_unix_timestamp(2025, 6, 27, 5, 50, 0)
    sell_end = utc_to_unix_timestamp(2025, 6, 27, 6, 5, 0)
    
    # Filter by sell timeframe
    sell_df = df[(df['timestamp_unix'] >= sell_start) & (df['timestamp_unix'] <= sell_end)]
    print(f"📊 Transactions in sell timeframe: {len(sell_df)}")
    
    # Determine transaction types and get sellers
    sell_df = sell_df.copy()
    sell_df['transaction_type'] = sell_df.apply(
        lambda row: determine_transaction_type(row, neural_frog_token), axis=1
    )
    
    # Get unique sellers
    sellers = set()
    sell_transactions = []
    
    for _, row in sell_df.iterrows():
        if row['transaction_type'] == 'sell':
            sellers.add(row['From'])
            sell_transactions.append(row.to_dict())
    
    print(f"💰 Unique sellers in timeframe: {len(sellers)}")
    
    # Cross-reference with Mortgage wallets
    print(f"\n🎯 CROSS-REFERENCING WITH MORTGAGE WALLETS")
    intersection = mortgage_wallets & sellers
    
    print(f"🔍 Mortgage wallets: {len(mortgage_wallets)}")
    print(f"🔍 神经蛙 sellers: {len(sellers)}")
    print(f"🎯 INTERSECTION: {len(intersection)}")
    
    if intersection:
        print(f"\n🎉 FOUND {len(intersection)} WALLET(S) THAT TRADED BOTH TOKENS!")
        
        for i, wallet in enumerate(intersection, 1):
            print(f"\n{i}. 🌟 CANDIDATE WALLET: {wallet}")
            
            # Show 神经蛙 sell transactions for this wallet
            wallet_sells = [tx for tx in sell_transactions if tx['From'] == wallet]
            print(f"   📊 神经蛙 sells in timeframe: {len(wallet_sells)}")
            
            for sell in wallet_sells:
                print(f"   💰 SELL: {sell['Human Time']} | Value: ${sell['Value']} | Action: {sell['Action']}")
            
            print(f"   ✅ This wallet also bought AND sold Mortgage on June 25, 19:30-19:45 UTC")
        
        # Save results
        final_results = {
            'mortgage_candidates': list(mortgage_wallets),
            'neural_frog_sellers': list(sellers),
            'final_intersection': list(intersection),
            'analysis_summary': {
                'mortgage_wallets_count': len(mortgage_wallets),
                'neural_frog_sellers_count': len(sellers),
                'intersection_count': len(intersection)
            }
        }
        
        with open('/home/ubuntu/final_cross_reference_results.json', 'w') as f:
            json.dump(final_results, f, indent=2)
        
        print(f"\n📄 Results saved to final_cross_reference_results.json")
        
    else:
        print(f"\n❌ No wallets found that traded both tokens in the specified timeframes")
        
        # Show some sample wallets from each group for debugging
        print(f"\n🔍 SAMPLE MORTGAGE WALLETS:")
        for wallet in list(mortgage_wallets)[:5]:
            print(f"   - {wallet}")
        
        print(f"\n🔍 SAMPLE 神经蛙 SELLERS:")
        for wallet in list(sellers)[:5]:
            print(f"   - {wallet}")

if __name__ == "__main__":
    main()

