#!/usr/bin/env python3

import requests
import json
from datetime import datetime

api_key = 'd69a0997-86cb-4a69-8f0b-c3435a11b45b'
headers = {'x-api-key': api_key, 'accept': 'application/json'}
kol_wallet = 'suqh5sHtr8HyJ7q8scBimULPkPpA557prMG47xCHQfK'

# The main suspicious wallet from previous analysis
suspicious_wallet = '56S29mZ3wqvw8hATuUUFqKhGcSGYFASRRFNT38W8q7G3'

# New token to analyze
token_address = 'GZxo6raDU797Kkci1s4BKepwRPW7vhCK5fLstTYdpump'

print(f'🔍 Analyzing token: {token_address}')
print(f'📍 KOL Wallet: {kol_wallet}')
print(f'🎯 Checking for suspicious wallet: {suspicious_wallet}')
print('=' * 80)

# Step 1: Get KOL's trades to find when they first bought this token
print(f'\n📊 Getting KOL\'s transaction history...')
try:
    trades_url = f'https://data.solanatracker.io/wallet/{kol_wallet}/trades'
    trades_response = requests.get(trades_url, headers=headers, timeout=30)
    
    if trades_response.status_code == 200:
        trades_data = trades_response.json()
        trades = trades_data.get('trades', [])
        
        # Find KOL's first buy of this token
        kol_first_buy = None
        for trade in trades:
            to_addr = trade.get('to', {}).get('address')
            if to_addr == token_address:
                trade_time = trade.get('time')
                if trade_time and (kol_first_buy is None or trade_time < kol_first_buy):
                    kol_first_buy = trade_time
        
        if kol_first_buy:
            kol_date = datetime.fromtimestamp(kol_first_buy / 1000)
            print(f'✅ KOL first bought on: {kol_date}')
        else:
            print(f'❌ KOL never bought this token')
            exit()
    else:
        print(f'❌ Error getting KOL trades: {trades_response.text}')
        exit()
        
except Exception as e:
    print(f'❌ Exception getting KOL trades: {e}')
    exit()

# Step 2: Get first buyers for this token
print(f'\n📊 Getting first buyers...')
try:
    fb_url = f'https://data.solanatracker.io/first-buyers/{token_address}'
    fb_response = requests.get(fb_url, headers=headers, timeout=30)
    
    if fb_response.status_code == 200:
        first_buyers = fb_response.json()
        print(f'✅ Found {len(first_buyers)} first buyers')
        
        # Step 3: Filter buyers who bought before KOL
        early_buyers = []
        suspicious_wallet_found = False
        
        for buyer in first_buyers:
            buyer_time = buyer.get('first_buy_time')
            if buyer_time and buyer_time < kol_first_buy:
                buyer_date = datetime.fromtimestamp(buyer_time / 1000)
                time_advantage = (kol_first_buy - buyer_time) / 1000  # seconds
                
                early_buyer_data = {
                    'wallet': buyer['wallet'],
                    'first_buy_time': buyer_time,
                    'first_buy_date': buyer_date,
                    'time_advantage_seconds': time_advantage,
                    'volume_usd': buyer.get('first_buy', {}).get('volume_usd', 0),
                    'total_invested': buyer.get('total_invested', 0),
                    'holding': buyer.get('holding', 0)
                }
                
                early_buyers.append(early_buyer_data)
                
                # Check if this is our suspicious wallet
                if buyer['wallet'] == suspicious_wallet:
                    suspicious_wallet_found = True
        
        print(f'🎯 Found {len(early_buyers)} wallets that bought before KOL')
        
        # Step 4: Check for suspicious wallet
        print(f'\n🚨 SUSPICIOUS WALLET CHECK:')
        if suspicious_wallet_found:
            print(f'✅ FOUND! Suspicious wallet {suspicious_wallet} appears in this token!')
            for buyer in early_buyers:
                if buyer['wallet'] == suspicious_wallet:
                    print(f'   📊 First buy: {buyer["first_buy_date"]}')
                    print(f'   ⏰ Time advantage: {buyer["time_advantage_seconds"]:.1f} seconds')
                    print(f'   💰 Investment: ${buyer["total_invested"]:.4f}')
            
            # Update total count
            print(f'\n🔥 UPDATED TOTAL PATTERN: 7 out of 13 tokens (53.8% hit rate)!')
        else:
            print(f'❌ Suspicious wallet {suspicious_wallet} NOT found in this token')
            print(f'   Total pattern remains: 6 out of 13 tokens (46.2% hit rate)')
        
        # Step 5: Show all early buyers
        print(f'\n📋 ALL EARLY BUYERS (Top 20):')
        early_buyers.sort(key=lambda x: x['first_buy_time'])
        
        for i, buyer in enumerate(early_buyers[:20], 1):
            wallet = buyer['wallet']
            date = buyer['first_buy_date']
            advantage = buyer['time_advantage_seconds']
            investment = buyer['total_invested']
            
            # Highlight if it's our suspicious wallet
            marker = '🚨' if wallet == suspicious_wallet else '  '
            
            print(f'{marker}#{i}: {wallet}')
            print(f'     Time: {date} ({advantage:.1f}s advantage)')
            print(f'     Investment: ${investment:.4f}')
            
    else:
        print(f'❌ Error getting first buyers: {fb_response.text}')
        
except Exception as e:
    print(f'❌ Exception getting first buyers: {e}')

print(f'\n✅ Analysis complete!')

