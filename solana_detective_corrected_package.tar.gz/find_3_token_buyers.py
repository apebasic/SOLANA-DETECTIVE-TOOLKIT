#!/usr/bin/env python3
"""
Find wallets that bought ALL 3 specified tokens
Using the explained architecture: comprehensive data collection + set intersection
"""

import requests
import json
from collections import defaultdict
import time

def get_all_buyers_for_token(token_address, api_key):
    """Get ALL buyers for a token using comprehensive approach"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    print(f"   🔍 Getting ALL buyers for {token_address[:8]}...")
    
    # Step 1: Get token info to find pools
    try:
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"   ❌ Error getting token info: {response.text}")
            return set()
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            print(f"   ❌ No pools found")
            return set()
        
        print(f"   ✅ Found {len(pools)} pools")
        
        # Step 2: Get buyers from all pools
        all_buyers = set()
        
        for pool_idx, pool in enumerate(pools, 1):
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
                
            print(f"   📊 Pool {pool_idx}/{len(pools)}: {pool_id[:8]}...")
            
            # Get trades from this pool - focus on early pages for efficiency
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            page = 1
            max_pages = 50  # Limit to first 50 pages for efficiency
            
            while page <= max_pages:
                try:
                    params = {'page': page, 'limit': 100}
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        print(f"      ❌ Error page {page}: {response.text}")
                        break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        print(f"      ✅ No more trades at page {page}")
                        break
                    
                    # Extract buyer wallets from buy trades
                    page_buyers = 0
                    for trade in trades:
                        if trade.get('type') == 'buy':
                            wallet = trade.get('wallet')
                            if wallet:
                                all_buyers.add(wallet)
                                page_buyers += 1
                    
                    print(f"      📄 Page {page}: {len(trades)} trades, {page_buyers} buyers, {len(all_buyers)} total unique")
                    
                    page += 1
                    time.sleep(1.1)  # Rate limiting
                    
                except Exception as e:
                    print(f"      ❌ Exception page {page}: {e}")
                    break
        
        print(f"   ✅ Total unique buyers: {len(all_buyers)}")
        return all_buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return set()

def find_wallets_bought_all_3_tokens():
    """Find wallets that bought ALL 3 specified tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # The 3 tokens to analyze
    tokens = [
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk"
    ]
    
    print(f"🔍 FINDING WALLETS THAT BOUGHT ALL 3 TOKENS")
    print("=" * 60)
    print("🏗️ Using explained architecture:")
    print("   1. Comprehensive data collection from all pools")
    print("   2. Set intersection for efficient analysis")
    print("   3. Focus on early buyers for efficiency")
    print("=" * 60)
    
    # Step 1: Get ALL buyers for each token
    token_buyers = {}
    
    for i, token in enumerate(tokens, 1):
        print(f"\n📊 {i}/3 Processing token:")
        print(f"   {token}")
        
        buyers = get_all_buyers_for_token(token, api_key)
        token_buyers[token] = buyers
        
        print(f"   ✅ Found {len(buyers)} total buyers")
    
    # Step 2: Find intersection - wallets that bought ALL 3 tokens
    print(f"\n🎯 CROSS-TOKEN INTERSECTION ANALYSIS:")
    print("=" * 50)
    
    if len(token_buyers) != 3:
        print("❌ Could not collect data for all tokens")
        return
    
    # Start with buyers from first token
    token_list = list(tokens)
    common_wallets = token_buyers[token_list[0]].copy()
    
    print(f"Starting with {len(common_wallets)} buyers from token 1")
    
    # Find intersection with other tokens
    for i, token in enumerate(token_list[1:], 2):
        token_buyers_set = token_buyers[token]
        common_wallets = common_wallets.intersection(token_buyers_set)
        print(f"After token {i}: {len(common_wallets)} wallets remain")
        
        if len(common_wallets) == 0:
            print("❌ No common wallets found")
            break
    
    # Step 3: Results
    print(f"\n🎯 FINAL RESULTS:")
    print("=" * 50)
    
    if common_wallets:
        print(f"✅ Found {len(common_wallets)} wallet(s) that bought ALL 3 tokens:")
        print()
        
        for i, wallet in enumerate(sorted(common_wallets), 1):
            print(f"{i}. {wallet}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for wallet in sorted(common_wallets):
            print(wallet)
            
    else:
        print(f"❌ No wallets found that bought ALL 3 tokens")
        
        # Show statistics for debugging
        print(f"\n📊 BUYER STATISTICS:")
        for i, token in enumerate(tokens, 1):
            buyers_count = len(token_buyers[token])
            print(f"   Token {i}: {buyers_count} total buyers")
            
        # Check pairwise intersections
        print(f"\n🔍 PAIRWISE INTERSECTIONS:")
        for i in range(len(tokens)):
            for j in range(i+1, len(tokens)):
                intersection = token_buyers[tokens[i]].intersection(token_buyers[tokens[j]])
                print(f"   Tokens {i+1} & {j+1}: {len(intersection)} common wallets")

if __name__ == "__main__":
    find_wallets_bought_all_3_tokens()
