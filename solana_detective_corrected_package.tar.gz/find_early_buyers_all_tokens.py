#!/usr/bin/env python3
"""
Find wallets that bought ALL tokens during early launch stages
Focuses on early buyers, not recent activity
"""

import requests
import json
from collections import defaultdict
from datetime import datetime, timedelta
import time

def get_token_launch_date(token_address, api_key):
    """Get token launch date to focus search on early period"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    try:
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            token_data = response.json()
            created_at = token_data.get('createdAt')
            if created_at:
                return datetime.fromtimestamp(created_at / 1000)
        return None
    except:
        return None

def get_early_buyers_for_token(token_address, api_key, days_after_launch=7):
    """Get buyers from early launch period (first X days)"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    print(f"   🔍 Getting early buyers for {token_address[:8]}...")
    
    # Get launch date
    launch_date = get_token_launch_date(token_address, api_key)
    if launch_date:
        end_date = launch_date + timedelta(days=days_after_launch)
        print(f"   📅 Launch: {launch_date.strftime('%Y-%m-%d')}, searching first {days_after_launch} days")
    else:
        print(f"   ⚠️ Could not get launch date, using first buyers method")
        # Fallback to first buyers if we can't get launch date
        try:
            response = requests.get(f'{base_url}/first-buyers/{token_address}', headers=headers, timeout=30)
            if response.status_code == 200:
                buyers_data = response.json()
                buyers = set()
                for buyer in buyers_data:
                    wallet = buyer.get('wallet')
                    if wallet:
                        buyers.add(wallet)
                print(f"   ✅ Found {len(buyers)} first buyers")
                return buyers
        except:
            pass
        return set()
    
    # Get token info to find pools
    try:
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"   ❌ Error getting token info")
            return set()
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            print(f"   ❌ No pools found")
            return set()
        
        # Focus on main pool (usually the first/largest)
        main_pool = pools[0]
        pool_id = main_pool.get('poolId')
        
        print(f"   📊 Searching early trades in main pool...")
        
        # Get early trades using time filtering
        trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
        
        # Convert dates to timestamps for API
        start_timestamp = int(launch_date.timestamp())
        end_timestamp = int(end_date.timestamp())
        
        early_buyers = set()
        page = 1
        
        while page <= 20:  # Limit to first 20 pages for early period
            try:
                params = {
                    'page': page, 
                    'limit': 100,
                    'time_from': start_timestamp,
                    'time_to': end_timestamp
                }
                
                response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                
                if response.status_code != 200:
                    # If time filtering doesn't work, try without it
                    params = {'page': page, 'limit': 100}
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        break
                
                trades_data = response.json()
                trades = trades_data.get('trades', [])
                
                if not trades:
                    break
                
                # Extract early buyer wallets
                early_trades_count = 0
                for trade in trades:
                    trade_time = trade.get('time', 0)
                    if trade_time:
                        trade_date = datetime.fromtimestamp(trade_time / 1000)
                        
                        # Only include trades from early period
                        if trade_date <= end_date:
                            early_trades_count += 1
                            if trade.get('type') == 'buy':
                                wallet = trade.get('wallet')
                                if wallet:
                                    early_buyers.add(wallet)
                
                print(f"   📄 Page {page}: {early_trades_count} early trades, {len(early_buyers)} unique early buyers")
                
                # If no early trades in this page, we've gone too far
                if early_trades_count == 0:
                    print(f"   ✅ Reached end of early period at page {page}")
                    break
                
                page += 1
                time.sleep(1.1)  # Rate limiting
                
            except Exception as e:
                print(f"   ❌ Exception: {e}")
                break
        
        print(f"   ✅ Found {len(early_buyers)} early buyers")
        return early_buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return set()

def find_wallets_bought_all_tokens_early():
    """Find wallets that bought ALL tokens during early launch periods"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    tokens = [
        "qfyhNU2WmMAT1P5kc3isJNBKRpHec3ZLiLWxn38pump",
        "DFVeSFxNohR5CVuReaXSz6rGuJ62LsKhxFpWsDbbjups", 
        "EoD6LKTTpkLjpWaf9Dyemo7C4qEzsxWjPqCRa76apump",
        "8CDe8CVX74r3mEpcr2LsGGrNoGdJFt4uSYWyGfKUpump",
        "4dmQFkCM1WiUhC75UndLkmMtWj78fQJUvfc4xpMLpump",
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump"
    ]
    
    print(f"🔍 EARLY BUYER ANALYSIS: Finding wallets that bought ALL {len(tokens)} tokens during early launch")
    print("=" * 80)
    print("🎯 Focusing on early launch periods (first 7 days after launch)")
    print("⚡ Much faster than searching all historical data")
    print("=" * 80)
    
    # Get early buyers for each token
    token_buyers = {}
    
    for i, token in enumerate(tokens, 1):
        print(f"\n📊 {i}/{len(tokens)} Processing token:")
        print(f"   {token}")
        
        buyers = get_early_buyers_for_token(token, api_key)
        token_buyers[token] = buyers
    
    # Find intersection
    print(f"\n🎯 FINDING INTERSECTION:")
    print("=" * 50)
    
    if not token_buyers:
        print("❌ No data collected")
        return
    
    # Start with first token's buyers
    first_token = tokens[0]
    common_wallets = token_buyers[first_token].copy()
    
    print(f"Starting with {len(common_wallets)} early buyers from first token")
    
    # Find intersection
    for i, token in enumerate(tokens[1:], 2):
        token_buyers_set = token_buyers[token]
        common_wallets = common_wallets.intersection(token_buyers_set)
        print(f"After token {i}: {len(common_wallets)} wallets remain")
        
        if len(common_wallets) == 0:
            print("❌ No common wallets, stopping")
            break
    
    # Results
    print(f"\n🎯 FINAL RESULTS:")
    print("=" * 50)
    
    if common_wallets:
        print(f"✅ Found {len(common_wallets)} wallet(s) that bought ALL {len(tokens)} tokens during early launch:")
        print()
        
        for i, wallet in enumerate(sorted(common_wallets), 1):
            print(f"{i}. {wallet}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for wallet in sorted(common_wallets):
            print(wallet)
    else:
        print(f"❌ No wallets bought ALL {len(tokens)} tokens during early launch periods")
        
        # Show statistics
        print(f"\n📊 EARLY BUYER STATISTICS:")
        for i, token in enumerate(tokens, 1):
            buyers_count = len(token_buyers[token])
            print(f"   Token {i}: {buyers_count} early buyers")

if __name__ == "__main__":
    find_wallets_bought_all_tokens_early()
