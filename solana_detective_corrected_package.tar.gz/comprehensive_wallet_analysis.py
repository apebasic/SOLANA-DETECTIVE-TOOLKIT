#!/usr/bin/env python3
"""
Comprehensive Wallet Analysis
Check if candidate wallets have traded all tokens mentioned in our conversation
"""

import requests
import json
import time
from typing import Dict, List, Set

class ComprehensiveWalletAnalyzer:
    def __init__(self):
        # Load API key
        with open('/home/ubuntu/config.json', 'r') as f:
            config = json.load(f)
            self.api_key = config['api_key']
        
        self.base_url = "https://data.solanatracker.io"
        
        # All token addresses mentioned in our conversation
        self.tokens = {
            'PFP': '4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump',
            'GIRLIES': 'DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtdmrdS1i7ru1gqkXn9Hkbonk',
            'SYN': 'BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk',
            'Mortgage': 'FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN',
            '神经蛙': '4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk',
            'BLORB': 'CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump'
        }
        
        # Candidate wallets from our analysis
        self.candidate_wallets = [
            '337s6TEdfSZ3T1HqMGpuiE8vji5AUtSPXfwaUw1fowKo',
            'HuTshmtwcQkWBLzgW3m4uwcmik7Lmz4YFpYcTqMJpXiP'
        ]
    
    def get_wallet_trades_for_token(self, wallet_address: str, token_address: str) -> Dict:
        """Get all trades for a specific wallet and token"""
        url = f"{self.base_url}/trades/{token_address}/by-wallet/{wallet_address}"
        headers = {"x-api-key": self.api_key}
        
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                data = response.json()
                return data
            else:
                print(f"   ❌ API Error {response.status_code} for {wallet_address[:8]}... on token {token_address[:8]}...")
                return {}
        except Exception as e:
            print(f"   ❌ Exception for {wallet_address[:8]}... on token {token_address[:8]}...: {e}")
            return {}
    
    def analyze_wallet_comprehensive(self, wallet_address: str) -> Dict:
        """Analyze a wallet's trading activity across all tokens"""
        print(f"\n🔍 ANALYZING WALLET: {wallet_address}")
        print("=" * 80)
        
        wallet_results = {
            'wallet_address': wallet_address,
            'tokens_traded': {},
            'summary': {
                'total_tokens_traded': 0,
                'total_transactions': 0,
                'tokens_with_activity': []
            }
        }
        
        for token_name, token_address in self.tokens.items():
            print(f"   📊 Checking {token_name} ({token_address[:8]}...)")
            
            # Get trades for this wallet and token
            trades_data = self.get_wallet_trades_for_token(wallet_address, token_address)
            
            if trades_data and 'trades' in trades_data:
                trades = trades_data['trades']
                trade_count = len(trades)
                
                if trade_count > 0:
                    # Analyze trade types
                    buy_count = len([t for t in trades if t.get('type') == 'buy'])
                    sell_count = len([t for t in trades if t.get('type') == 'sell'])
                    
                    # Get date range
                    timestamps = [t.get('time', 0) for t in trades if t.get('time')]
                    if timestamps:
                        earliest = min(timestamps)
                        latest = max(timestamps)
                        from datetime import datetime
                        earliest_date = datetime.fromtimestamp(earliest/1000).strftime('%Y-%m-%d %H:%M:%S')
                        latest_date = datetime.fromtimestamp(latest/1000).strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        earliest_date = "Unknown"
                        latest_date = "Unknown"
                    
                    # Calculate total volume
                    total_volume = sum([float(t.get('volume', 0)) for t in trades])
                    
                    wallet_results['tokens_traded'][token_name] = {
                        'token_address': token_address,
                        'total_trades': trade_count,
                        'buy_count': buy_count,
                        'sell_count': sell_count,
                        'total_volume_sol': total_volume,
                        'date_range': f"{earliest_date} to {latest_date}",
                        'has_both_buy_and_sell': buy_count > 0 and sell_count > 0
                    }
                    
                    wallet_results['summary']['tokens_with_activity'].append(token_name)
                    wallet_results['summary']['total_transactions'] += trade_count
                    
                    print(f"      ✅ {trade_count} trades ({buy_count} buys, {sell_count} sells)")
                    print(f"      📅 {earliest_date} to {latest_date}")
                    print(f"      💰 Total volume: {total_volume:.4f} SOL")
                    
                    if buy_count > 0 and sell_count > 0:
                        print(f"      🎯 HAS BOTH BUY AND SELL")
                else:
                    print(f"      ❌ No trades found")
            else:
                print(f"      ❌ No data or API error")
            
            # Small delay to avoid rate limiting
            time.sleep(0.5)
        
        wallet_results['summary']['total_tokens_traded'] = len(wallet_results['summary']['tokens_with_activity'])
        
        return wallet_results
    
    def run_comprehensive_analysis(self):
        """Run comprehensive analysis for all candidate wallets"""
        print("🚀 COMPREHENSIVE WALLET ANALYSIS")
        print("=" * 80)
        print(f"📊 Analyzing {len(self.candidate_wallets)} candidate wallets")
        print(f"🎯 Checking activity across {len(self.tokens)} tokens")
        
        all_results = {}
        
        for wallet in self.candidate_wallets:
            wallet_results = self.analyze_wallet_comprehensive(wallet)
            all_results[wallet] = wallet_results
        
        # Generate summary comparison
        print(f"\n📊 SUMMARY COMPARISON")
        print("=" * 80)
        
        for wallet, results in all_results.items():
            summary = results['summary']
            print(f"\n🌟 WALLET: {wallet}")
            print(f"   📊 Tokens traded: {summary['total_tokens_traded']}/{len(self.tokens)}")
            print(f"   📊 Total transactions: {summary['total_transactions']}")
            print(f"   📊 Active tokens: {', '.join(summary['tokens_with_activity'])}")
            
            # Check for tokens with both buy and sell
            both_buy_sell_tokens = []
            for token_name, token_data in results['tokens_traded'].items():
                if token_data['has_both_buy_and_sell']:
                    both_buy_sell_tokens.append(token_name)
            
            if both_buy_sell_tokens:
                print(f"   🎯 Tokens with both buy/sell: {', '.join(both_buy_sell_tokens)}")
            
            # Check if this wallet traded all tokens
            if summary['total_tokens_traded'] == len(self.tokens):
                print(f"   🎉 TRADED ALL {len(self.tokens)} TOKENS!")
        
        # Save results
        with open('/home/ubuntu/comprehensive_wallet_analysis_results.json', 'w') as f:
            json.dump(all_results, f, indent=2)
        
        print(f"\n📄 Results saved to comprehensive_wallet_analysis_results.json")
        
        return all_results

def main():
    analyzer = ComprehensiveWalletAnalyzer()
    results = analyzer.run_comprehensive_analysis()

if __name__ == "__main__":
    main()

