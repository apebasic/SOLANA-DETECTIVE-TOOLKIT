#!/usr/bin/env python3
"""
Manual Parameter Fix for Solana Tracker API Documentation
Adds missing query parameters based on observed patterns
"""

import json

def fix_missing_parameters():
    """Manually add missing query parameters for key endpoints"""
    
    # Load existing documentation
    with open('FINAL_COMPLETE_SOLANA_API_DOCS.json', 'r') as f:
        documentation = json.load(f)
    
    # Manual parameter additions based on observed patterns
    parameter_fixes = {
        "GET /price": [
            {
                "name": "token",
                "type": "string",
                "description": "The token address",
                "required": True
            },
            {
                "name": "priceChanges",
                "type": "boolean",
                "description": "Returns price change percentages up to 24 hours ago",
                "required": False
            }
        ],
        "GET /price/history": [
            {
                "name": "token",
                "type": "string", 
                "description": "The token address",
                "required": True
            },
            {
                "name": "time_from",
                "type": "integer",
                "description": "Start time (unix timestamp)",
                "required": True
            },
            {
                "name": "time_to", 
                "type": "integer",
                "description": "End time (unix timestamp)",
                "required": True
            }
        ],
        "GET /price/history/timestamp": [
            {
                "name": "token",
                "type": "string",
                "description": "The token address", 
                "required": True
            },
            {
                "name": "timestamp",
                "type": "integer",
                "description": "Unix timestamp",
                "required": True
            }
        ],
        "GET /price/history/range": [
            {
                "name": "token",
                "type": "string",
                "description": "The token address",
                "required": True
            },
            {
                "name": "time_from",
                "type": "integer", 
                "description": "Start time (unix timestamp)",
                "required": True
            },
            {
                "name": "time_to",
                "type": "integer",
                "description": "End time (unix timestamp)", 
                "required": True
            }
        ],
        "GET /chart/{token}": [
            {
                "name": "type",
                "type": "string",
                "description": "Time interval (e.g., '1s', '1m', '1h', '1d')",
                "required": False
            },
            {
                "name": "time_from",
                "type": "integer",
                "description": "Start time (Unix timestamp in seconds)",
                "required": False
            },
            {
                "name": "time_to",
                "type": "integer", 
                "description": "End time (Unix timestamp in seconds)",
                "required": False
            },
            {
                "name": "marketCap",
                "type": "boolean",
                "description": "Return chart for market cap instead of pricing",
                "required": False
            },
            {
                "name": "removeOutliers",
                "type": "boolean",
                "description": "Set to false to disable outlier removal, true by default",
                "required": False
            }
        ],
        "GET /chart/{token}/{pool}": [
            {
                "name": "type",
                "type": "string",
                "description": "Time interval (e.g., '1s', '1m', '1h', '1d')",
                "required": False
            },
            {
                "name": "time_from",
                "type": "integer",
                "description": "Start time (Unix timestamp in seconds)",
                "required": False
            },
            {
                "name": "time_to",
                "type": "integer",
                "description": "End time (Unix timestamp in seconds)",
                "required": False
            },
            {
                "name": "marketCap",
                "type": "boolean",
                "description": "Return chart for market cap instead of pricing",
                "required": False
            },
            {
                "name": "removeOutliers",
                "type": "boolean",
                "description": "Set to false to disable outlier removal, true by default",
                "required": False
            }
        ],
        "GET /deployer/{wallet}": [
            {
                "name": "page",
                "type": "integer",
                "description": "Page number (default: 1)",
                "required": False
            },
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of items per page (default: 250, max: 500)",
                "required": False
            }
        ],
        "GET /search": [
            {
                "name": "query",
                "type": "string",
                "description": "Search query for tokens",
                "required": True
            },
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of results to return",
                "required": False
            }
        ],
        "GET /tokens/latest": [
            {
                "name": "page",
                "type": "integer",
                "description": "Page number (default: 1)",
                "required": False
            },
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of items per page (default: 250, max: 500)",
                "required": False
            }
        ],
        "GET /wallet/{owner}/trades": [
            {
                "name": "page",
                "type": "integer",
                "description": "Page number for pagination",
                "required": False
            },
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of trades per page",
                "required": False
            }
        ],
        "GET /trades/{tokenAddress}/{poolAddress}": [
            {
                "name": "page",
                "type": "integer",
                "description": "Page number for pagination",
                "required": False
            },
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of trades per page",
                "required": False
            }
        ],
        "GET /first-buyers/{token}": [
            {
                "name": "limit",
                "type": "integer",
                "description": "Number of first buyers to return",
                "required": False
            }
        ]
    }
    
    print("🔧 MANUAL PARAMETER FIX - Adding missing query parameters")
    print("=" * 60)
    
    fixed_count = 0
    
    for endpoint_name, parameters in parameter_fixes.items():
        if endpoint_name in documentation['endpoints']:
            documentation['endpoints'][endpoint_name]['query_parameters'] = parameters
            fixed_count += 1
            print(f"✅ Fixed: {endpoint_name} - Added {len(parameters)} parameters")
            for param in parameters:
                required = " (required)" if param['required'] else " (optional)"
                print(f"   📋 {param['name']}{required}: {param['description']}")
        else:
            print(f"❌ Endpoint not found: {endpoint_name}")
    
    print(f"\n🎉 Manual fix completed!")
    print(f"📈 Fixed: {fixed_count} endpoints")
    
    # Save updated documentation
    with open('MANUALLY_FIXED_SOLANA_API_DOCS.json', 'w', encoding='utf-8') as f:
        json.dump(documentation, f, indent=2, ensure_ascii=False)
    print(f"💾 Updated documentation saved: MANUALLY_FIXED_SOLANA_API_DOCS.json")
    
    # Generate updated markdown
    generate_updated_markdown(documentation)
    
def generate_updated_markdown(documentation):
    """Generate updated markdown with manually fixed parameters"""
    print("📝 Generating updated markdown documentation...")
    
    markdown = f"""# SOLANA TRACKER API - COMPLETE DOCUMENTATION (MANUALLY FIXED)

**Base URL**: `{documentation['base_url']}`
**Authentication**: {documentation['authentication']}
**Total Endpoints**: {documentation['total_endpoints']}
**Last Updated**: 2025-06-28 (Manual Parameter Fix)

## COMPLETE API REFERENCE WITH MANUALLY FIXED PARAMETERS

"""
    
    # Group endpoints by category
    categories = {
        "Token Endpoints": [],
        "Price Endpoints": [],
        "Wallet Endpoints": [],
        "Trade Endpoints": [],
        "Chart Data Endpoints": [],
        "PnL Data Endpoints": [],
        "Top Traders Endpoints": [],
        "Stats and Events Endpoints": [],
        "Credits Endpoints": []
    }
    
    # Categorize endpoints
    for endpoint_name, endpoint_doc in documentation['endpoints'].items():
        path = endpoint_doc.get('path', '')
        
        if path.startswith('/tokens'):
            categories["Token Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/price'):
            categories["Price Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/wallet'):
            categories["Wallet Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/trades'):
            categories["Trade Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/chart') or path.startswith('/holders'):
            categories["Chart Data Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/pnl') or path.startswith('/first-buyers'):
            categories["PnL Data Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/top-traders'):
            categories["Top Traders Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/stats') or path.startswith('/events'):
            categories["Stats and Events Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/credits'):
            categories["Credits Endpoints"].append((endpoint_name, endpoint_doc))
            
    # Generate detailed documentation
    for category, endpoints in categories.items():
        if endpoints:
            markdown += f"## {category}\n\n"
            
            for endpoint_name, endpoint_doc in endpoints:
                markdown += f"### {endpoint_name}\n\n"
                
                if endpoint_doc.get('description'):
                    markdown += f"**Description**: {endpoint_doc['description']}\n\n"
                    
                # Path Parameters
                if endpoint_doc.get('path_parameters'):
                    markdown += "**Path Parameters**:\n"
                    for param in endpoint_doc['path_parameters']:
                        required = " (required)" if param.get('required') else " (optional)"
                        markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                    markdown += "\n"
                    
                # Query Parameters (MANUALLY FIXED)
                if endpoint_doc.get('query_parameters'):
                    markdown += "**Query Parameters**:\n"
                    for param in endpoint_doc['query_parameters']:
                        required = " (required)" if param.get('required') else " (optional)"
                        markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                    markdown += "\n"
                    
                # Available Intervals
                if endpoint_doc.get('available_intervals'):
                    markdown += "**Available Intervals**: "
                    markdown += ", ".join(f"`{interval}`" for interval in endpoint_doc['available_intervals'])
                    markdown += "\n\n"
                    
                # Pagination
                if endpoint_doc.get('pagination_supported'):
                    markdown += "**Pagination**: Supported (cursor-based)\n\n"
                    
                # Notes
                if endpoint_doc.get('notes'):
                    markdown += "**Notes**:\n"
                    for note in endpoint_doc['notes']:
                        markdown += f"- {note}\n"
                    markdown += "\n"
                    
                # Response Example
                if endpoint_doc.get('example_response'):
                    markdown += f"**Response Example**:\n```json\n{endpoint_doc['example_response']}\n```\n\n"
                    
                markdown += "---\n\n"
                
    filename = 'MANUALLY_FIXED_SOLANA_TRACKER_API_DOCS.md'
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(markdown)
        
    print(f"✅ Updated markdown documentation generated: {filename}")

if __name__ == "__main__":
    fix_missing_parameters()

