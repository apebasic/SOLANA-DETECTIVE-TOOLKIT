#!/usr/bin/env python3
"""
Debug script to examine pool structure
"""

import requests
import json

def debug_pool_structure():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {"x-api-key": api_key}
    base_url = "https://data.solanatracker.io"
    
    # Test token: PFP
    token_address = "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump"
    
    print(f"🔍 Examining pool structure for token: {token_address}")
    print("=" * 60)
    
    # Get token info
    url = f"{base_url}/tokens/{token_address}"
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        token_data = response.json()
        pools = token_data.get('pools', [])
        print(f"Number of pools: {len(pools)}")
        
        for i, pool in enumerate(pools):
            print(f"\nPool {i+1}:")
            print(f"  Full pool object: {pool}")
            print(f"  Keys: {list(pool.keys())}")
            
            # Try different possible address fields
            possible_address_fields = ['address', 'pool', 'poolAddress', 'id', 'pubkey']
            for field in possible_address_fields:
                if field in pool:
                    print(f"  {field}: {pool[field]}")
    else:
        print(f"Error: {response.text}")

if __name__ == "__main__":
    debug_pool_structure()

