#!/usr/bin/env python3
"""
Incremental Cross-Token Analysis
Systematically collect transactions in phases and cross-reference wallet addresses
"""

import requests
import json
import time
from datetime import datetime
from collections import defaultdict

class IncrementalTokenAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {"x-api-key": api_key}
        
        # Token addresses
        self.tokens = {
            "PFP": "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",
            "GIRLIES": "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump", 
            "SYN": "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk"
        }
        
        # Track progress for each token
        self.token_progress = {}
        self.token_wallets = {}
        self.api_calls_made = 0
        
        for token_name in self.tokens:
            self.token_progress[token_name] = {
                "transactions_collected": 0,
                "last_block": None,
                "last_timestamp": None,
                "pools_processed": [],
                "current_pool_index": 0,
                "current_page": 1
            }
            self.token_wallets[token_name] = set()

    def get_token_pools(self, token_address):
        """Get all pools for a token"""
        url = f"{self.base_url}/tokens/{token_address}"
        try:
            response = requests.get(url, headers=self.headers)
            self.api_calls_made += 1
            
            if response.status_code == 200:
                data = response.json()
                pools = data.get('pools', [])
                print(f"Found {len(pools)} pools for token")
                return pools
            else:
                print(f"Error getting token info: {response.status_code}")
                return []
        except Exception as e:
            print(f"Exception getting token pools: {e}")
            return []

    def collect_transactions_for_token(self, token_name, target_transactions):
        """Collect transactions for a specific token up to target count"""
        token_address = self.tokens[token_name]
        progress = self.token_progress[token_name]
        
        print(f"\n=== COLLECTING TRANSACTIONS FOR {token_name} ===")
        print(f"Target: {target_transactions} transactions")
        print(f"Already collected: {progress['transactions_collected']}")
        
        # Get pools if not already done
        if not progress['pools_processed']:
            pools = self.get_token_pools(token_address)
            if not pools:
                print(f"No pools found for {token_name}")
                return
            progress['pools_processed'] = pools
            print(f"Will process {len(pools)} pools")

        # Continue from where we left off
        pools = progress['pools_processed']
        current_pool_idx = progress['current_pool_index']
        current_page = progress['current_page']
        
        while (progress['transactions_collected'] < target_transactions and 
               current_pool_idx < len(pools)):
            
            pool = pools[current_pool_idx]
            pool_address = pool["poolId"]
            
            print(f"\nProcessing Pool {current_pool_idx + 1}/{len(pools)}: {pool_address[:8]}...")
            
            # Get trades from this pool starting from current page
            while progress['transactions_collected'] < target_transactions:
                url = f"{self.base_url}/trades/{token_address}/{pool_address}"
                params = {"page": current_page}
                
                try:
                    response = requests.get(url, headers=self.headers, params=params)
                    self.api_calls_made += 1
                    
                    if response.status_code == 200:
                        trades = response.json()
                        
                        if not trades:  # No more trades in this pool
                            print(f"  No more trades on page {current_page}")
                            break
                            
                        # Process trades
                        new_wallets = 0
                        for trade in trades:
                            if progress['transactions_collected'] >= target_transactions:
                                break
                                
                            # Extract wallet address (buyer)
                            wallet = trade.get('owner')
                            if wallet and wallet not in self.token_wallets[token_name]:
                                self.token_wallets[token_name].add(wallet)
                                new_wallets += 1
                            
                            # Track progress
                            progress['transactions_collected'] += 1
                            progress['last_block'] = trade.get('slot')
                            progress['last_timestamp'] = trade.get('timestamp')
                        
                        print(f"  Page {current_page}: {len(trades)} trades, {new_wallets} new wallets")
                        print(f"  Total collected: {progress['transactions_collected']}/{target_transactions}")
                        
                        current_page += 1
                        time.sleep(1.1)  # Rate limiting
                        
                    else:
                        print(f"  Error on page {current_page}: {response.status_code}")
                        break
                        
                except Exception as e:
                    print(f"  Exception on page {current_page}: {e}")
                    break
            
            # Move to next pool
            current_pool_idx += 1
            current_page = 1  # Reset page for next pool
            
            # Update progress
            progress['current_pool_index'] = current_pool_idx
            progress['current_page'] = current_page

        print(f"\n{token_name} Collection Complete:")
        print(f"  Transactions: {progress['transactions_collected']}")
        print(f"  Unique wallets: {len(self.token_wallets[token_name])}")
        print(f"  Last block: {progress['last_block']}")
        print(f"  Last timestamp: {progress['last_timestamp']}")

    def cross_reference_wallets(self):
        """Find wallets that appear in multiple tokens"""
        print(f"\n=== CROSS-REFERENCING WALLETS ===")
        
        # Get all wallet sets
        pfp_wallets = self.token_wallets.get("PFP", set())
        girlies_wallets = self.token_wallets.get("GIRLIES", set())
        syn_wallets = self.token_wallets.get("SYN", set())
        
        print(f"PFP wallets: {len(pfp_wallets)}")
        print(f"GIRLIES wallets: {len(girlies_wallets)}")
        print(f"SYN wallets: {len(syn_wallets)}")
        
        # Find intersections
        pfp_girlies = pfp_wallets & girlies_wallets
        pfp_syn = pfp_wallets & syn_wallets
        girlies_syn = girlies_wallets & syn_wallets
        all_three = pfp_wallets & girlies_wallets & syn_wallets
        
        print(f"\nCROSS-MATCHES:")
        print(f"PFP + GIRLIES: {len(pfp_girlies)} wallets")
        print(f"PFP + SYN: {len(pfp_syn)} wallets")
        print(f"GIRLIES + SYN: {len(girlies_syn)} wallets")
        print(f"ALL THREE: {len(all_three)} wallets")
        
        if all_three:
            print(f"\n🎯 WALLETS THAT BOUGHT ALL THREE TOKENS:")
            for wallet in all_three:
                print(f"  {wallet}")
        
        return {
            "pfp_girlies": pfp_girlies,
            "pfp_syn": pfp_syn,
            "girlies_syn": girlies_syn,
            "all_three": all_three
        }

    def generate_phase_report(self, phase_name, matches):
        """Generate report after each phase"""
        print(f"\n" + "="*60)
        print(f"📊 PHASE REPORT: {phase_name}")
        print(f"="*60)
        
        print(f"API Calls Made: {self.api_calls_made}")
        print(f"Estimated Cost: {self.api_calls_made} credits")
        
        print(f"\nTRANSACTION COLLECTION STATUS:")
        for token_name in self.tokens:
            progress = self.token_progress[token_name]
            print(f"  {token_name}:")
            print(f"    Transactions: {progress['transactions_collected']}")
            print(f"    Unique wallets: {len(self.token_wallets[token_name])}")
            print(f"    Last block: {progress['last_block']}")
            print(f"    Pools processed: {progress['current_pool_index']}/{len(progress.get('pools_processed', []))}")
        
        print(f"\nCROSS-MATCHES FOUND:")
        print(f"  PFP + GIRLIES: {len(matches['pfp_girlies'])}")
        print(f"  PFP + SYN: {len(matches['pfp_syn'])}")
        print(f"  GIRLIES + SYN: {len(matches['girlies_syn'])}")
        print(f"  ALL THREE: {len(matches['all_three'])}")
        
        if matches['all_three']:
            print(f"\n🎯 SUCCESS! Found {len(matches['all_three'])} wallets that bought all three tokens!")
            return True
        else:
            print(f"\n⏳ No complete matches yet. Continue to next increment?")
            return False

    def run_phase_1(self):
        """Phase 1: Collect first 5,000 transactions per token"""
        print("🚀 STARTING PHASE 1: First 5,000 transactions per token")
        
        for token_name in ["PFP", "GIRLIES", "SYN"]:
            self.collect_transactions_for_token(token_name, 5000)
        
        matches = self.cross_reference_wallets()
        success = self.generate_phase_report("PHASE 1", matches)
        
        return success, matches

    def run_incremental_phase(self, increment_size=2000):
        """Run incremental phase: collect next N transactions"""
        print(f"🔄 STARTING INCREMENTAL PHASE: Next {increment_size} transactions per token")
        
        for token_name in ["PFP", "GIRLIES", "SYN"]:
            current_count = self.token_progress[token_name]['transactions_collected']
            target_count = current_count + increment_size
            self.collect_transactions_for_token(token_name, target_count)
        
        matches = self.cross_reference_wallets()
        success = self.generate_phase_report(f"INCREMENTAL (+{increment_size})", matches)
        
        return success, matches

if __name__ == "__main__":
    API_KEY = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    analyzer = IncrementalTokenAnalyzer(API_KEY)
    
    # Run Phase 1
    success, matches = analyzer.run_phase_1()
    
    if not success:
        print(f"\n" + "="*60)
        print("PHASE 1 COMPLETE - AWAITING USER DECISION")
        print("="*60)
        print("No wallets found that bought all three tokens in first 5,000 transactions.")
        print("Ready for incremental phase if approved.")
