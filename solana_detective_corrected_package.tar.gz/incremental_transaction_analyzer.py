#!/usr/bin/env python3
"""
Enhanced Incremental Transaction Analyzer
Collects transactions in phases with block tracking and cross-referencing
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Set, Tuple, Optional

class IncrementalTransactionAnalyzer:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {"x-api-key": api_key}
        
        # Track progress for each token
        self.token_progress = {}
        self.token_wallets = {}
        
    def get_token_info(self, token_address: str) -> Dict:
        """Get token information including pools"""
        url = f"{self.base_url}/tokens/{token_address}"
        response = requests.get(url, headers=self.headers)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def get_trades_page(self, token_address: str, pool_address: str, page: int = 1) -> Dict:
        """Get trades for a specific page"""
        url = f"{self.base_url}/trades/{token_address}/{pool_address}"
        params = {"page": page}
        
        response = requests.get(url, headers=self.headers, params=params)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def collect_transactions_for_token(self, token_address: str, target_count: int, 
                                     start_from_last: bool = False) -> Dict:
        """
        Collect transactions for a token up to target_count
        Returns: {
            'wallets': set of wallet addresses,
            'last_block': last block processed,
            'last_timestamp': last timestamp processed,
            'total_collected': total transactions collected,
            'api_calls_used': number of API calls made
        }
        """
        print(f"\n🔍 Collecting {target_count} transactions for token: {token_address[:8]}...")
        
        # Get token info and pools
        token_info = self.get_token_info(token_address)
        if not token_info:
            print(f"❌ Could not get token info for {token_address}")
            return {}
        
        pools = token_info.get('pools', [])
        if not pools:
            print(f"❌ No pools found for token {token_address}")
            return {}
        
        # Sort pools by liquidity (USD) and take only the top one
        pools_with_liquidity = []
        for pool in pools:
            liquidity_usd = pool.get('liquidity', {}).get('usd', 0)
            pools_with_liquidity.append((pool, liquidity_usd))
        
        # Sort by liquidity descending and take top pool
        pools_with_liquidity.sort(key=lambda x: x[1], reverse=True)
        top_pool = pools_with_liquidity[0][0]
        top_liquidity = pools_with_liquidity[0][1]
        
        print(f"📊 Found {len(pools)} pools, using top liquidity pool: ${top_liquidity:,.2f}")
        pools = [top_pool]  # Only process the top pool
        
        # Initialize or get existing progress
        if token_address not in self.token_progress:
            self.token_progress[token_address] = {
                'last_block': None,
                'last_timestamp': None,
                'pools_processed': {},
                'total_collected': 0
            }
            self.token_wallets[token_address] = set()
        
        progress = self.token_progress[token_address]
        wallets = self.token_wallets[token_address]
        
        collected_count = 0
        api_calls = 0
        last_block = progress['last_block']
        last_timestamp = progress['last_timestamp']
        
        # Process each pool
        for pool in pools:
            pool_address = pool.get('poolId', '')
            if not pool_address:
                continue
                
            print(f"  📈 Processing pool: {pool_address[:8]}...")
            
            # Start from where we left off for this pool
            start_page = progress['pools_processed'].get(pool_address, 1)
            page = start_page
            
            while collected_count < target_count:
                print(f"    📄 Page {page} (collected: {collected_count}/{target_count})")
                
                trades_data = self.get_trades_page(token_address, pool_address, page)
                api_calls += 1
                
                if not trades_data or 'trades' not in trades_data:
                    print(f"    ⚠️ No more trades in pool {pool_address[:8]}")
                    break
                
                trades = trades_data['trades']
                if not trades:
                    print(f"    ⚠️ Empty trades page in pool {pool_address[:8]}")
                    break
                
                # Process trades
                for trade in trades:
                    if collected_count >= target_count:
                        break
                    
                    # Extract wallet address (buyer)
                    wallet = trade.get('wallet', '')
                    if wallet and trade.get('type') == 'buy':
                        wallets.add(wallet)
                        collected_count += 1
                        
                        # Track block and timestamp
                        block = trade.get('block')
                        timestamp = trade.get('timestamp')
                        
                        if block and (not last_block or block > last_block):
                            last_block = block
                        if timestamp and (not last_timestamp or timestamp > last_timestamp):
                            last_timestamp = timestamp
                
                # Update progress
                progress['pools_processed'][pool_address] = page + 1
                page += 1
                
                # Rate limiting
                time.sleep(1.1)
                
                if collected_count >= target_count:
                    break
            
            if collected_count >= target_count:
                break
        
        # Update final progress
        progress['last_block'] = last_block
        progress['last_timestamp'] = last_timestamp
        progress['total_collected'] += collected_count
        
        print(f"✅ Collected {collected_count} transactions from {api_calls} API calls")
        print(f"📊 Total unique wallets for this token: {len(wallets)}")
        
        return {
            'wallets': wallets,
            'last_block': last_block,
            'last_timestamp': last_timestamp,
            'total_collected': collected_count,
            'api_calls_used': api_calls,
            'unique_wallets': len(wallets)
        }
    
    def cross_reference_wallets(self, token_addresses: List[str]) -> Dict:
        """Cross-reference wallets across multiple tokens"""
        print(f"\n🔄 Cross-referencing wallets across {len(token_addresses)} tokens...")
        
        if len(token_addresses) < 2:
            return {}
        
        # Get wallet sets for each token
        wallet_sets = {}
        for token in token_addresses:
            if token in self.token_wallets:
                wallet_sets[token] = self.token_wallets[token]
                print(f"  📊 {token[:8]}: {len(wallet_sets[token])} wallets")
        
        # Find intersections
        results = {}
        
        # Pairwise intersections
        for i, token1 in enumerate(token_addresses):
            for j, token2 in enumerate(token_addresses):
                if i < j and token1 in wallet_sets and token2 in wallet_sets:
                    intersection = wallet_sets[token1] & wallet_sets[token2]
                    if intersection:
                        key = f"{token1[:8]} & {token2[:8]}"
                        results[key] = list(intersection)
                        print(f"  🎯 {key}: {len(intersection)} common wallets")
        
        # Three-way intersection (if 3 tokens)
        if len(token_addresses) == 3:
            all_tokens = list(wallet_sets.keys())
            if len(all_tokens) == 3:
                intersection = wallet_sets[all_tokens[0]] & wallet_sets[all_tokens[1]] & wallet_sets[all_tokens[2]]
                if intersection:
                    results['ALL_THREE'] = list(intersection)
                    print(f"  🎯 ALL THREE TOKENS: {len(intersection)} common wallets")
        
        return results
    
    def generate_phase_report(self, phase: str, token_addresses: List[str], 
                            collection_results: Dict, cross_ref_results: Dict) -> str:
        """Generate detailed phase report"""
        report = f"\n{'='*60}\n"
        report += f"📊 PHASE {phase} REPORT\n"
        report += f"{'='*60}\n"
        
        # Collection summary
        report += f"\n🔍 COLLECTION SUMMARY:\n"
        total_api_calls = 0
        for token in token_addresses:
            if token in collection_results:
                result = collection_results[token]
                report += f"  • {token[:8]}: {result['unique_wallets']} wallets, "
                report += f"{result['total_collected']} transactions, "
                report += f"{result['api_calls_used']} API calls\n"
                report += f"    Last block: {result['last_block']}\n"
                total_api_calls += result['api_calls_used']
        
        report += f"\n💰 Total API calls used: {total_api_calls}\n"
        
        # Cross-reference results
        report += f"\n🎯 CROSS-REFERENCE RESULTS:\n"
        if cross_ref_results:
            for key, wallets in cross_ref_results.items():
                report += f"  • {key}: {len(wallets)} common wallets\n"
                if len(wallets) <= 10:  # Show wallets if not too many
                    for wallet in wallets:
                        report += f"    - {wallet}\n"
        else:
            report += "  ❌ No common wallets found\n"
        
        # Recommendation
        report += f"\n💡 RECOMMENDATION:\n"
        if 'ALL_THREE' in cross_ref_results and cross_ref_results['ALL_THREE']:
            report += "  ✅ SUCCESS! Found wallets that bought all three tokens.\n"
            report += "  🛑 STOP - Analysis complete.\n"
        elif any(len(wallets) > 0 for wallets in cross_ref_results.values()):
            report += "  ⚠️ Found some pairwise matches but no three-way match.\n"
            report += "  ➡️ CONTINUE to next increment to find more data.\n"
        else:
            report += "  ❌ No matches found yet.\n"
            report += "  ➡️ CONTINUE to next increment.\n"
        
        return report

def main():
    # Load API key
    try:
        with open('/home/ubuntu/config.json', 'r') as f:
            config = json.load(f)
            api_key = config.get('api_key', '')
    except:
        print("❌ Could not load API key from config.json")
        return
    
    if not api_key:
        print("❌ No API key found in config")
        return
    
    # Token addresses
    tokens = [
        "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",  # PFP
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",  # GIRLIES
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk"    # SYN
    ]
    
    analyzer = IncrementalTransactionAnalyzer(api_key)
    
    print("🚀 Starting Incremental Transaction Analysis")
    print(f"📋 Analyzing {len(tokens)} tokens")
    
    # Phase 1: Collect first 5,000 transactions
    print(f"\n{'='*60}")
    print("🔥 PHASE 1: Collecting first 5,000 transactions per token")
    print(f"{'='*60}")
    
    phase1_results = {}
    for token in tokens:
        result = analyzer.collect_transactions_for_token(token, 5000)
        if result:
            phase1_results[token] = result
    
    # Cross-reference Phase 1
    cross_ref_1 = analyzer.cross_reference_wallets(tokens)
    
    # Generate Phase 1 report
    report1 = analyzer.generate_phase_report("1", tokens, phase1_results, cross_ref_1)
    print(report1)
    
    # Save report to file
    with open('/home/ubuntu/phase1_report.txt', 'w') as f:
        f.write(report1)
    
    print("\n📄 Phase 1 report saved to phase1_report.txt")
    print("⏸️ Pausing for user validation before proceeding to Phase 2...")

if __name__ == "__main__":
    main()

