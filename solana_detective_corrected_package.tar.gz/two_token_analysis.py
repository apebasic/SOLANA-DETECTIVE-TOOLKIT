#!/usr/bin/env python3
"""
Two Token Analysis - 神经蛙 and BLORB
Find all wallets that interacted with both tokens
"""

import pandas as pd
import json

def main():
    print("🔍 TWO TOKEN INTERSECTION ANALYSIS")
    print("=" * 60)
    print("📊 Analyzing 神经蛙 and BLORB tokens only")
    
    # Token information
    tokens = {
        '神经蛙': {
            'address': '4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk',
            'csv_path': '/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751061865153.csv'
        },
        'BLORB': {
            'address': 'CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump',
            'csv_path': '/home/ubuntu/upload/export_defi_activities_CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump_1751061700105.csv'
        }
    }
    
    # Dictionary to store wallets for each token
    token_wallets = {}
    
    # Process each token CSV
    for token_name, token_info in tokens.items():
        print(f"\n📊 ANALYZING {token_name} TOKEN")
        print(f"   Address: {token_info['address']}")
        
        try:
            # Read CSV
            df = pd.read_csv(token_info['csv_path'])
            print(f"   Total transactions: {len(df)}")
            
            # Get all unique wallets from 'From' column
            unique_wallets = set(df['From'].dropna().unique())
            token_wallets[token_name] = unique_wallets
            
            print(f"   Unique wallets: {len(unique_wallets)}")
            
            # Show some sample wallets
            sample_wallets = list(unique_wallets)[:3]
            for wallet in sample_wallets:
                print(f"     - {wallet}")
            
        except Exception as e:
            print(f"   ❌ Error reading CSV: {e}")
            token_wallets[token_name] = set()
    
    # Find intersection
    print(f"\n🎯 INTERSECTION ANALYSIS")
    print("=" * 60)
    
    if len(token_wallets) == 2:
        neural_frog_wallets = token_wallets['神经蛙']
        blorb_wallets = token_wallets['BLORB']
        
        print(f"📊 WALLET COUNTS:")
        print(f"   神经蛙: {len(neural_frog_wallets)} wallets")
        print(f"   BLORB: {len(blorb_wallets)} wallets")
        
        # Two-way intersection
        intersection = neural_frog_wallets & blorb_wallets
        
        print(f"\n🔗 INTERSECTION:")
        print(f"   神经蛙 ∩ BLORB: {len(intersection)} wallets")
        
        if intersection:
            print(f"\n🎉 FOUND {len(intersection)} WALLET(S) THAT INTERACTED WITH BOTH TOKENS!")
            
            for i, wallet in enumerate(intersection, 1):
                print(f"\n{i}. 🌟 CANDIDATE WALLET: {wallet}")
                
                # Count transactions for each token
                for token_name, token_info in tokens.items():
                    try:
                        df = pd.read_csv(token_info['csv_path'])
                        wallet_transactions = df[df['From'] == wallet]
                        transaction_count = len(wallet_transactions)
                        
                        print(f"   📊 {token_name}: {transaction_count} transactions")
                        
                        # Show date range of transactions
                        if transaction_count > 0:
                            earliest = wallet_transactions['Human Time'].min()
                            latest = wallet_transactions['Human Time'].max()
                            print(f"      📅 From {earliest} to {latest}")
                            
                            # Show sample transaction values
                            sample_values = wallet_transactions['Value'].head(3).tolist()
                            print(f"      💰 Sample values: {sample_values}")
                            
                            # Show transaction types
                            actions = wallet_transactions['Action'].unique()
                            print(f"      🔧 Actions: {', '.join(actions)}")
                    
                    except Exception as e:
                        print(f"   ❌ Error analyzing {token_name}: {e}")
            
            # Save results
            results = {
                'analysis_summary': {
                    'neural_frog_wallets_count': len(neural_frog_wallets),
                    'blorb_wallets_count': len(blorb_wallets),
                    'intersection_count': len(intersection)
                },
                'intersection_wallets': list(intersection),
                'token_addresses': {
                    '神经蛙': tokens['神经蛙']['address'],
                    'BLORB': tokens['BLORB']['address']
                }
            }
            
            with open('/home/ubuntu/two_token_intersection_results.json', 'w') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            print(f"\n📄 Results saved to two_token_intersection_results.json")
            
        else:
            print(f"\n❌ No wallets found that interacted with both tokens")
            
            # Show some wallets from each token for reference
            print(f"\n🔍 SAMPLE 神经蛙 WALLETS:")
            for wallet in list(neural_frog_wallets)[:5]:
                print(f"   - {wallet}")
            
            print(f"\n🔍 SAMPLE BLORB WALLETS:")
            for wallet in list(blorb_wallets)[:5]:
                print(f"   - {wallet}")
    
    else:
        print("❌ Could not load both token datasets")

if __name__ == "__main__":
    main()

