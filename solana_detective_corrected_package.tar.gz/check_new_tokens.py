#!/usr/bin/env python3

import requests
import json
from datetime import datetime

api_key = 'd69a0997-86cb-4a69-8f0b-c3435a11b45b'
headers = {'x-api-key': api_key, 'accept': 'application/json'}

# The top suspicious wallet from previous analysis
suspicious_wallet = '56S29mZ3wqvw8hATuUUFqKhGcSGYFASRRFNT38W8q7G3'

# New 2 tokens
new_tokens = [
    '2zBpPCeCge75KrdscAeaEpdzRpvvbJ7q6XcV9xeKpump',
    'EKk5jUgWno1Y9sCNKgLeHgUbxXm9jPnVaP9fkEw1uV9m'
]

print(f'🔍 Checking if wallet {suspicious_wallet} appears in the 2 new tokens...')

found_in_new = []

for i, token in enumerate(new_tokens, 1):
    print(f'\n📊 Checking Token {i}: {token}')
    
    try:
        url = f'https://data.solanatracker.io/first-buyers/{token}'
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            first_buyers = response.json()
            
            # Check if our suspicious wallet is in the first buyers
            wallet_found = False
            for buyer in first_buyers:
                if buyer.get('wallet') == suspicious_wallet:
                    wallet_found = True
                    print(f'  ✅ FOUND! Wallet appears in first buyers')
                    print(f'     First buy time: {buyer.get("first_buy_time")}')
                    print(f'     Investment: ${buyer.get("total_invested", 0):.4f}')
                    found_in_new.append({
                        'token': f'Token {i}',
                        'token_address': token,
                        'first_buy_time': buyer.get('first_buy_time'),
                        'investment': buyer.get('total_invested', 0)
                    })
                    break
            
            if not wallet_found:
                print(f'  ❌ Not found in first buyers')
        else:
            print(f'  ❌ Error getting first buyers: {response.status_code}')
            
    except Exception as e:
        print(f'  ❌ Exception: {e}')

print(f'\n🎯 SUMMARY:')
if found_in_new:
    print(f'✅ Wallet {suspicious_wallet} appears in {len(found_in_new)} of the 2 new tokens:')
    for finding in found_in_new:
        date = datetime.fromtimestamp(finding['first_buy_time'] / 1000)
        print(f'  - {finding["token"]}: {date}, ${finding["investment"]:.4f}')
    
    # Previous total was 6 out of 10
    total_tokens = 6 + len(found_in_new)  # Previous 6 + new findings
    total_analyzed = 10 + 2  # Previous 10 + new 2
    print(f'\n🚨 UPDATED TOTAL PATTERN: This wallet bought {total_tokens} out of {total_analyzed} total tokens!')
    print(f'   Hit rate: {total_tokens/total_analyzed*100:.1f}%')
else:
    print(f'❌ Wallet {suspicious_wallet} did NOT appear in either of the 2 new tokens')
    print(f'   Total pattern remains: 6 out of 12 tokens (50.0% hit rate)')

# Also show all early buyers for these tokens
print(f'\n📋 ALL EARLY BUYERS FOR THESE 2 TOKENS:')
for i, token in enumerate(new_tokens, 1):
    print(f'\n🎯 Token {i} Early Buyers:')
    try:
        url = f'https://data.solanatracker.io/first-buyers/{token}'
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            first_buyers = response.json()
            print(f'   Found {len(first_buyers)} first buyers')
            
            # Show top 10 early buyers
            for j, buyer in enumerate(first_buyers[:10], 1):
                date = datetime.fromtimestamp(buyer.get('first_buy_time', 0) / 1000)
                investment = buyer.get('total_invested', 0)
                wallet = buyer.get('wallet', 'Unknown')
                print(f'   #{j}: {wallet} - {date} - ${investment:.4f}')
                
        else:
            print(f'   Error: {response.status_code}')
    except Exception as e:
        print(f'   Exception: {e}')

