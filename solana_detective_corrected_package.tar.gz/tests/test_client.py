#!/usr/bin/env python3
"""
Comprehensive test suite for Solana Detective client
Tests all endpoints, error handling, and functionality
"""

import unittest
import json
import os
import sys
from unittest.mock import Mock, patch, MagicMock
from requests.exceptions import ConnectionError, Timeout

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solana_detective import SolanaDetective
from solana_detective.exceptions import (
    APIError, 
    AuthenticationError, 
    RateLimitError, 
    ValidationError
)
from solana_detective.config import Config

class TestSolanaDetectiveClient(unittest.TestCase):
    """Test cases for SolanaDetective client"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.api_key = "test_api_key_12345"
        self.client = SolanaDetective(api_key=self.api_key)
        
        # Mock response data
        self.mock_token_response = {
            "token": {
                "name": "Test Token",
                "symbol": "TEST",
                "mint": "test_token_address",
                "decimals": 6
            },
            "pools": [],
            "events": {},
            "risk": {"rugged": False}
        }
        
        self.mock_price_response = {
            "price": 1.23,
            "liquidity": 1000000,
            "marketCap": 50000000,
            "lastUpdated": 1628097600000
        }
        
        self.mock_trades_response = {
            "trades": [
                {
                    "tx": "test_transaction_signature",
                    "from": {"address": "test_from_address", "amount": 100},
                    "to": {"address": "test_to_address", "amount": 95},
                    "price": {"usd": 1.23},
                    "volume": {"usd": 123.45},
                    "time": 1628097600000
                }
            ],
            "nextCursor": "test_cursor",
            "hasNextPage": True
        }
    
    def test_client_initialization(self):
        """Test client initialization"""
        # Test with API key
        client = SolanaDetective(api_key="test_key")
        self.assertEqual(client.config.get("api_key"), "test_key")
        
        # Test with config object
        config = Config(api_key="config_key")
        client = SolanaDetective(config=config)
        self.assertEqual(client.config.get("api_key"), "config_key")
    
    def test_client_initialization_no_api_key(self):
        """Test client initialization without API key raises error"""
        with self.assertRaises(ValueError):
            SolanaDetective()
    
    @patch('solana_detective.client.requests.Session.request')
    def test_successful_api_request(self, mock_request):
        """Test successful API request"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = self.mock_token_response
        mock_request.return_value = mock_response
        
        result = self.client._make_request("GET", "/test")
        self.assertEqual(result, self.mock_token_response)
    
    @patch('solana_detective.client.requests.Session.request')
    def test_authentication_error(self, mock_request):
        """Test authentication error handling"""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_request.return_value = mock_response
        
        with self.assertRaises(AuthenticationError):
            self.client._make_request("GET", "/test")
    
    @patch('solana_detective.client.requests.Session.request')
    def test_rate_limit_error(self, mock_request):
        """Test rate limit error handling"""
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.headers = {"Retry-After": "60"}
        mock_request.return_value = mock_response
        
        with self.assertRaises(RateLimitError) as context:
            self.client._make_request("GET", "/test")
        
        self.assertEqual(context.exception.retry_after, 60)
    
    @patch('solana_detective.client.requests.Session.request')
    def test_api_error(self, mock_request):
        """Test general API error handling"""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"error": "Internal server error"}
        mock_request.return_value = mock_response
        
        with self.assertRaises(APIError) as context:
            self.client._make_request("GET", "/test")
        
        self.assertEqual(context.exception.status_code, 500)
    
    @patch('solana_detective.client.requests.Session.request')
    def test_timeout_error(self, mock_request):
        """Test timeout error handling"""
        mock_request.side_effect = Timeout()
        
        with self.assertRaises(APIError) as context:
            self.client._make_request("GET", "/test")
        
        self.assertIn("timeout", str(context.exception).lower())
    
    @patch('solana_detective.client.requests.Session.request')
    def test_connection_error(self, mock_request):
        """Test connection error handling"""
        mock_request.side_effect = ConnectionError()
        
        with self.assertRaises(APIError) as context:
            self.client._make_request("GET", "/test")
        
        self.assertIn("connection", str(context.exception).lower())
    
    def test_token_address_validation(self):
        """Test token address validation"""
        # Valid token address
        valid_token = "So11111111111111111111111111111111111111112"
        result = self.client._validate_token_address(valid_token)
        self.assertEqual(result, valid_token)
        
        # Invalid token addresses
        with self.assertRaises(ValidationError):
            self.client._validate_token_address("")
        
        with self.assertRaises(ValidationError):
            self.client._validate_token_address("short")
        
        with self.assertRaises(ValidationError):
            self.client._validate_token_address(None)
    
    def test_wallet_address_validation(self):
        """Test wallet address validation"""
        # Valid wallet address
        valid_wallet = "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D"
        result = self.client._validate_wallet_address(valid_wallet)
        self.assertEqual(result, valid_wallet)
        
        # Invalid wallet addresses
        with self.assertRaises(ValidationError):
            self.client._validate_wallet_address("")
        
        with self.assertRaises(ValidationError):
            self.client._validate_wallet_address("short")
        
        with self.assertRaises(ValidationError):
            self.client._validate_wallet_address(None)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_token_info(self, mock_request):
        """Test get_token_info method"""
        mock_request.return_value = self.mock_token_response
        
        result = self.client.get_token_info("So11111111111111111111111111111111111111112")
        
        mock_request.assert_called_once_with("GET", "/tokens/So11111111111111111111111111111111111111112")
        self.assertEqual(result, self.mock_token_response)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_token_price(self, mock_request):
        """Test get_token_price method"""
        mock_request.return_value = self.mock_price_response
        
        result = self.client.get_token_price("So11111111111111111111111111111111111111112")
        
        mock_request.assert_called_once_with("GET", "/price", params={"token": "So11111111111111111111111111111111111111112"})
        self.assertEqual(result, self.mock_price_response)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_token_price_with_changes(self, mock_request):
        """Test get_token_price method with price changes"""
        mock_request.return_value = self.mock_price_response
        
        result = self.client.get_token_price("So11111111111111111111111111111111111111112", price_changes=True)
        
        expected_params = {
            "token": "So11111111111111111111111111111111111111112",
            "priceChanges": "true"
        }
        mock_request.assert_called_once_with("GET", "/price", params=expected_params)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_wallet_trades(self, mock_request):
        """Test get_wallet_trades method"""
        mock_request.return_value = self.mock_trades_response
        
        result = self.client.get_wallet_trades("5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D")
        
        expected_params = {"page": 1, "limit": 100}
        mock_request.assert_called_once_with("GET", "/wallet/5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D/trades", params=expected_params)
        self.assertEqual(result, self.mock_trades_response)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_chart_data(self, mock_request):
        """Test get_chart_data method"""
        mock_chart_response = {
            "oclhv": [
                {
                    "open": 1.0,
                    "close": 1.1,
                    "low": 0.9,
                    "high": 1.2,
                    "volume": 1000,
                    "time": 1628097600
                }
            ]
        }
        mock_request.return_value = mock_chart_response
        
        # Test token only
        result = self.client.get_chart_data("So11111111111111111111111111111111111111112")
        
        expected_params = {
            "type": "1h",
            "marketCap": "false",
            "removeOutliers": "true"
        }
        mock_request.assert_called_with("GET", "/chart/So11111111111111111111111111111111111111112", params=expected_params)
        
        # Test token with pool
        result = self.client.get_chart_data("So11111111111111111111111111111111111111112", pool="test_pool")
        
        mock_request.assert_called_with("GET", "/chart/So11111111111111111111111111111111111111112/test_pool", params=expected_params)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_search_tokens(self, mock_request):
        """Test search_tokens method"""
        mock_search_response = {
            "tokens": [
                {"name": "Test Token", "symbol": "TEST", "address": "test_address"}
            ]
        }
        mock_request.return_value = mock_search_response
        
        result = self.client.search_tokens("test")
        
        expected_params = {"query": "test", "limit": 10}
        mock_request.assert_called_once_with("GET", "/search", params=expected_params)
    
    def test_search_tokens_empty_query(self):
        """Test search_tokens with empty query raises error"""
        with self.assertRaises(ValidationError):
            self.client.search_tokens("")
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_get_multiple_token_prices_get(self, mock_request):
        """Test get_multiple_token_prices GET method"""
        mock_request.return_value = {"prices": []}
        
        tokens = ["token1", "token2"]
        result = self.client.get_multiple_token_prices(tokens)
        
        expected_params = {"tokens": "token1,token2"}
        mock_request.assert_called_once_with("GET", "/price/multi", params=expected_params)
    
    @patch('solana_detective.client.SolanaDetective._make_request')
    def test_post_multiple_token_prices(self, mock_request):
        """Test post_multiple_token_prices POST method"""
        mock_request.return_value = {"prices": []}
        
        tokens = ["token1", "token2"]
        result = self.client.post_multiple_token_prices(tokens)
        
        expected_data = {"tokens": tokens}
        mock_request.assert_called_once_with("POST", "/price/multi", data=expected_data)
    
    def test_post_multiple_token_prices_invalid_input(self):
        """Test post_multiple_token_prices with invalid input"""
        with self.assertRaises(ValidationError):
            self.client.post_multiple_token_prices([])
        
        with self.assertRaises(ValidationError):
            self.client.post_multiple_token_prices("not_a_list")
    
    def test_get_available_endpoints(self):
        """Test get_available_endpoints method"""
        endpoints = self.client.get_available_endpoints()
        
        # Should return a list of method names
        self.assertIsInstance(endpoints, list)
        self.assertIn("get_token_info", endpoints)
        self.assertIn("get_token_price", endpoints)
        self.assertIn("get_wallet_trades", endpoints)
        
        # Should not include private methods
        self.assertNotIn("_make_request", endpoints)
        self.assertNotIn("_validate_token_address", endpoints)
    
    @patch('solana_detective.client.SolanaDetective.get_credits')
    def test_health_check_healthy(self, mock_get_credits):
        """Test health_check when API is healthy"""
        mock_get_credits.return_value = {"credits": 1000}
        
        result = self.client.health_check()
        
        self.assertEqual(result["status"], "healthy")
        self.assertTrue(result["api_accessible"])
        self.assertEqual(result["credits_remaining"], 1000)
    
    @patch('solana_detective.client.SolanaDetective.get_credits')
    def test_health_check_unhealthy(self, mock_get_credits):
        """Test health_check when API is unhealthy"""
        mock_get_credits.side_effect = APIError("API unavailable")
        
        result = self.client.health_check()
        
        self.assertEqual(result["status"], "unhealthy")
        self.assertFalse(result["api_accessible"])
        self.assertIn("error", result)

class TestConfig(unittest.TestCase):
    """Test cases for Config class"""
    
    def test_config_initialization_with_api_key(self):
        """Test config initialization with API key"""
        config = Config(api_key="test_key")
        self.assertEqual(config.get("api_key"), "test_key")
    
    def test_config_initialization_no_api_key(self):
        """Test config initialization without API key raises error"""
        with self.assertRaises(ValueError):
            Config()
    
    def test_config_environment_variables(self):
        """Test config loading from environment variables"""
        with patch.dict(os.environ, {"SOLANA_TRACKER_API_KEY": "env_key"}):
            config = Config()
            self.assertEqual(config.get("api_key"), "env_key")
    
    def test_config_file_loading(self):
        """Test config loading from file"""
        # Create temporary config file
        test_config = {"api_key": "file_key", "timeout": 60}
        with open("test_config.json", "w") as f:
            json.dump(test_config, f)
        
        try:
            config = Config(config_file="test_config.json")
            self.assertEqual(config.get("api_key"), "file_key")
            self.assertEqual(config.get("timeout"), 60)
        finally:
            # Clean up
            if os.path.exists("test_config.json"):
                os.remove("test_config.json")
    
    def test_config_override_with_kwargs(self):
        """Test config override with kwargs"""
        config = Config(api_key="test_key", timeout=120)
        self.assertEqual(config.get("timeout"), 120)
    
    def test_config_get_set(self):
        """Test config get and set methods"""
        config = Config(api_key="test_key")
        
        # Test get with default
        self.assertEqual(config.get("nonexistent", "default"), "default")
        
        # Test set
        config.set("new_key", "new_value")
        self.assertEqual(config.get("new_key"), "new_value")
    
    def test_config_to_dict(self):
        """Test config to_dict method"""
        config = Config(api_key="test_key")
        config_dict = config.to_dict()
        
        self.assertIsInstance(config_dict, dict)
        self.assertEqual(config_dict["api_key"], "test_key")

if __name__ == "__main__":
    # Create test suite
    test_suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Print summary
    print(f"\n{'='*60}")
    print(f"TEST SUMMARY")
    print(f"{'='*60}")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print(f"\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print(f"\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    # Exit with appropriate code
    sys.exit(0 if result.wasSuccessful() else 1)

