#!/usr/bin/env python3
"""
Simple first hour buyer analysis - one token at a time
"""

import requests
import json
from datetime import datetime, timedelta
from collections import defaultdict
import time

def get_first_hour_buyers(token_address, token_name, launch_time, api_key):
    """Get buyers in first hour after launch for one token"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    end_time = launch_time + timedelta(hours=1)
    buyers = set()
    
    print(f"\n🔍 {token_name}:")
    print(f"   Launch: {launch_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   Window: {launch_time.strftime('%H:%M')} - {end_time.strftime('%H:%M')}")
    
    try:
        # Get token pools
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"   ❌ Failed to get token info")
            return buyers
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        print(f"   📊 Found {len(pools)} pools")
        
        # Check each pool
        for i, pool in enumerate(pools, 1):
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
                
            print(f"   Pool {i}/{len(pools)}: {pool_id[:8]}...", end=" ")
            
            # Get trades from pool
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            pool_buyers = 0
            for page in range(1, 11):  # Check first 10 pages
                try:
                    params = {'page': page, 'limit': 100}
                    response = requests.get(trades_url, headers=headers, params=params, timeout=20)
                    
                    if response.status_code != 200:
                        break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        break
                    
                    # Check trades in timeframe
                    for trade in trades:
                        trade_time = trade.get('time', 0)
                        if trade_time:
                            if trade_time > 1e12:
                                trade_time = trade_time / 1000
                            
                            trade_dt = datetime.fromtimestamp(trade_time)
                            
                            if launch_time <= trade_dt <= end_time:
                                if trade.get('type') == 'buy':
                                    wallet = trade.get('wallet')
                                    if wallet:
                                        buyers.add(wallet)
                                        pool_buyers += 1
                    
                    time.sleep(0.5)  # Rate limiting
                    
                except Exception as e:
                    break
            
            print(f"{pool_buyers} buyers")
        
        print(f"   ✅ Total: {len(buyers)} first-hour buyers")
        return buyers
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return buyers

def main():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # Token data with launch times
    tokens = [
        ("PFP", "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump", datetime(2025, 6, 27, 9, 15, 48)),
        ("GIRLIES", "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump", datetime(2025, 6, 27, 4, 40, 11)),
        ("SYN", "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk", datetime(2025, 6, 26, 10, 49, 6)),
        ("PUMPHOUSE", "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump", datetime(2025, 6, 26, 10, 58, 25))
    ]
    
    print("🚀 FIRST HOUR BUYER ANALYSIS")
    print("=" * 50)
    
    all_buyers = {}
    
    # Process each token
    for name, address, launch_time in tokens:
        buyers = get_first_hour_buyers(address, name, launch_time, api_key)
        all_buyers[name] = buyers
    
    # Cross-token analysis
    print(f"\n🎯 CROSS-TOKEN ANALYSIS:")
    print("=" * 30)
    
    wallet_tokens = defaultdict(set)
    for token_name, buyers in all_buyers.items():
        for wallet in buyers:
            wallet_tokens[wallet].add(token_name)
    
    # Group by count
    by_count = defaultdict(list)
    for wallet, tokens_bought in wallet_tokens.items():
        count = len(tokens_bought)
        by_count[count].append((wallet, tokens_bought))
    
    # Show results
    for count in sorted(by_count.keys(), reverse=True):
        wallets = by_count[count]
        print(f"\n📋 {len(wallets)} wallets bought {count}/4 tokens:")
        
        if count >= 2:  # Show multi-token buyers
            for i, (wallet, tokens_bought) in enumerate(wallets[:5], 1):  # Show first 5
                print(f"  {i}. {wallet}")
                print(f"     Tokens: {', '.join(sorted(tokens_bought))}")
            
            if len(wallets) > 5:
                print(f"     ... and {len(wallets) - 5} more")
        
        if count >= 4:
            print(f"\n🎉 FOUND WALLETS THAT BOUGHT ALL 4 TOKENS:")
            for wallet, _ in wallets:
                print(f"   {wallet}")
    
    # Summary
    print(f"\n📊 SUMMARY:")
    for name, buyers in all_buyers.items():
        print(f"   {name}: {len(buyers)} first-hour buyers")

if __name__ == "__main__":
    main()
