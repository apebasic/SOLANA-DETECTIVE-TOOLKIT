#!/usr/bin/env python3
"""
Interactive KOL Alt Wallet Detection Tool

This script provides an easy-to-use interface for the KOL alt wallet detection tool.
"""

import json
import os
from kol_alt_detector import KOLAltWalletDetector
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_user_input():
    """Get input from user interactively"""
    print("=== KOL Alt Wallet Detection Tool ===")
    print()
    
    # Get API key
    api_key = input("Enter your Solscan Pro API key: ").strip()
    if not api_key:
        print("API key is required!")
        return None
    
    # Get KOL wallet address
    kol_wallet = input("Enter KOL's public wallet address: ").strip()
    if not kol_wallet:
        print("KOL wallet address is required!")
        return None
    
    # Get token addresses
    print("\nEnter token contract addresses (one per line, press Enter twice when done):")
    token_addresses = []
    while True:
        token = input().strip()
        if not token:
            break
        token_addresses.append(token)
    
    if not token_addresses:
        print("At least one token address is required!")
        return None
    
    return {
        "api_key": api_key,
        "kol_wallet": kol_wallet,
        "token_addresses": token_addresses
    }

def load_config():
    """Load configuration from file"""
    config_path = "config.json"
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return None

def save_results(results, filename="analysis_results.json"):
    """Save results to file"""
    with open(filename, 'w') as f:
        json.dump(results, f, indent=2)
    return filename

def print_summary(results):
    """Print analysis summary"""
    summary = results["analysis_summary"]
    
    print("\n" + "="*50)
    print("ANALYSIS SUMMARY")
    print("="*50)
    print(f"KOL Wallet: {summary['kol_wallet']}")
    print(f"Tokens Analyzed: {summary['tokens_analyzed']}")
    print(f"Tokens with KOL Purchases: {summary['tokens_with_kol_purchases']}")
    print(f"Total Early Buyers Found: {summary['total_early_buyers']}")
    print(f"Suspicious Wallets Found: {summary['suspicious_wallets_found']}")
    
    if results["suspicious_wallets"]:
        print("\n" + "="*50)
        print("TOP SUSPICIOUS WALLETS")
        print("="*50)
        
        for i, wallet in enumerate(results["suspicious_wallets"][:5], 1):
            print(f"\n{i}. Wallet: {wallet['wallet_address']}")
            print(f"   Suspicion Score: {wallet['suspicion_score']:.3f}")
            print(f"   Tokens Bought Early: {wallet['tokens_bought_early']}")
            print(f"   Consistency Rate: {wallet['consistency_rate']:.1%}")
            print(f"   Avg Time Advantage: {wallet['avg_time_advantage_hours']:.1f} hours")
            print(f"   Total Early Volume: {wallet['total_early_volume']:.6f}")
            
            if wallet['token_details']:
                print("   Token Details:")
                for detail in wallet['token_details'][:3]:  # Show first 3 tokens
                    print(f"     - {detail['token_address'][:8]}... "
                          f"({detail['time_advantage_hours']:.1f}h advantage)")
    else:
        print("\nNo suspicious wallets found with current criteria.")
        print("You may want to:")
        print("- Lower the min_frequency or min_consistency in config.json")
        print("- Check if the KOL wallet actually made purchases in the provided tokens")
        print("- Verify the token addresses are correct")

def main():
    """Main interactive function"""
    try:
        # Get user input
        user_input = get_user_input()
        if not user_input:
            return
        
        # Load configuration
        config = load_config()
        if config:
            print(f"\nLoaded configuration from config.json")
        else:
            print(f"\nUsing default configuration")
        
        # Initialize detector
        print(f"\nInitializing detector...")
        detector = KOLAltWalletDetector(user_input["api_key"], config)
        
        # Run analysis
        print(f"\nStarting analysis...")
        print(f"This may take several minutes depending on the number of tokens and transaction history.")
        print(f"Please be patient...")
        
        results = detector.analyze_kol_wallet(
            user_input["kol_wallet"], 
            user_input["token_addresses"]
        )
        
        # Save results
        output_file = save_results(results)
        print(f"\nResults saved to: {output_file}")
        
        # Print summary
        print_summary(results)
        
        # Additional options
        print(f"\n" + "="*50)
        print("NEXT STEPS")
        print("="*50)
        print(f"1. Review the full results in {output_file}")
        print(f"2. Investigate suspicious wallets manually on Solscan.io")
        print(f"3. Look for direct connections between suspicious wallets and the KOL")
        print(f"4. Adjust configuration in config.json if needed")
        
    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user.")
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        print(f"\nError: {e}")
        print("Please check your inputs and try again.")

if __name__ == "__main__":
    main()

