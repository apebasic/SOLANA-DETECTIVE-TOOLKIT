#!/usr/bin/env python3
"""
Find wallets that bought a specific token in a time window
"""

import requests
import json
from datetime import datetime, timezone, timedelta
import pytz

def find_wallets_in_time_window():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    
    token_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    
    print(f"🔍 Finding wallets that bought {token_address}")
    print(f"⏰ Time window: 3:00pm - 3:10pm EST")
    print("=" * 80)
    
    # Get first buyers
    try:
        url = f'https://data.solanatracker.io/first-buyers/{token_address}'
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ Error getting first buyers: {response.text}")
            return
        
        first_buyers = response.json()
        print(f"✅ Found {len(first_buyers)} total first buyers")
        
        # Define EST timezone
        est = pytz.timezone('US/Eastern')
        
        # We need to determine which date's 3:00-3:10pm EST
        # Let's check the range of buy times first
        if first_buyers:
            times = [buyer.get('first_buy_time', 0) for buyer in first_buyers if buyer.get('first_buy_time')]
            if times:
                earliest = min(times)
                latest = max(times)
                earliest_date = datetime.fromtimestamp(earliest / 1000, tz=est)
                latest_date = datetime.fromtimestamp(latest / 1000, tz=est)
                
                print(f"📊 Buy time range:")
                print(f"   Earliest: {earliest_date}")
                print(f"   Latest: {latest_date}")
                
                # Find all possible 3:00-3:10pm EST windows in the data range
                current_date = earliest_date.date()
                end_date = latest_date.date()
                
                matching_wallets = []
                
                while current_date <= end_date:
                    # Create 3:00pm and 3:10pm EST for this date
                    start_time = est.localize(datetime.combine(current_date, datetime.min.time().replace(hour=15, minute=0)))
                    end_time = est.localize(datetime.combine(current_date, datetime.min.time().replace(hour=15, minute=10)))
                    
                    # Convert to milliseconds timestamp
                    start_timestamp = int(start_time.timestamp() * 1000)
                    end_timestamp = int(end_time.timestamp() * 1000)
                    
                    print(f"\n🔍 Checking {current_date} 3:00-3:10pm EST:")
                    print(f"   Start: {start_time}")
                    print(f"   End: {end_time}")
                    
                    # Find wallets in this time window
                    day_matches = []
                    for buyer in first_buyers:
                        buy_time = buyer.get('first_buy_time')
                        if buy_time and start_timestamp <= buy_time <= end_timestamp:
                            buy_datetime = datetime.fromtimestamp(buy_time / 1000, tz=est)
                            day_matches.append({
                                'wallet': buyer.get('wallet'),
                                'buy_time': buy_time,
                                'buy_datetime': buy_datetime,
                                'total_invested': buyer.get('total_invested', 0),
                                'volume_usd': buyer.get('first_buy', {}).get('volume_usd', 0),
                                'amount': buyer.get('first_buy', {}).get('amount', 0),
                                'holding': buyer.get('holding', 0),
                                'buy_transactions': buyer.get('buy_transactions', 0)
                            })
                    
                    if day_matches:
                        print(f"   ✅ Found {len(day_matches)} wallets")
                        matching_wallets.extend(day_matches)
                        
                        # Sort by time
                        day_matches.sort(key=lambda x: x['buy_time'])
                        
                        for i, match in enumerate(day_matches, 1):
                            wallet = match['wallet']
                            time_str = match['buy_datetime'].strftime('%H:%M:%S')
                            investment = match['total_invested']
                            volume = match['volume_usd']
                            amount = match['amount']
                            
                            print(f"      #{i}: {wallet}")
                            print(f"          Time: {time_str} EST")
                            print(f"          Investment: ${investment:.4f}")
                            print(f"          Volume: ${volume:.4f}")
                            print(f"          Amount: {amount:.4f}")
                    else:
                        print(f"   ❌ No wallets found")
                    
                    current_date += timedelta(days=1)
                
                # Summary
                print(f"\n" + "="*80)
                print(f"📊 SUMMARY")
                print(f"="*80)
                
                if matching_wallets:
                    print(f"✅ Total wallets found: {len(matching_wallets)}")
                    print(f"💰 Total investment: ${sum(w['total_invested'] for w in matching_wallets):.2f}")
                    print(f"📈 Total volume: ${sum(w['volume_usd'] for w in matching_wallets):.2f}")
                    
                    print(f"\n🎯 ALL MATCHING WALLETS:")
                    print(f"-" * 60)
                    
                    # Sort all matches by time
                    matching_wallets.sort(key=lambda x: x['buy_time'])
                    
                    for i, match in enumerate(matching_wallets, 1):
                        wallet = match['wallet']
                        date_time = match['buy_datetime'].strftime('%m-%d %H:%M:%S')
                        investment = match['total_invested']
                        volume = match['volume_usd']
                        
                        print(f"{i:2d}. {wallet}")
                        print(f"    📅 {date_time} EST")
                        print(f"    💰 ${investment:.4f} (Vol: ${volume:.4f})")
                        
                        # Check if this wallet appears in our previous analyses
                        known_suspicious = [
                            "56S29mZ3wqvw8hATuUUFqKhGcSGYFASRRFNT38W8q7G3",
                            "F3m2C4biThKXpPt6zbXW3VbXwucK8Rhv1Dtyrh1ruzUz",
                            "Eo753cT5dY47djQHZZ45rFgAWFSrcjyfZDwfpfM1ZiuG",
                            "FsG3BaPmRTdSrPaivbgJsFNCCa8cPfkUtk8VLWXkHpHP"
                        ]
                        
                        if wallet in known_suspicious:
                            print(f"    🚨 KNOWN SUSPICIOUS WALLET!")
                        
                        print()
                else:
                    print(f"❌ No wallets found buying between 3:00-3:10pm EST on any day")
            else:
                print(f"❌ No valid buy times found in data")
        else:
            print(f"❌ No first buyers data available")
            
    except Exception as e:
        print(f"❌ Exception: {e}")

if __name__ == "__main__":
    find_wallets_in_time_window()

