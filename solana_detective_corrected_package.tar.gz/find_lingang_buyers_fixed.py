#!/usr/bin/env python3

import requests
import json
from datetime import datetime, timezone
import pytz

def find_lingang_buyers():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    
    token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    pool_address = token_address  # For pump.fun tokens, pool = token address
    
    print(f"🔍 Finding wallets that bought $LINGANG")
    print(f"📍 Token: {token_address}")
    print(f"⏰ Time window: 11:56:20am - 12:02:20pm EST (June 26, 2025)")
    print("=" * 80)
    
    # Convert EST times to UTC timestamps
    est = pytz.timezone('US/Eastern')
    
    # June 26, 2025 times in EST
    start_time_est = est.localize(datetime(2025, 6, 26, 11, 56, 20))
    end_time_est = est.localize(datetime(2025, 6, 26, 12, 2, 20))
    
    # Convert to UTC timestamps
    start_timestamp = int(start_time_est.astimezone(pytz.UTC).timestamp())
    end_timestamp = int(end_time_est.astimezone(pytz.UTC).timestamp())
    
    print(f"🕐 Start: {start_time_est} EST = {start_timestamp} UTC")
    print(f"🕐 End: {end_time_est} EST = {end_timestamp} UTC")
    print()
    
    # Get trades for the specific time window
    print(f"📈 Getting trades from {start_time_est} to {end_time_est}...")
    
    try:
        trades_url = f'https://data.solanatracker.io/trades/{token_address}/{pool_address}'
        params = {
            'time_from': start_timestamp,
            'time_to': end_timestamp,
            'limit': 250
        }
        
        all_buyers = []
        page = 0
        
        while True:
            params['offset'] = page * 250
            response = requests.get(trades_url, headers=headers, params=params, timeout=30)
            
            if response.status_code != 200:
                print(f"❌ Error getting trades: {response.text}")
                break
            
            trades_data = response.json()
            trades = trades_data.get('trades', [])
            
            if not trades:
                break
                
            print(f"📄 Page {page + 1}: {len(trades)} trades")
            
            # Filter for buy transactions in our timeframe
            for trade in trades:
                trade_time = trade.get('time', 0)
                if start_timestamp <= trade_time <= end_timestamp:
                    # Check if it's a buy (positive volume usually indicates buy)
                    volume = trade.get('volume', 0)
                    if volume > 0:  # This is a buy
                        wallet = trade.get('owner')
                        if wallet:
                            all_buyers.append({
                                'wallet': wallet,
                                'time': trade_time,
                                'volume': volume,
                                'amount': trade.get('amount', 0)
                            })
            
            page += 1
            if len(trades) < 250:  # Last page
                break
        
        # Remove duplicates and sort by time
        unique_buyers = {}
        for buyer in all_buyers:
            wallet = buyer['wallet']
            if wallet not in unique_buyers:
                unique_buyers[wallet] = buyer
        
        buyers_list = list(unique_buyers.values())
        buyers_list.sort(key=lambda x: x['time'])
        
        print(f"\n🎯 RESULTS:")
        print(f"✅ Found {len(buyers_list)} unique buyers in the timeframe")
        
        if buyers_list:
            print(f"\n📋 WALLET ADDRESSES:")
            for i, buyer in enumerate(buyers_list, 1):
                trade_time = datetime.fromtimestamp(buyer['time'], tz=est)
                print(f"\n{i}. {buyer['wallet']}")
                print(f"   Time: {trade_time.strftime('%H:%M:%S')} EST")
                print(f"   Volume: ${buyer['volume']:.2f}")
            
            print(f"\n📝 COPY-PASTE LIST:")
            for buyer in buyers_list:
                print(buyer['wallet'])
        else:
            print("❌ No buyers found in the specified timeframe")
            
    except Exception as e:
        print(f"❌ Error getting trades: {e}")

if __name__ == "__main__":
    find_lingang_buyers()
