#!/usr/bin/env python3
"""
Debug Neural Frog CSV
Deep debug of 神经蛙 CSV to understand why no transactions are found
"""

import pandas as pd
from datetime import datetime, timezone

def parse_csv_timestamp(timestamp_str: str) -> int:
    """Parse CSV timestamp string to Unix timestamp"""
    # Parse ISO format: 2025-06-25T19:45:00.000Z
    dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
    return int(dt.timestamp() * 1000)

def utc_to_unix_timestamp(year: int, month: int, day: int, 
                         hour: int, minute: int, second: int = 0) -> int:
    """Convert UTC time to Unix timestamp"""
    dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)  # Convert to milliseconds

def main():
    print("🐸 DEBUGGING 神经蛙 CSV")
    print("=" * 50)
    
    # Read CSV
    csv_path = "/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751059035337.csv"
    df = pd.read_csv(csv_path)
    
    print(f"📊 Total transactions in CSV: {len(df)}")
    
    # Show first few rows to understand structure
    print("\n📋 FIRST 5 ROWS:")
    print(df.head().to_string())
    
    # Parse timestamps
    df['timestamp_unix'] = df['Human Time'].apply(parse_csv_timestamp)
    
    # Target timeframes
    # Buy: June 27, 2:00-2:30 AM UTC
    buy_start = utc_to_unix_timestamp(2025, 6, 27, 2, 0, 0)
    buy_end = utc_to_unix_timestamp(2025, 6, 27, 2, 30, 0)
    
    # Sell: June 27, 5:50-6:05 AM UTC
    sell_start = utc_to_unix_timestamp(2025, 6, 27, 5, 50, 0)
    sell_end = utc_to_unix_timestamp(2025, 6, 27, 6, 5, 0)
    
    print(f"\n🕐 Buy timeframe: {datetime.fromtimestamp(buy_start/1000, tz=timezone.utc)} to {datetime.fromtimestamp(buy_end/1000, tz=timezone.utc)}")
    print(f"🕐 Sell timeframe: {datetime.fromtimestamp(sell_start/1000, tz=timezone.utc)} to {datetime.fromtimestamp(sell_end/1000, tz=timezone.utc)}")
    
    # Check what's the earliest and latest timestamp in CSV
    earliest = df['timestamp_unix'].min()
    latest = df['timestamp_unix'].max()
    
    print(f"\n📊 CSV TIME RANGE:")
    print(f"   Earliest: {datetime.fromtimestamp(earliest/1000, tz=timezone.utc)}")
    print(f"   Latest: {datetime.fromtimestamp(latest/1000, tz=timezone.utc)}")
    
    # Filter by buy timeframe
    buy_df = df[(df['timestamp_unix'] >= buy_start) & (df['timestamp_unix'] <= buy_end)]
    print(f"\n🛒 TRANSACTIONS IN BUY TIMEFRAME: {len(buy_df)}")
    
    if len(buy_df) > 0:
        print("📋 BUY TIMEFRAME TRANSACTIONS:")
        for _, row in buy_df.iterrows():
            print(f"   Time: {row['Human Time']} | Action: {row['Action']} | From: {row['From']}")
            print(f"   Token1: {row['Token1']} | Token2: {row['Token2']} | Value: ${row['Value']}")
            print()
    else:
        print("❌ No transactions found in buy timeframe")
        
        # Check transactions around the buy timeframe
        print("\n🔍 CHECKING TRANSACTIONS AROUND BUY TIMEFRAME:")
        extended_buy_start = buy_start - 30*60*1000  # 30 minutes before
        extended_buy_end = buy_end + 30*60*1000      # 30 minutes after
        
        extended_buy_df = df[(df['timestamp_unix'] >= extended_buy_start) & (df['timestamp_unix'] <= extended_buy_end)]
        print(f"   Transactions within ±30 minutes: {len(extended_buy_df)}")
        
        if len(extended_buy_df) > 0:
            print("   Sample transactions:")
            for _, row in extended_buy_df.head(5).iterrows():
                print(f"     {row['Human Time']} | {row['Action']} | From: {row['From'][:8]}...")
    
    # Filter by sell timeframe
    sell_df = df[(df['timestamp_unix'] >= sell_start) & (df['timestamp_unix'] <= sell_end)]
    print(f"\n💰 TRANSACTIONS IN SELL TIMEFRAME: {len(sell_df)}")
    
    if len(sell_df) > 0:
        print("📋 SELL TIMEFRAME TRANSACTIONS:")
        for _, row in sell_df.iterrows():
            print(f"   Time: {row['Human Time']} | Action: {row['Action']} | From: {row['From']}")
            print(f"   Token1: {row['Token1']} | Token2: {row['Token2']} | Value: ${row['Value']}")
            print()
    else:
        print("❌ No transactions found in sell timeframe")
        
        # Check transactions around the sell timeframe
        print("\n🔍 CHECKING TRANSACTIONS AROUND SELL TIMEFRAME:")
        extended_sell_start = sell_start - 30*60*1000  # 30 minutes before
        extended_sell_end = sell_end + 30*60*1000      # 30 minutes after
        
        extended_sell_df = df[(df['timestamp_unix'] >= extended_sell_start) & (df['timestamp_unix'] <= extended_sell_end)]
        print(f"   Transactions within ±30 minutes: {len(extended_sell_df)}")
        
        if len(extended_sell_df) > 0:
            print("   Sample transactions:")
            for _, row in extended_sell_df.head(5).iterrows():
                print(f"     {row['Human Time']} | {row['Action']} | From: {row['From'][:8]}...")
    
    # Show unique actions in the CSV
    print(f"\n📊 UNIQUE ACTIONS IN CSV:")
    unique_actions = df['Action'].unique()
    for action in unique_actions:
        count = len(df[df['Action'] == action])
        print(f"   {action}: {count} transactions")
    
    # Show token addresses
    neural_frog_token = "4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk"
    sol_address = "So11111111111111111111111111111111111111112"
    
    print(f"\n📊 TOKEN ANALYSIS:")
    token1_matches = len(df[df['Token1'] == neural_frog_token])
    token2_matches = len(df[df['Token2'] == neural_frog_token])
    
    print(f"   神经蛙 as Token1: {token1_matches} transactions")
    print(f"   神经蛙 as Token2: {token2_matches} transactions")
    
    sol_token1_matches = len(df[df['Token1'] == sol_address])
    sol_token2_matches = len(df[df['Token2'] == sol_address])
    
    print(f"   SOL as Token1: {sol_token1_matches} transactions")
    print(f"   SOL as Token2: {sol_token2_matches} transactions")

if __name__ == "__main__":
    main()

