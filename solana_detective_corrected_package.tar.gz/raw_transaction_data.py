#!/usr/bin/env python3
"""
Show raw transaction data to understand the correct fields
"""

import requests
import json

def main():
    # Configuration
    wallet_address = "CGU2AJLzf28QzRq3Lz4F3sGSZhKCxPnRHe6fG9MoXzfZ"
    token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    
    # Load API key
    with open('/home/ubuntu/config.json', 'r') as f:
        config = json.load(f)
        api_key = config['api_key']
    
    print(f"🔍 RAW TRANSACTION DATA ANALYSIS")
    print("=" * 60)
    print(f"📊 Wallet: {wallet_address}")
    print(f"🎯 Token: {token_address}")
    
    # Get trades for this wallet and token
    url = f"https://data.solanatracker.io/trades/{token_address}/by-wallet/{wallet_address}"
    headers = {"x-api-key": api_key}
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            
            if 'trades' in data and data['trades']:
                trades = data['trades']
                print(f"📊 Total trades found: {len(trades)}")
                
                # Filter for buy transactions
                buy_trades = [trade for trade in trades if trade.get('type') == 'buy']
                print(f"🛒 Buy transactions: {len(buy_trades)}")
                
                # Show first 3 buy transactions in detail
                print(f"\n📋 FIRST 3 BUY TRANSACTIONS (RAW DATA):")
                for i, trade in enumerate(buy_trades[:3], 1):
                    print(f"\n--- BUY TRANSACTION {i} ---")
                    for key, value in trade.items():
                        print(f"{key}: {value}")
                
                # Show all available fields
                if buy_trades:
                    print(f"\n📊 AVAILABLE FIELDS IN BUY TRANSACTIONS:")
                    sample_trade = buy_trades[0]
                    for key in sample_trade.keys():
                        print(f"   - {key}")
                
                # Try different interpretations
                print(f"\n🔍 DIFFERENT INTERPRETATIONS OF 'SOL VALUE':")
                
                total_volume = sum([float(trade.get('volume', 0)) for trade in buy_trades])
                total_amount = sum([float(trade.get('amount', 0)) for trade in buy_trades])
                total_price_usd = sum([float(trade.get('priceUsd', 0)) for trade in buy_trades])
                
                print(f"   Sum of 'volume' field: {total_volume:.6f}")
                print(f"   Sum of 'amount' field: {total_amount:.6f}")
                print(f"   Sum of 'priceUsd' field: ${total_price_usd:.6f}")
                
                # Check if there are other relevant fields
                sample_keys = list(buy_trades[0].keys())
                sol_related_keys = [key for key in sample_keys if 'sol' in key.lower() or 'price' in key.lower() or 'value' in key.lower()]
                
                if sol_related_keys:
                    print(f"\n🎯 SOL/PRICE/VALUE RELATED FIELDS:")
                    for key in sol_related_keys:
                        total_for_key = sum([float(trade.get(key, 0)) for trade in buy_trades])
                        print(f"   Sum of '{key}' field: {total_for_key:.6f}")
                
            else:
                print("❌ No trades found for this wallet and token combination")
                
        else:
            print(f"❌ API Error {response.status_code}: {response.text}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()

