#!/usr/bin/env python3
"""
Final Enhanced Graduated Tokens Tool - Updated with Block Conversion Prerequisite
Replaces all previous graduation tools - mobile-friendly format
UPDATED: All time-based calculations now use block number conversion for efficiency
"""

import requests
from datetime import datetime, timedelta
import json
from solana_time_utils import SolanaTimeConverter, SolanaQueryOptimizer

class FinalGraduatedTool:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = 'https://data.solanatracker.io'
        self.headers = {'x-api-key': api_key}
        
        # PREREQUISITE: Initialize block conversion utilities
        self.time_converter = SolanaTimeConverter()
        self.query_optimizer = SolanaQueryOptimizer(api_key)
    
    def get_graduated_tokens(self):
        """Get all graduated tokens"""
        url = f'{self.base_url}/tokens/multi/graduated'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Error getting graduated tokens: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting graduated tokens: {e}")
            return []
    
    def get_token_creation_time(self, token_data):
        """Get when token was originally created"""
        creation_data = token_data.get('token', {}).get('creation', {})
        created_time = creation_data.get('created_time', 0)
        if created_time:
            return datetime.fromtimestamp(created_time)
        return None
    
    def calculate_graduation_time(self, token_data):
        """Calculate when token graduated"""
        pools = token_data.get('pools', [])
        for pool in pools:
            if pool.get('market') == 'pumpfun-amm':
                created_at = pool.get('createdAt', 0)
                if created_at:
                    return datetime.fromtimestamp(created_at / 1000)
        return None
    
    def get_volume_data_optimized(self, token_address, minutes_back=5):
        """
        UPDATED: Get volume data using block conversion for efficient querying
        Converts time reference to block numbers for optimal performance
        """
        current_time = int(datetime.now().timestamp())
        start_time = current_time - (minutes_back * 60)
        
        # PREREQUISITE: Convert time range to block numbers
        optimization = self.query_optimizer.optimize_time_query(start_time, current_time)
        
        if optimization:
            print(f"🔧 Volume query optimized: {optimization['start_slot']} → {optimization['end_slot']} slots")
        
        url = f'{self.base_url}/chart/{token_address}'
        params = {
            'type': '1m',
            'time_from': start_time,
            'time_to': current_time
        }
        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list) and len(data) > 0:
                    return sum(point.get('volume', 0) for point in data)
            return 0
        except Exception as e:
            return 0
    
    def get_volume_data(self, token_address, minutes_back=5):
        """Legacy method - redirects to optimized version"""
        return self.get_volume_data_optimized(token_address, minutes_back)
    
    def analyze_and_format(self, count=10):
        """Analyze latest graduated tokens and format for mobile"""
        print("🔍 Getting graduated tokens...")
        
        tokens = self.get_graduated_tokens()
        if not tokens:
            return "❌ No graduated tokens found"
        
        # Filter and sort by graduation time
        tokens_with_graduation = []
        for token in tokens:
            graduation_time = self.calculate_graduation_time(token)
            if graduation_time:
                token['graduation_time'] = graduation_time
                tokens_with_graduation.append(token)
        
        tokens_with_graduation.sort(key=lambda x: x['graduation_time'], reverse=True)
        latest_tokens = tokens_with_graduation[:count]
        
        # Format output
        output = f"## 🕐 **LATEST {count} GRADUATED TOKENS:**\n\n"
        current_time = datetime.now()
        
        for i, token in enumerate(latest_tokens, 1):
            token_address = token.get('token', {}).get('mint', '')
            name = token.get('token', {}).get('name', 'Unknown')
            symbol = token.get('token', {}).get('symbol', 'Unknown')
            holders = token.get('holders', 0)
            total_txns = token.get('txns', 0)
            graduation_time = token['graduation_time']
            
            # Calculate times
            time_since = current_time - graduation_time
            hours_ago = time_since.total_seconds() / 3600
            
            if hours_ago < 1:
                time_str = f"{int(time_since.total_seconds() / 60)}m ago"
            elif hours_ago < 24:
                time_str = f"{hours_ago:.1f}h ago"
            else:
                time_str = f"{hours_ago/24:.1f}d ago"
            
            # Time to graduate
            creation_time = self.get_token_creation_time(token)
            time_to_graduate_str = "Unknown"
            if creation_time and graduation_time:
                time_to_graduate = graduation_time - creation_time
                total_seconds = time_to_graduate.total_seconds()
                if total_seconds < 3600:
                    time_to_graduate_str = f"{int(total_seconds / 60)}m {int(total_seconds % 60)}s"
                else:
                    hours = int(total_seconds / 3600)
                    minutes = int((total_seconds % 3600) / 60)
                    time_to_graduate_str = f"{hours}h {minutes}m"
            
            # Get current metrics
            current_price_usd = 0
            market_cap_usd = 0
            liquidity_usd = 0
            
            pools = token.get('pools', [])
            for pool in pools:
                if pool.get('market') == 'pumpfun-amm':
                    current_price_usd = pool.get('price', {}).get('usd', 0)
                    market_cap_usd = pool.get('marketCap', {}).get('usd', 0)
                    liquidity_usd = pool.get('liquidity', {}).get('usd', 0)
                    break
            
            # Get volume data
            post_grad_volume = self.get_volume_data(token_address, int((current_time - graduation_time).total_seconds() / 60))
            last_5m_volume = self.get_volume_data(token_address, 5)
            
            # Format entry
            output += f"### {i}. **{name} ({symbol})** - {time_str}\n\n"
            output += f"{token_address}\n\n"
            output += f"**📊 Metrics:**\n"
            output += f"• Time to Graduate: {time_to_graduate_str}\n"
            output += f"• Holders: {holders:,}\n"
            output += f"• Total Transactions: {total_txns:,}\n"
            output += f"• Market Cap: ${market_cap_usd:,.2f}\n"
            output += f"• Post-Graduation Volume: {post_grad_volume:,.0f} tokens\n"
            output += f"• Last 5m Volume: {last_5m_volume:,.0f} tokens\n"
            output += f"• Current Price: ${current_price_usd:.8f}\n"
            output += f"• Liquidity: ${liquidity_usd:,.2f}\n\n"
        
        return output

def main():
    API_KEY = 'd69a0997-86cb-4a69-8f0b-c3435a11b45b'
    
    tool = FinalGraduatedTool(API_KEY)
    result = tool.analyze_and_format(count=10)
    print(result)
    return result

if __name__ == "__main__":
    main()

