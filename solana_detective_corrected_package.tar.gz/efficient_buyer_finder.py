#!/usr/bin/env python3
"""
Efficient Buyer Finder - Updated with Block Number Conversion Prerequisite
Automatically converts any time-based requests to block number queries for maximum efficiency
"""

import requests
import json
from datetime import datetime, timezone
import pytz
import time
from solana_time_utils import convert_est_timeframe_to_optimized_query, get_buyers_in_timeframe, SolanaTimeConverter

def find_buyers_with_block_optimization():
    """
    UPDATED: Uses block number conversion prerequisite for efficient querying
    Automatically converts time references to block numbers
    """
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    token_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    min_volume = 140
    
    print(f"⚡ BLOCK-OPTIMIZED VERSION - Using block number conversion prerequisite")
    print(f"🔍 Token: {token_address}")
    print(f"⏰ Target: 3:00-3:10pm EST (June 25, 2025)")
    print(f"💰 Minimum: ${min_volume}")
    print("=" * 70)
    
    # PREREQUISITE: Convert time reference to optimized query parameters
    print("🔧 STEP 1: Converting time reference to block numbers...")
    
    # Get current date for "today" reference
    est = pytz.timezone('US/Eastern')
    today = datetime.now(est).date()
    
    query_params = convert_est_timeframe_to_optimized_query(
        year=today.year, month=today.month, day=today.day,
        start_hour=15, start_min=0, start_sec=0,  # 3:00pm EST
        end_hour=15, end_min=10, end_sec=0,       # 3:10pm EST
        api_key=api_key
    )
    
    start_timestamp = query_params['start_timestamp']
    end_timestamp = query_params['end_timestamp']
    
    print(f"✅ Time converted to block-optimized parameters")
    print()
    
    # STEP 2: Use optimized buyer finder with volume filtering
    print("⚡ STEP 2: Getting buyers using block-optimized querying...")
    
    buyers = get_buyers_in_timeframe(
        token_address=token_address,
        start_timestamp=start_timestamp,
        end_timestamp=end_timestamp,
        api_key=api_key,
        min_volume=min_volume
    )
    
    # STEP 3: Display results
    print(f"\n🎯 RESULTS:")
    print(f"✅ Found {len(buyers)} buyers with volume ≥ ${min_volume}")
    
    if buyers:
        print(f"\n📋 HIGH-VOLUME BUYERS:")
        for i, buyer in enumerate(buyers, 1):
            trade_time = datetime.fromtimestamp(buyer['time'], tz=est)
            print(f"\n{i}. {buyer['wallet']}")
            print(f"   Time: {trade_time.strftime('%H:%M:%S')} EST")
            print(f"   Volume: ${buyer['volume']:.2f}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for buyer in buyers:
            print(buyer['wallet'])
    else:
        print("❌ No high-volume buyers found in the specified timeframe")

def find_buyers_relative_time(relative_time_str, token_address, min_volume=0, api_key="d69a0997-86cb-4a69-8f0b-c3435a11b45b"):
    """
    NEW: Handle relative time references like "last 10 minutes", "yesterday at same time"
    Automatically converts to block numbers for efficient querying
    """
    print(f"⚡ RELATIVE TIME QUERY - Converting '{relative_time_str}' to block numbers")
    
    converter = SolanaTimeConverter()
    current_time = int(time.time())
    
    # Parse relative time references
    if "last" in relative_time_str.lower() and "minute" in relative_time_str.lower():
        # Extract minutes from "last X minutes"
        import re
        minutes = int(re.search(r'(\d+)', relative_time_str).group(1))
        start_timestamp = current_time - (minutes * 60)
        end_timestamp = current_time
        
    elif "yesterday" in relative_time_str.lower():
        # Yesterday at same time
        start_timestamp = current_time - (24 * 60 * 60)
        end_timestamp = start_timestamp + (10 * 60)  # 10 minute window
        
    elif "hour" in relative_time_str.lower() and "ago" in relative_time_str.lower():
        # X hours ago
        import re
        hours = int(re.search(r'(\d+)', relative_time_str).group(1))
        start_timestamp = current_time - (hours * 60 * 60)
        end_timestamp = start_timestamp + (10 * 60)  # 10 minute window
        
    else:
        print(f"❌ Unsupported relative time format: {relative_time_str}")
        return []
    
    # Convert to block numbers and execute optimized query
    print(f"🔧 Converting timeframe to block numbers...")
    optimization = converter.timestamp_to_slot(start_timestamp)
    
    if optimization:
        print(f"✅ Converted to block range for efficient querying")
        
        buyers = get_buyers_in_timeframe(
            token_address=token_address,
            start_timestamp=start_timestamp,
            end_timestamp=end_timestamp,
            api_key=api_key,
            min_volume=min_volume
        )
        
        return buyers
    else:
        print(f"❌ Failed to convert to block numbers")
        return []

if __name__ == "__main__":
    print("🔧 EFFICIENT BUYER FINDER - Updated with Block Conversion Prerequisite")
    print("=" * 70)
    
    # Test 1: Standard time window query
    print("\n📊 TEST 1: Standard time window (3:00-3:10pm EST)")
    find_buyers_with_block_optimization()
    
    # Test 2: Relative time queries
    print("\n📊 TEST 2: Relative time queries")
    
    # Example relative time queries
    test_queries = [
        "last 10 minutes",
        "last 30 minutes", 
        "2 hours ago",
        "yesterday at same time"
    ]
    
    token_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    
    for query in test_queries:
        print(f"\n🔍 Testing: '{query}'")
        buyers = find_buyers_relative_time(query, token_address, min_volume=100)
        print(f"   Result: {len(buyers)} buyers found")
        
    print("\n✅ All time-based queries now use block number conversion prerequisite!")

