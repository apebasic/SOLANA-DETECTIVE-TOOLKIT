#!/usr/bin/env python3
"""
Find wallets that bought ALL specified tokens
Uses cross-token overlap analysis with block conversion prerequisite
"""

import requests
import json
from collections import defaultdict, Counter
from solana_time_utils import SolanaTimeConverter, SolanaQueryOptimizer

def find_wallets_bought_all_tokens():
    """Find wallets that bought ALL of the specified tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    # List of tokens to analyze
    tokens = [
        "qfyhNU2WmMAT1P5kc3isJNBKRpHec3ZLiLWxn38pump",
        "DFVeSFxNohR5CVuReaXSz6rGuJ62LsKhxFpWsDbbjups", 
        "EoD6LKTTpkLjpWaf9Dyemo7C4qEzsxWjPqCRa76apump",
        "8CDe8CVX74r3mEpcr2LsGGrNoGdJFt4uSYWyGfKUpump",
        "4dmQFkCM1WiUhC75UndLkmMtWj78fQJUvfc4xpMLpump",
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump"
    ]
    
    print(f"🔍 CROSS-TOKEN ANALYSIS: Finding wallets that bought ALL {len(tokens)} tokens")
    print("=" * 80)
    
    # Step 1: Get first buyers for each token
    all_buyers = defaultdict(set)  # wallet -> set of tokens they bought
    token_buyers = {}  # token -> list of buyers
    
    for i, token in enumerate(tokens, 1):
        print(f"\n📊 {i}/{len(tokens)} Getting first buyers for token:")
        print(f"   {token}")
        
        try:
            url = f'{base_url}/first-buyers/{token}'
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                buyers = response.json()
                if isinstance(buyers, list):
                    print(f"   ✅ Found {len(buyers)} first buyers")
                    
                    token_buyers[token] = buyers
                    
                    # Track which tokens each wallet bought
                    for buyer in buyers:
                        wallet = buyer.get('wallet')
                        if wallet:
                            all_buyers[wallet].add(token)
                else:
                    print(f"   ❌ Unexpected response format")
                    token_buyers[token] = []
            else:
                print(f"   ❌ Error: {response.text}")
                token_buyers[token] = []
                
        except Exception as e:
            print(f"   ❌ Exception: {e}")
            token_buyers[token] = []
    
    # Step 2: Find wallets that bought ALL tokens
    print(f"\n🎯 ANALYSIS RESULTS:")
    print("=" * 50)
    
    wallets_bought_all = []
    for wallet, tokens_bought in all_buyers.items():
        if len(tokens_bought) == len(tokens):  # Bought ALL tokens
            wallets_bought_all.append(wallet)
    
    print(f"✅ Found {len(wallets_bought_all)} wallets that bought ALL {len(tokens)} tokens")
    
    if wallets_bought_all:
        print(f"\n📋 WALLET ADDRESSES THAT BOUGHT ALL TOKENS:")
        for i, wallet in enumerate(wallets_bought_all, 1):
            print(f"\n{i}. {wallet}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for wallet in wallets_bought_all:
            print(wallet)
            
        # Additional analysis
        print(f"\n📊 DETAILED ANALYSIS:")
        for wallet in wallets_bought_all:
            print(f"\n🔍 Wallet: {wallet}")
            print(f"   Tokens bought: {len(all_buyers[wallet])}/{len(tokens)}")
            
            # Show timing info if available
            wallet_activities = []
            for token in tokens:
                buyers_list = token_buyers.get(token, [])
                for buyer in buyers_list:
                    if buyer.get('wallet') == wallet:
                        wallet_activities.append({
                            'token': token[:8] + '...',
                            'timestamp': buyer.get('timestamp', 0),
                            'amount': buyer.get('amount', 0)
                        })
            
            if wallet_activities:
                wallet_activities.sort(key=lambda x: x['timestamp'])
                print(f"   First activity: Token {wallet_activities[0]['token']}")
                print(f"   Last activity: Token {wallet_activities[-1]['token']}")
    else:
        print(f"\n❌ No wallets found that bought ALL {len(tokens)} tokens")
        
        # Show distribution analysis
        print(f"\n📊 DISTRIBUTION ANALYSIS:")
        token_counts = Counter(len(tokens_bought) for tokens_bought in all_buyers.values())
        
        for count in sorted(token_counts.keys(), reverse=True):
            wallets_with_count = token_counts[count]
            print(f"   {wallets_with_count} wallets bought {count}/{len(tokens)} tokens")
            
            if count >= len(tokens) - 2:  # Show wallets that bought almost all
                print(f"   📋 Wallets that bought {count} tokens:")
                for wallet, tokens_bought in all_buyers.items():
                    if len(tokens_bought) == count:
                        print(f"      {wallet}")

if __name__ == "__main__":
    find_wallets_bought_all_tokens()
