# Solscan API Research Findings

## Account Transfer API
**Endpoint**: `https://pro-api.solscan.io/v2.0/account/transfer`

### Key Parameters for Our Use Case:
- `address` (required): Solana wallet address
- `token`: Filter by specific token address (can filter multiple with commas, max 5)
- `from_time` / `to_time`: Unix timestamp filtering for time ranges
- `flow`: Filter by direction ("in" or "out")
- `page` / `page_size`: Pagination (max 100 items per page)
- `sort_by`: "block_time" 
- `sort_order`: "asc" or "desc"

### Response Data:
- `block_id`: Block number
- `trans_id`: Transaction signature
- `block_time`: Unix timestamp
- `time`: ISO timestamp
- `activity_type`: Type of transfer (e.g., "ACTIVITY_SPL_TRANSFER")
- `from_address`: Sender wallet
- `to_address`: Recipient wallet
- `token_address`: Token contract address
- `token_decimals`: Token decimal places
- `amount`: Transfer amount (in smallest unit)
- `flow`: Direction ("in" or "out")

### Authentication:
- Requires API key in header
- Has rate limits and different pricing tiers

## Analysis Strategy:
1. For each KOL wallet + token combination:
   - Get all transfers for that token using the KOL's public wallet
   - Find the earliest transaction timestamp
   - Query all wallets that bought the same token BEFORE that timestamp
   - Cross-reference these "early buyer" wallets across multiple tokens
   - Identify wallets that consistently appear as early buyers across multiple tokens

## Additional APIs to Investigate:
- Account Transactions API (for more detailed transaction data)
- Token APIs (for token metadata and holder information)
- Public APIs (for free tier options)

