#!/usr/bin/env python3
"""
Comprehensive Solana Tracker API Documentation Scraper
Uses direct endpoint URLs to extract complete documentation
"""

import json
import time
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait

class ComprehensiveDocScraper:
    def __init__(self):
        self.setup_driver()
        self.base_url = "https://docs.solanatracker.io/public-data-api/docs"
        
        # All endpoint URLs based on the pattern you identified
        self.endpoint_urls = [
            # Token Endpoints
            f"{self.base_url}#get-tokenstokenaddress",
            f"{self.base_url}#get-tokensby-poolpooladdress", 
            f"{self.base_url}#get-tokenstokenaddressholders",
            f"{self.base_url}#get-tokenstokenaddressholderstop",
            f"{self.base_url}#get-tokenstokenaddressath",
            f"{self.base_url}#get-deployerwallet",
            f"{self.base_url}#get-search",
            f"{self.base_url}#get-tokenslatest",
            f"{self.base_url}#post-tokensmulti",
            f"{self.base_url}#get-tokenstrending",
            f"{self.base_url}#get-tokenstrendingtimeframe",
            f"{self.base_url}#get-tokensvolume",
            f"{self.base_url}#get-tokensvolumetimeframe",
            f"{self.base_url}#get-tokensmultiall",
            f"{self.base_url}#get-tokensmultigraduated",
            
            # Price Endpoints
            f"{self.base_url}#get-price",
            f"{self.base_url}#get-pricehistory",
            f"{self.base_url}#get-pricehistorytimestamp",
            f"{self.base_url}#get-pricehistoryrange",
            f"{self.base_url}#post-price",
            f"{self.base_url}#get-pricemulti",
            f"{self.base_url}#post-pricemulti",
            
            # Wallet Endpoints
            f"{self.base_url}#get-walletowner",
            f"{self.base_url}#get-walletownerbasic",
            f"{self.base_url}#get-walletownerpagepage",
            f"{self.base_url}#get-walletownertrades",
            f"{self.base_url}#get-walletownerchart",
            
            # Trade Endpoints
            f"{self.base_url}#get-tradestokenaddresspooladdress",
            f"{self.base_url}#get-tradestokenaddresspooladdressowner",
            f"{self.base_url}#get-tradestokenaddressby-walletowner",
            
            # Chart Data
            f"{self.base_url}#get-charttoken",
            f"{self.base_url}#get-charttokenpool",
            f"{self.base_url}#get-holderscharttoken",
            
            # PnL Data
            f"{self.base_url}#get-pnlwallet",
            f"{self.base_url}#get-first-buyerstoken",
            f"{self.base_url}#get-pnlwallettoken",
            
            # Top Traders
            f"{self.base_url}#get-top-tradersall",
            f"{self.base_url}#get-top-tradersallpage",
            f"{self.base_url}#get-top-traderstoken",
            
            # Stats and Events
            f"{self.base_url}#get-statstoken",
            f"{self.base_url}#get-statstokenpool",
            f"{self.base_url}#get-eventstokenaddress",
            f"{self.base_url}#get-eventstokenaddresspooladdress",
            
            # Credits
            f"{self.base_url}#get-credits"
        ]
        
        self.documentation = {
            "base_url": "https://data.solanatracker.io",
            "authentication": "x-api-key header",
            "endpoints": {}
        }
        
    def setup_driver(self):
        """Setup Chrome driver"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
    def extract_endpoint_documentation(self, url):
        """Extract documentation from a specific endpoint URL"""
        try:
            print(f"📖 Extracting: {url}")
            self.driver.get(url)
            time.sleep(3)
            
            # Get the page content
            page_content = self.driver.page_source
            
            # Extract the markdown content
            markdown_script = """
            return document.body.textContent;
            """
            
            text_content = self.driver.execute_script(markdown_script)
            
            # Parse the endpoint information
            endpoint_info = self.parse_endpoint_content(text_content, url)
            
            return endpoint_info
            
        except Exception as e:
            print(f"❌ Error extracting {url}: {str(e)}")
            return None
            
    def parse_endpoint_content(self, content, url):
        """Parse the content to extract endpoint information"""
        lines = content.split('\n')
        
        endpoint_info = {
            "url": url,
            "method": "",
            "path": "",
            "description": "",
            "parameters": [],
            "response_format": "",
            "example_response": ""
        }
        
        # Extract method and path from URL fragment
        fragment = url.split('#')[-1] if '#' in url else ""
        
        if fragment.startswith('get-'):
            endpoint_info["method"] = "GET"
            # Convert URL fragment back to path
            path = fragment.replace('get-', '/').replace('post-', '/')
            # Handle special cases
            path = path.replace('tokenstokenaddress', 'tokens/{tokenAddress}')
            path = path.replace('tokensby-poolpooladdress', 'tokens/by-pool/{poolAddress}')
            path = path.replace('deployerwallet', 'deployer/{wallet}')
            path = path.replace('walletowner', 'wallet/{owner}')
            path = path.replace('tradestokenaddresspooladdress', 'trades/{tokenAddress}/{poolAddress}')
            path = path.replace('charttoken', 'chart/{token}')
            path = path.replace('pnlwallet', 'pnl/{wallet}')
            path = path.replace('first-buyerstoken', 'first-buyers/{token}')
            path = path.replace('top-tradersall', 'top-traders/all')
            path = path.replace('statstoken', 'stats/{token}')
            path = path.replace('eventstokenaddress', 'events/{tokenAddress}')
            
            endpoint_info["path"] = path
            
        elif fragment.startswith('post-'):
            endpoint_info["method"] = "POST"
            path = fragment.replace('post-', '/')
            path = path.replace('tokensmulti', 'tokens/multi')
            path = path.replace('pricemulti', 'price/multi')
            endpoint_info["path"] = path
            
        # Extract description and response from content
        in_response = False
        response_lines = []
        
        for line in lines:
            line = line.strip()
            
            # Look for description
            if "Retrieves" in line or "Gets" in line or "Returns" in line:
                endpoint_info["description"] = line
                
            # Look for Response section
            if line == "Response":
                in_response = True
                response_lines = []
                continue
                
            # Collect response JSON
            if in_response and line.startswith('{'):
                response_lines.append(line)
                
            # Stop at next section
            if in_response and (line.startswith('GET ') or line.startswith('POST ') or 
                              line in ['Parameters', 'Request', 'Example'] or
                              line.startswith('###')):
                in_response = False
                
        # Join response lines
        if response_lines:
            endpoint_info["example_response"] = '\n'.join(response_lines)
            
        return endpoint_info
        
    def run_comprehensive_extraction(self):
        """Run extraction for all endpoints"""
        print("🚀 Starting comprehensive documentation extraction...")
        print(f"📊 Total endpoints to process: {len(self.endpoint_urls)}")
        
        successful_extractions = 0
        
        for i, url in enumerate(self.endpoint_urls, 1):
            print(f"\n📈 Progress: {i}/{len(self.endpoint_urls)}")
            
            try:
                endpoint_info = self.extract_endpoint_documentation(url)
                
                if endpoint_info and endpoint_info["path"]:
                    self.documentation["endpoints"][endpoint_info["path"]] = endpoint_info
                    successful_extractions += 1
                    print(f"✅ Successfully extracted: {endpoint_info['method']} {endpoint_info['path']}")
                else:
                    print(f"⚠️  No valid data extracted from {url}")
                    
            except Exception as e:
                print(f"❌ Failed to process {url}: {str(e)}")
                continue
                
            # Small delay between requests
            time.sleep(2)
            
        print(f"\n🎉 Extraction completed!")
        print(f"📈 Successfully extracted {successful_extractions}/{len(self.endpoint_urls)} endpoints")
        
        # Save results
        self.save_documentation()
        self.generate_markdown()
        
    def save_documentation(self):
        """Save documentation to JSON file"""
        with open('complete_solana_api_docs.json', 'w', encoding='utf-8') as f:
            json.dump(self.documentation, f, indent=2, ensure_ascii=False)
        print("💾 JSON documentation saved!")
        
    def generate_markdown(self):
        """Generate comprehensive markdown documentation"""
        print("📝 Generating comprehensive markdown documentation...")
        
        markdown = f"""# SOLANA TRACKER API - COMPLETE DOCUMENTATION

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}

## COMPREHENSIVE ENDPOINT DOCUMENTATION ({len(self.documentation['endpoints'])} endpoints)

"""
        
        # Group endpoints by category
        categories = {
            "Token Endpoints": [],
            "Price Endpoints": [],
            "Wallet Endpoints": [],
            "Trade Endpoints": [],
            "Chart Data": [],
            "PnL Data": [],
            "Top Traders": [],
            "Stats and Events": [],
            "Credits": []
        }
        
        for path, endpoint in self.documentation['endpoints'].items():
            if path.startswith('/tokens'):
                categories["Token Endpoints"].append(endpoint)
            elif path.startswith('/price'):
                categories["Price Endpoints"].append(endpoint)
            elif path.startswith('/wallet'):
                categories["Wallet Endpoints"].append(endpoint)
            elif path.startswith('/trades'):
                categories["Trade Endpoints"].append(endpoint)
            elif path.startswith('/chart') or path.startswith('/holders'):
                categories["Chart Data"].append(endpoint)
            elif path.startswith('/pnl') or path.startswith('/first-buyers'):
                categories["PnL Data"].append(endpoint)
            elif path.startswith('/top-traders'):
                categories["Top Traders"].append(endpoint)
            elif path.startswith('/stats') or path.startswith('/events'):
                categories["Stats and Events"].append(endpoint)
            elif path.startswith('/credits'):
                categories["Credits"].append(endpoint)
                
        # Generate documentation by category
        for category, endpoints in categories.items():
            if endpoints:
                markdown += f"## {category}\n\n"
                
                for endpoint in endpoints:
                    markdown += f"### {endpoint['method']} {endpoint['path']}\n\n"
                    
                    if endpoint.get('description'):
                        markdown += f"**Description**: {endpoint['description']}\n\n"
                        
                    if endpoint.get('example_response'):
                        markdown += f"**Response Example**:\n```json\n{endpoint['example_response']}\n```\n\n"
                        
                    markdown += "---\n\n"
                    
        with open('COMPLETE_SOLANA_TRACKER_API_DOCS.md', 'w', encoding='utf-8') as f:
            f.write(markdown)
            
        print("✅ Comprehensive markdown documentation generated!")
        
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            
    def run(self):
        """Run the complete process"""
        try:
            self.run_comprehensive_extraction()
        except Exception as e:
            print(f"❌ Process failed: {str(e)}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("🤖 Comprehensive Solana Tracker API Documentation Scraper")
    print("=" * 70)
    
    scraper = ComprehensiveDocScraper()
    scraper.run()
    
    print("\n🎉 Complete documentation extraction finished!")

