#!/usr/bin/env python3
"""
Test script for KOL Alt Wallet Detection Tool

This script tests the core functionality without requiring API calls.
"""

import json
from kol_alt_detector import KOLAltWalletDetector, TokenPurchase, SuspiciousWallet
from datetime import datetime
import time

def test_configuration():
    """Test configuration loading"""
    print("Testing configuration loading...")
    
    # Test with default config
    detector = KOLAltWalletDetector("dummy_api_key")
    assert detector.config["min_frequency"] == 2
    assert detector.config["min_consistency"] == 0.3
    print("✓ Default configuration loaded correctly")
    
    # Test with custom config
    custom_config = {"min_frequency": 3, "min_consistency": 0.5}
    detector = KOLAltWalletDetector("dummy_api_key", custom_config)
    assert detector.config["min_frequency"] == 3
    assert detector.config["min_consistency"] == 0.5
    print("✓ Custom configuration loaded correctly")

def test_data_structures():
    """Test data structure creation"""
    print("\nTesting data structures...")
    
    # Test TokenPurchase
    purchase = TokenPurchase(
        token_address="test_token",
        wallet_address="test_wallet",
        timestamp=int(time.time()),
        amount=100.0,
        transaction_id="test_tx",
        block_time="2024-01-01T00:00:00.000Z"
    )
    assert purchase.token_address == "test_token"
    assert purchase.amount == 100.0
    print("✓ TokenPurchase data structure works correctly")
    
    # Test SuspiciousWallet
    suspicious = SuspiciousWallet(
        wallet_address="suspicious_wallet",
        suspicion_score=0.85,
        tokens_bought_early=3,
        consistency_rate=0.75,
        avg_time_advantage_hours=12.5,
        total_early_volume=1000.0,
        token_details=[]
    )
    assert suspicious.suspicion_score == 0.85
    assert suspicious.tokens_bought_early == 3
    print("✓ SuspiciousWallet data structure works correctly")

def test_scoring_logic():
    """Test the scoring algorithm logic"""
    print("\nTesting scoring logic...")
    
    detector = KOLAltWalletDetector("dummy_api_key")
    
    # Test scoring calculation
    frequency_weight = detector.config["frequency_weight"]
    timing_weight = detector.config["timing_weight"]
    volume_weight = detector.config["volume_weight"]
    
    # Simulate a high-suspicion scenario
    consistency_rate = 0.8  # 80% of tokens
    time_advantage_normalized = 0.5  # 12 hours normalized to 0.5
    volume_normalized = 0.3  # Some volume
    
    expected_score = (
        frequency_weight * consistency_rate +
        timing_weight * time_advantage_normalized +
        volume_weight * volume_normalized
    )
    
    calculated_score = (
        detector.config["frequency_weight"] * consistency_rate +
        detector.config["timing_weight"] * time_advantage_normalized +
        detector.config["volume_weight"] * volume_normalized
    )
    
    assert abs(calculated_score - expected_score) < 0.001
    print(f"✓ Scoring logic works correctly (score: {calculated_score:.3f})")

def test_file_operations():
    """Test file reading and writing"""
    print("\nTesting file operations...")
    
    # Test config file reading
    try:
        with open("config.json", 'r') as f:
            config = json.load(f)
        assert "min_frequency" in config
        assert "min_consistency" in config
        print("✓ Configuration file reading works")
    except Exception as e:
        print(f"✗ Configuration file reading failed: {e}")
    
    # Test results writing
    test_results = {
        "analysis_summary": {
            "kol_wallet": "test_wallet",
            "tokens_analyzed": 2,
            "suspicious_wallets_found": 1
        },
        "suspicious_wallets": [
            {
                "wallet_address": "test_suspicious",
                "suspicion_score": 0.75
            }
        ]
    }
    
    try:
        with open("test_results.json", 'w') as f:
            json.dump(test_results, f, indent=2)
        
        # Verify it can be read back
        with open("test_results.json", 'r') as f:
            loaded_results = json.load(f)
        
        assert loaded_results["analysis_summary"]["kol_wallet"] == "test_wallet"
        print("✓ Results file writing and reading works")
        
        # Clean up
        import os
        os.remove("test_results.json")
        
    except Exception as e:
        print(f"✗ Results file operations failed: {e}")

def test_input_validation():
    """Test input validation"""
    print("\nTesting input validation...")
    
    # Test empty inputs
    try:
        detector = KOLAltWalletDetector("")
        print("✗ Should have failed with empty API key")
    except:
        print("✓ Empty API key properly rejected")
    
    # Test valid initialization
    try:
        detector = KOLAltWalletDetector("valid_api_key")
        print("✓ Valid API key accepted")
    except Exception as e:
        print(f"✗ Valid API key rejected: {e}")

def run_all_tests():
    """Run all tests"""
    print("=== KOL Alt Wallet Detection Tool - Test Suite ===")
    print()
    
    try:
        test_configuration()
        test_data_structures()
        test_scoring_logic()
        test_file_operations()
        test_input_validation()
        
        print("\n" + "="*50)
        print("ALL TESTS PASSED! ✓")
        print("="*50)
        print("\nThe tool is ready to use with a valid Solscan Pro API key.")
        print("Run 'python3 interactive_detector.py' to start the analysis.")
        
    except Exception as e:
        print(f"\n✗ TEST FAILED: {e}")
        print("Please check the implementation and try again.")

if __name__ == "__main__":
    run_all_tests()

