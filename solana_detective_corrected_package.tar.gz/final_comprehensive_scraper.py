#!/usr/bin/env python3
"""
Final Comprehensive Solana Tracker API Documentation Scraper
Extracts complete documentation for all 47 endpoints with full specifications
"""

import json
import time
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By

class FinalComprehensiveScraper:
    def __init__(self):
        self.setup_driver()
        self.base_url = "https://docs.solanatracker.io/public-data-api/docs"
        
        # Complete inventory of all 47 endpoints with CORRECTED URL patterns
        self.endpoints = {
            # Token Endpoints (15)
            "GET /tokens/{tokenAddress}": f"{self.base_url}#get-tokenstokenaddress",
            "GET /tokens/by-pool/{poolAddress}": f"{self.base_url}#get-tokensbypoolpooladdress",
            "GET /tokens/{tokenAddress}/holders": f"{self.base_url}#get-tokenstokenaddressholders",
            "GET /tokens/{tokenAddress}/holders/top": f"{self.base_url}#get-tokenstokenaddressholderstop",
            "GET /tokens/{tokenAddress}/ath": f"{self.base_url}#get-tokenstokenaddressath",
            "GET /deployer/{wallet}": f"{self.base_url}#get-deployerwallet",
            "GET /search": f"{self.base_url}#get-search",
            "GET /tokens/latest": f"{self.base_url}#get-tokenslatest",
            "POST /tokens/multi": f"{self.base_url}#post-tokensmulti",
            "GET /tokens/trending": f"{self.base_url}#get-tokenstrending",
            "GET /tokens/trending/{timeframe}": f"{self.base_url}#get-tokenstrendingtimeframe",
            "GET /tokens/volume": f"{self.base_url}#get-tokensvolume",
            "GET /tokens/volume/{timeframe}": f"{self.base_url}#get-tokensvolumetimeframe",
            "GET /tokens/multi/all": f"{self.base_url}#get-tokensmultiall",
            "GET /tokens/multi/graduated": f"{self.base_url}#get-tokensmultigraduated",
            
            # Price Endpoints (7)
            "GET /price": f"{self.base_url}#get-price",
            "GET /price/history": f"{self.base_url}#get-pricehistory",
            "GET /price/history/timestamp": f"{self.base_url}#get-pricehistorytimestamp",
            "GET /price/history/range": f"{self.base_url}#get-pricehistoryrange",
            "POST /price": f"{self.base_url}#post-price",
            "GET /price/multi": f"{self.base_url}#get-pricemulti",
            "POST /price/multi": f"{self.base_url}#post-pricemulti",
            
            # Wallet Endpoints (5)
            "GET /wallet/{owner}": f"{self.base_url}#get-walletowner",
            "GET /wallet/{owner}/basic": f"{self.base_url}#get-walletownerbasic",
            "GET /wallet/{owner}/page/{page}": f"{self.base_url}#get-walletownerpagepage",
            "GET /wallet/{owner}/trades": f"{self.base_url}#get-walletownertrades",
            "GET /wallet/{owner}/chart": f"{self.base_url}#get-walletownerchart",
            
            # Trade Endpoints (3)
            "GET /trades/{tokenAddress}/{poolAddress}": f"{self.base_url}#get-tradestokenaddresspooladdress",
            "GET /trades/{tokenAddress}/{poolAddress}/{owner}": f"{self.base_url}#get-tradestokenaddresspooladdressowner",
            "GET /trades/{tokenAddress}/by-wallet/{owner}": f"{self.base_url}#get-tradestokenaddressbywalletowner",
            
            # Chart Data (4)
            "GET /chart/{token}": f"{self.base_url}#get-charttoken",
            "GET /chart/{token}/{pool}": f"{self.base_url}#get-charttokenpool",
            "GET /holders/chart/{token}": f"{self.base_url}#get-holderscharttoken",
            
            # PnL Data (3)
            "GET /pnl/{wallet}": f"{self.base_url}#get-pnlwallet",
            "GET /first-buyers/{token}": f"{self.base_url}#get-firstbuyerstoken",
            "GET /pnl/{wallet}/{token}": f"{self.base_url}#get-pnlwallettoken",
            
            # Top Traders (4)
            "GET /top-traders/all": f"{self.base_url}#get-toptradersall",
            "GET /top-traders/all/{page}": f"{self.base_url}#get-toptradersallpage",
            "GET /top-traders/{token}": f"{self.base_url}#get-toptraderstoken",
            
            # Stats and Live Events (5)
            "GET /stats/{token}": f"{self.base_url}#get-statstoken",
            "GET /stats/{token}/{pool}": f"{self.base_url}#get-statstokenpool",
            "GET /events/{tokenAddress}": f"{self.base_url}#get-eventstokenaddress",
            "GET /events/{tokenAddress}/{poolAddress}": f"{self.base_url}#get-eventstokenaddresspooladdress",
            
            # Credits (1)
            "GET /credits": f"{self.base_url}#get-credits"
        }
        
        self.documentation = {
            "base_url": "https://data.solanatracker.io",
            "authentication": "x-api-key header required",
            "total_endpoints": len(self.endpoints),
            "extraction_timestamp": time.time(),
            "endpoints": {}
        }
        
    def setup_driver(self):
        """Setup Chrome driver with proper options"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 15)
        
    def extract_detailed_endpoint_documentation(self, endpoint_name, url):
        """Extract complete detailed documentation for a single endpoint"""
        try:
            print(f"📖 Extracting: {endpoint_name}")
            print(f"🔗 URL: {url}")
            
            self.driver.get(url)
            time.sleep(4)  # Allow page to fully load
            
            # Get all text content from the page
            page_text = self.driver.execute_script("return document.body.innerText;")
            
            # Initialize endpoint documentation structure
            endpoint_doc = {
                "endpoint": endpoint_name,
                "url": url,
                "method": endpoint_name.split()[0],
                "path": endpoint_name.split(" ", 1)[1] if " " in endpoint_name else "",
                "description": "",
                "query_parameters": [],
                "path_parameters": [],
                "request_body": None,
                "response_format": {},
                "example_response": "",
                "available_intervals": [],
                "notes": [],
                "pagination_supported": False,
                "authentication_required": True
            }
            
            # Split content into lines for processing
            lines = page_text.split('\n')
            
            # Extract description
            for i, line in enumerate(lines):
                line = line.strip()
                if any(keyword in line.lower() for keyword in ['gets ', 'retrieves ', 'returns ', 'provides ']):
                    if len(line) < 300 and not line.startswith('GET ') and not line.startswith('POST '):
                        endpoint_doc["description"] = line
                        break
            
            # Extract query parameters
            in_query_params = False
            in_response = False
            in_intervals = False
            response_json = []
            
            for i, line in enumerate(lines):
                line = line.strip()
                
                # Query Parameters section
                if line == "Query Parameters":
                    in_query_params = True
                    continue
                elif in_query_params and line in ["Response", "Request Body", "Available Intervals", ""]:
                    in_query_params = False
                elif in_query_params and line:
                    # Parse parameter: name (type): description
                    param_match = re.match(r'(\w+)\s*\(([^)]+)\):\s*(.+)', line)
                    if param_match:
                        param_name, param_type, param_desc = param_match.groups()
                        endpoint_doc["query_parameters"].append({
                            "name": param_name,
                            "type": param_type.strip(),
                            "description": param_desc.strip(),
                            "required": "optional" not in param_type.lower()
                        })
                
                # Available Intervals section (for chart endpoints)
                if line == "Available Intervals":
                    in_intervals = True
                    continue
                elif in_intervals and line.startswith("Note:"):
                    in_intervals = False
                elif in_intervals and line:
                    # Extract interval patterns like 1s, 5s, 1m, 1h, etc.
                    intervals = re.findall(r'\b\d+[smhdw]|\d+mn\b', line)
                    endpoint_doc["available_intervals"].extend(intervals)
                
                # Response section
                if line == "Response":
                    in_response = True
                    response_json = []
                    continue
                elif in_response and line.startswith('{'):
                    response_json.append(line)
                    # Continue collecting JSON lines
                    for j in range(i+1, len(lines)):
                        next_line = lines[j].strip()
                        if next_line and (next_line.startswith('}') or '"' in next_line or next_line in ['{', '}', ']', '[']):
                            response_json.append(next_line)
                        elif next_line.startswith('GET ') or next_line.startswith('POST ') or next_line == "":
                            break
                    in_response = False
                    break
            
            # Process response JSON
            if response_json:
                endpoint_doc["example_response"] = '\n'.join(response_json)
                
            # Check for pagination
            page_lower = page_text.lower()
            if any(keyword in page_lower for keyword in ['cursor', 'page', 'pagination', 'nextcursor', 'hasnextpage']):
                endpoint_doc["pagination_supported"] = True
                
            # Extract path parameters from endpoint path
            path_params = re.findall(r'\{(\w+)\}', endpoint_doc["path"])
            for param in path_params:
                endpoint_doc["path_parameters"].append({
                    "name": param,
                    "type": "string",
                    "description": f"The {param} identifier",
                    "required": True
                })
            
            # Add notes for special cases
            if "chart" in endpoint_name.lower():
                endpoint_doc["notes"].append("OHLCV data endpoint with customizable time intervals")
            if "multi" in endpoint_name.lower():
                endpoint_doc["notes"].append("Batch endpoint for multiple items")
            if "pnl" in endpoint_name.lower():
                endpoint_doc["notes"].append("Profit and Loss calculation endpoint")
                
            return endpoint_doc
            
        except Exception as e:
            print(f"❌ Error extracting {endpoint_name}: {str(e)}")
            return None
            
    def run_final_comprehensive_extraction(self):
        """Run the final comprehensive extraction for all 47 endpoints"""
        print("🏭 FINAL COMPREHENSIVE Solana Tracker API Documentation Extraction")
        print("=" * 80)
        print(f"🚀 Starting extraction of ALL {len(self.endpoints)} endpoints...")
        print(f"📊 Target: Complete documentation with query parameters, intervals, and response formats")
        
        successful_extractions = 0
        failed_extractions = []
        
        for i, (endpoint_name, url) in enumerate(self.endpoints.items(), 1):
            print(f"\n📈 Progress: {i}/{len(self.endpoints)}")
            
            try:
                endpoint_doc = self.extract_detailed_endpoint_documentation(endpoint_name, url)
                
                if endpoint_doc:
                    self.documentation["endpoints"][endpoint_name] = endpoint_doc
                    successful_extractions += 1
                    
                    # Show extraction summary
                    params_count = len(endpoint_doc["query_parameters"])
                    intervals_count = len(endpoint_doc["available_intervals"])
                    has_response = bool(endpoint_doc["example_response"])
                    
                    print(f"✅ Extracted: {endpoint_name}")
                    print(f"   📋 Query Parameters: {params_count}")
                    print(f"   ⏱️  Available Intervals: {intervals_count}")
                    print(f"   📄 Response Example: {'Yes' if has_response else 'No'}")
                else:
                    failed_extractions.append(endpoint_name)
                    print(f"⚠️  Failed: {endpoint_name}")
                    
            except Exception as e:
                failed_extractions.append(endpoint_name)
                print(f"❌ Error processing {endpoint_name}: {str(e)}")
                continue
                
            # Delay between requests to be respectful
            time.sleep(3)
            
        print(f"\n🎉 Final extraction completed!")
        print(f"📈 Successfully extracted: {successful_extractions}/{len(self.endpoints)}")
        
        if failed_extractions:
            print(f"❌ Failed extractions: {len(failed_extractions)}")
            for failed in failed_extractions:
                print(f"   - {failed}")
        
        # Save and generate documentation
        self.save_final_documentation()
        self.generate_final_markdown()
        self.run_final_quality_control()
        
    def save_final_documentation(self):
        """Save final comprehensive documentation"""
        filename = 'FINAL_COMPLETE_SOLANA_API_DOCS.json'
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.documentation, f, indent=2, ensure_ascii=False)
        print(f"💾 Final documentation saved to: {filename}")
        
    def generate_final_markdown(self):
        """Generate final comprehensive markdown documentation"""
        print("📝 Generating final comprehensive markdown...")
        
        markdown = f"""# SOLANA TRACKER API - FINAL COMPREHENSIVE DOCUMENTATION

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}
**Total Endpoints**: {self.documentation['total_endpoints']}
**Extraction Date**: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.documentation['extraction_timestamp']))}

## COMPLETE API REFERENCE

"""
        
        # Group endpoints by category
        categories = {
            "Token Endpoints": [],
            "Price Endpoints": [],
            "Wallet Endpoints": [],
            "Trade Endpoints": [],
            "Chart Data Endpoints": [],
            "PnL Data Endpoints": [],
            "Top Traders Endpoints": [],
            "Stats and Events Endpoints": [],
            "Credits Endpoints": []
        }
        
        # Categorize endpoints
        for endpoint_name, endpoint_doc in self.documentation['endpoints'].items():
            path = endpoint_doc.get('path', '')
            
            if path.startswith('/tokens'):
                categories["Token Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/price'):
                categories["Price Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/wallet'):
                categories["Wallet Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/trades'):
                categories["Trade Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/chart') or path.startswith('/holders'):
                categories["Chart Data Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/pnl') or path.startswith('/first-buyers'):
                categories["PnL Data Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/top-traders'):
                categories["Top Traders Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/stats') or path.startswith('/events'):
                categories["Stats and Events Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/credits'):
                categories["Credits Endpoints"].append((endpoint_name, endpoint_doc))
                
        # Generate detailed documentation
        for category, endpoints in categories.items():
            if endpoints:
                markdown += f"## {category}\n\n"
                
                for endpoint_name, endpoint_doc in endpoints:
                    markdown += f"### {endpoint_name}\n\n"
                    
                    if endpoint_doc.get('description'):
                        markdown += f"**Description**: {endpoint_doc['description']}\n\n"
                        
                    # Path Parameters
                    if endpoint_doc.get('path_parameters'):
                        markdown += "**Path Parameters**:\n"
                        for param in endpoint_doc['path_parameters']:
                            required = " (required)" if param.get('required') else " (optional)"
                            markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                        markdown += "\n"
                        
                    # Query Parameters
                    if endpoint_doc.get('query_parameters'):
                        markdown += "**Query Parameters**:\n"
                        for param in endpoint_doc['query_parameters']:
                            required = " (required)" if param.get('required') else " (optional)"
                            markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                        markdown += "\n"
                        
                    # Available Intervals
                    if endpoint_doc.get('available_intervals'):
                        markdown += "**Available Intervals**: "
                        markdown += ", ".join(f"`{interval}`" for interval in endpoint_doc['available_intervals'])
                        markdown += "\n\n"
                        
                    # Pagination
                    if endpoint_doc.get('pagination_supported'):
                        markdown += "**Pagination**: Supported (cursor-based)\n\n"
                        
                    # Notes
                    if endpoint_doc.get('notes'):
                        markdown += "**Notes**:\n"
                        for note in endpoint_doc['notes']:
                            markdown += f"- {note}\n"
                        markdown += "\n"
                        
                    # Response Example
                    if endpoint_doc.get('example_response'):
                        markdown += f"**Response Example**:\n```json\n{endpoint_doc['example_response']}\n```\n\n"
                        
                    markdown += "---\n\n"
                    
        filename = 'FINAL_COMPLETE_SOLANA_TRACKER_API_DOCS.md'
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(markdown)
            
        print(f"✅ Final markdown documentation generated: {filename}")
        
    def run_final_quality_control(self):
        """Run comprehensive quality control"""
        print("\n🔍 Running Final Quality Control...")
        
        total_endpoints = len(self.endpoints)
        extracted_endpoints = len(self.documentation['endpoints'])
        
        print(f"📊 Endpoint Coverage: {extracted_endpoints}/{total_endpoints} ({extracted_endpoints/total_endpoints*100:.1f}%)")
        
        # Detailed quality metrics
        endpoints_with_descriptions = 0
        endpoints_with_parameters = 0
        endpoints_with_responses = 0
        endpoints_with_intervals = 0
        
        for endpoint_name, endpoint_doc in self.documentation['endpoints'].items():
            if endpoint_doc.get('description'):
                endpoints_with_descriptions += 1
            if endpoint_doc.get('query_parameters') or endpoint_doc.get('path_parameters'):
                endpoints_with_parameters += 1
            if endpoint_doc.get('example_response'):
                endpoints_with_responses += 1
            if endpoint_doc.get('available_intervals'):
                endpoints_with_intervals += 1
                
        print(f"📝 Endpoints with Descriptions: {endpoints_with_descriptions}/{extracted_endpoints}")
        print(f"🔧 Endpoints with Parameters: {endpoints_with_parameters}/{extracted_endpoints}")
        print(f"📄 Endpoints with Responses: {endpoints_with_responses}/{extracted_endpoints}")
        print(f"⏱️  Endpoints with Intervals: {endpoints_with_intervals}/{extracted_endpoints}")
        
        # Calculate quality score
        quality_score = (
            (extracted_endpoints / total_endpoints) * 0.4 +
            (endpoints_with_descriptions / extracted_endpoints) * 0.2 +
            (endpoints_with_parameters / extracted_endpoints) * 0.2 +
            (endpoints_with_responses / extracted_endpoints) * 0.2
        ) * 100
        
        print(f"🎯 Overall Quality Score: {quality_score:.1f}%")
        
        if quality_score >= 90:
            print("✅ EXCELLENT QUALITY - Production Ready!")
        elif quality_score >= 75:
            print("✅ GOOD QUALITY - Minor improvements needed")
        else:
            print("⚠️  NEEDS IMPROVEMENT - Review required")
            
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            
    def run(self):
        """Run the complete final extraction process"""
        try:
            self.run_final_comprehensive_extraction()
        except Exception as e:
            print(f"❌ Final extraction process failed: {str(e)}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("🏭 FINAL COMPREHENSIVE Solana Tracker API Documentation Scraper")
    print("📋 Extracting ALL 47 endpoints with complete specifications")
    print("=" * 80)
    
    scraper = FinalComprehensiveScraper()
    scraper.run()
    
    print("\n🎉 Final comprehensive documentation extraction completed!")
    print("📁 Check FINAL_COMPLETE_SOLANA_API_DOCS.json and .md files for results")

