#!/usr/bin/env python3
"""
CSV Timeframe Analyzer
Analyzes CSV files from Solscan to find wallets matching specific timeframes
"""

import pandas as pd
import json
from datetime import datetime, timezone
import pytz
from typing import Dict, List, Set, Tuple

class CSVTimeframeAnalyzer:
    def __init__(self):
        pass
    
    def utc_to_unix_timestamp(self, year: int, month: int, day: int, 
                             hour: int, minute: int, second: int = 0) -> int:
        """Convert UTC time to Unix timestamp"""
        dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)  # Convert to milliseconds
    
    def est_to_unix_timestamp(self, year: int, month: int, day: int, 
                             hour: int, minute: int, second: int = 0) -> int:
        """Convert EST time to Unix timestamp"""
        est = pytz.timezone('US/Eastern')
        dt = datetime(year, month, day, hour, minute, second)
        dt_est = est.localize(dt)
        return int(dt_est.timestamp() * 1000)  # Convert to milliseconds
    
    def parse_csv_timestamp(self, timestamp_str: str) -> int:
        """Parse CSV timestamp string to Unix timestamp"""
        # Parse ISO format: 2025-06-25T19:45:00.000Z
        dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        return int(dt.timestamp() * 1000)
    
    def determine_transaction_type(self, row: pd.Series, token_address: str) -> str:
        """
        Determine if transaction is buy or sell based on token flow
        Buy: SOL -> Token (user receives token)
        Sell: Token -> SOL (user receives SOL)
        """
        token1 = row['Token1']
        token2 = row['Token2']
        sol_address = "So11111111111111111111111111111111111111112"
        
        # Check if this is a token swap involving our target token
        if token1 == token_address and token2 == sol_address:
            # Token -> SOL = SELL
            return 'sell'
        elif token1 == sol_address and token2 == token_address:
            # SOL -> Token = BUY
            return 'buy'
        elif token1 == token_address or token2 == token_address:
            # Other token pairs - need to determine direction
            # For now, classify based on which position the target token is in
            if token1 == token_address:
                return 'sell'  # User is giving away the token
            else:
                return 'buy'   # User is receiving the token
        
        return 'unknown'
    
    def analyze_mortgage_csv(self, csv_path: str) -> Dict:
        """
        Analyze Mortgage token CSV for June 25, 19:30-19:45 UTC timeframe
        """
        print("🏠 ANALYZING MORTGAGE TOKEN CSV")
        print("=" * 50)
        
        # Read CSV
        df = pd.read_csv(csv_path)
        print(f"📊 Total transactions in CSV: {len(df)}")
        
        # Token address
        mortgage_token = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
        
        # Target timeframe: June 25, 19:30-19:45 UTC
        start_time = self.utc_to_unix_timestamp(2025, 6, 25, 19, 30, 0)
        end_time = self.utc_to_unix_timestamp(2025, 6, 25, 19, 45, 0)
        
        print(f"🕐 Target timeframe: {datetime.fromtimestamp(start_time/1000, tz=timezone.utc)} to {datetime.fromtimestamp(end_time/1000, tz=timezone.utc)}")
        
        # Parse timestamps and filter by timeframe
        df['timestamp_unix'] = df['Human Time'].apply(self.parse_csv_timestamp)
        timeframe_df = df[(df['timestamp_unix'] >= start_time) & (df['timestamp_unix'] <= end_time)]
        
        print(f"📊 Transactions in timeframe: {len(timeframe_df)}")
        
        if len(timeframe_df) == 0:
            print("❌ No transactions found in specified timeframe")
            return {}
        
        # Determine transaction types
        timeframe_df = timeframe_df.copy()
        timeframe_df['transaction_type'] = timeframe_df.apply(
            lambda row: self.determine_transaction_type(row, mortgage_token), axis=1
        )
        
        # Separate buyers and sellers
        buyers = set()
        sellers = set()
        buy_transactions = []
        sell_transactions = []
        
        for _, row in timeframe_df.iterrows():
            wallet = row['From']
            tx_type = row['transaction_type']
            
            if tx_type == 'buy':
                buyers.add(wallet)
                buy_transactions.append(row.to_dict())
            elif tx_type == 'sell':
                sellers.add(wallet)
                sell_transactions.append(row.to_dict())
        
        print(f"🛒 Buyers: {len(buyers)} unique wallets")
        print(f"💰 Sellers: {len(sellers)} unique wallets")
        
        # Find intersection
        intersection = buyers & sellers
        print(f"🎯 Wallets that both bought and sold: {len(intersection)}")
        
        if intersection:
            print("\n🎉 FOUND WALLETS THAT BOUGHT AND SOLD:")
            for i, wallet in enumerate(intersection, 1):
                print(f"  {i}. {wallet}")
                
                # Show transaction details
                wallet_buys = [tx for tx in buy_transactions if tx['From'] == wallet]
                wallet_sells = [tx for tx in sell_transactions if tx['From'] == wallet]
                
                print(f"     📊 {len(wallet_buys)} buy(s), {len(wallet_sells)} sell(s)")
                
                for buy in wallet_buys:
                    print(f"     🛒 BUY: {buy['Human Time']} | Value: ${buy['Value']}")
                
                for sell in wallet_sells:
                    print(f"     💰 SELL: {sell['Human Time']} | Value: ${sell['Value']}")
        
        return {
            'token_name': 'Mortgage',
            'token_address': mortgage_token,
            'timeframe': (start_time, end_time),
            'total_transactions': len(timeframe_df),
            'buyers': list(buyers),
            'sellers': list(sellers),
            'intersection_wallets': list(intersection),
            'buy_transactions': buy_transactions,
            'sell_transactions': sell_transactions
        }
    
    def analyze_neural_frog_csv(self, csv_path: str) -> Dict:
        """
        Analyze 神经蛙 token CSV for dual timeframes (UTC)
        Buy: June 27, 2:00-2:30 AM UTC
        Sell: June 27, 5:50-6:05 AM UTC
        """
        print("\n🐸 ANALYZING 神经蛙 TOKEN CSV")
        print("=" * 50)
        
        # Read CSV
        df = pd.read_csv(csv_path)
        print(f"📊 Total transactions in CSV: {len(df)}")
        
        # Token address
        neural_frog_token = "4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk"
        
        # Target timeframes (UTC)
        # Buy: June 27, 2:00-2:30 AM UTC
        buy_start = self.utc_to_unix_timestamp(2025, 6, 27, 2, 0, 0)
        buy_end = self.utc_to_unix_timestamp(2025, 6, 27, 2, 30, 0)
        
        # Sell: June 27, 5:50-6:05 AM UTC
        sell_start = self.utc_to_unix_timestamp(2025, 6, 27, 5, 50, 0)
        sell_end = self.utc_to_unix_timestamp(2025, 6, 27, 6, 5, 0)
        
        print(f"🕐 Buy timeframe: {datetime.fromtimestamp(buy_start/1000, tz=timezone.utc)} to {datetime.fromtimestamp(buy_end/1000, tz=timezone.utc)}")
        print(f"🕐 Sell timeframe: {datetime.fromtimestamp(sell_start/1000, tz=timezone.utc)} to {datetime.fromtimestamp(sell_end/1000, tz=timezone.utc)}")
        
        # Parse timestamps
        df['timestamp_unix'] = df['Human Time'].apply(self.parse_csv_timestamp)
        
        # Filter by buy timeframe
        buy_df = df[(df['timestamp_unix'] >= buy_start) & (df['timestamp_unix'] <= buy_end)]
        print(f"📊 Transactions in buy timeframe: {len(buy_df)}")
        
        # Filter by sell timeframe
        sell_df = df[(df['timestamp_unix'] >= sell_start) & (df['timestamp_unix'] <= sell_end)]
        print(f"📊 Transactions in sell timeframe: {len(sell_df)}")
        
        if len(buy_df) == 0 and len(sell_df) == 0:
            print("❌ No transactions found in either timeframe")
            return {}
        
        # Determine transaction types for buy timeframe
        buyers = set()
        buy_transactions = []
        
        if len(buy_df) > 0:
            buy_df = buy_df.copy()
            buy_df['transaction_type'] = buy_df.apply(
                lambda row: self.determine_transaction_type(row, neural_frog_token), axis=1
            )
            
            for _, row in buy_df.iterrows():
                if row['transaction_type'] == 'buy':
                    buyers.add(row['From'])
                    buy_transactions.append(row.to_dict())
        
        # Determine transaction types for sell timeframe
        sellers = set()
        sell_transactions = []
        
        if len(sell_df) > 0:
            sell_df = sell_df.copy()
            sell_df['transaction_type'] = sell_df.apply(
                lambda row: self.determine_transaction_type(row, neural_frog_token), axis=1
            )
            
            for _, row in sell_df.iterrows():
                if row['transaction_type'] == 'sell':
                    sellers.add(row['From'])
                    sell_transactions.append(row.to_dict())
        
        print(f"🛒 Buyers in buy timeframe: {len(buyers)} unique wallets")
        print(f"💰 Sellers in sell timeframe: {len(sellers)} unique wallets")
        
        # Find intersection
        intersection = buyers & sellers
        print(f"🎯 Wallets that bought AND sold: {len(intersection)}")
        
        if intersection:
            print("\n🎉 FOUND WALLETS THAT BOUGHT AND SOLD:")
            for i, wallet in enumerate(intersection, 1):
                print(f"  {i}. {wallet}")
                
                # Show transaction details
                wallet_buys = [tx for tx in buy_transactions if tx['From'] == wallet]
                wallet_sells = [tx for tx in sell_transactions if tx['From'] == wallet]
                
                print(f"     📊 {len(wallet_buys)} buy(s), {len(wallet_sells)} sell(s)")
                
                for buy in wallet_buys:
                    print(f"     🛒 BUY: {buy['Human Time']} | Value: ${buy['Value']}")
                
                for sell in wallet_sells:
                    print(f"     💰 SELL: {sell['Human Time']} | Value: ${sell['Value']}")
        
        return {
            'token_name': '神经蛙',
            'token_address': neural_frog_token,
            'buy_timeframe': (buy_start, buy_end),
            'sell_timeframe': (sell_start, sell_end),
            'total_buy_transactions': len(buy_df),
            'total_sell_transactions': len(sell_df),
            'buyers': list(buyers),
            'sellers': list(sellers),
            'intersection_wallets': list(intersection),
            'buy_transactions': buy_transactions,
            'sell_transactions': sell_transactions
        }

def main():
    analyzer = CSVTimeframeAnalyzer()
    
    print("🚀 CSV TIMEFRAME ANALYSIS")
    print("=" * 70)
    
    # Analyze Mortgage token
    mortgage_csv = "/home/ubuntu/upload/export_defi_activities_FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN_1751058490066.csv"
    mortgage_results = analyzer.analyze_mortgage_csv(mortgage_csv)
    
    # Analyze 神经蛙 token
    neural_frog_csv = "/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751059035337.csv"
    neural_frog_results = analyzer.analyze_neural_frog_csv(neural_frog_csv)
    
    # Save results
    combined_results = {
        'mortgage': mortgage_results,
        'neural_frog': neural_frog_results
    }
    
    with open('/home/ubuntu/csv_analysis_results.json', 'w') as f:
        json.dump(combined_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Results saved to csv_analysis_results.json")
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 FINAL SUMMARY")
    print("=" * 70)
    
    if mortgage_results:
        print(f"🏠 Mortgage: {len(mortgage_results.get('intersection_wallets', []))} wallets found")
        for wallet in mortgage_results.get('intersection_wallets', []):
            print(f"   - {wallet}")
    
    if neural_frog_results:
        print(f"🐸 神经蛙: {len(neural_frog_results.get('intersection_wallets', []))} wallets found")
        for wallet in neural_frog_results.get('intersection_wallets', []):
            print(f"   - {wallet}")
    
    # Cross-reference between tokens
    mortgage_wallets = set(mortgage_results.get('intersection_wallets', []))
    neural_frog_wallets = set(neural_frog_results.get('intersection_wallets', []))
    
    cross_token_wallets = mortgage_wallets & neural_frog_wallets
    
    if cross_token_wallets:
        print(f"\n🎯 WALLETS FOUND IN BOTH TOKENS: {len(cross_token_wallets)}")
        for wallet in cross_token_wallets:
            print(f"   🌟 {wallet}")
    else:
        print(f"\n❌ No wallets found that traded both tokens in the specified timeframes")

if __name__ == "__main__":
    main()

