#!/usr/bin/env python3
"""
Search for specific wallet address in all CSV files
"""

import pandas as pd
import os

def search_address_in_csv(csv_path, target_address):
    """Search for target address in a CSV file"""
    try:
        df = pd.read_csv(csv_path)
        matches = df[df['From'] == target_address]
        return len(matches), matches
    except Exception as e:
        print(f"Error reading {csv_path}: {e}")
        return 0, pd.DataFrame()

def main():
    target_address = "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D"
    
    print(f"🔍 SEARCHING FOR ADDRESS: {target_address}")
    print("=" * 80)
    
    # All CSV files provided by user
    csv_files = [
        # First batch
        "/home/ubuntu/upload/export_defi_activities_FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN_1751058490066.csv",
        "/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751059035337.csv",
        "/home/ubuntu/upload/export_defi_activities_CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump_1751060100603.csv",
        
        # Second batch
        "/home/ubuntu/upload/export_defi_activities_FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN_1751061823537.csv",
        "/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751061865153.csv",
        "/home/ubuntu/upload/export_defi_activities_CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump_1751061700105.csv"
    ]
    
    # Token mapping
    token_names = {
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN": "Mortgage",
        "4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk": "神经蛙",
        "CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump": "BLORB"
    }
    
    total_matches = 0
    found_in_files = []
    
    for csv_path in csv_files:
        if os.path.exists(csv_path):
            # Extract token from filename
            token_address = None
            token_name = "Unknown"
            for addr, name in token_names.items():
                if addr in csv_path:
                    token_address = addr
                    token_name = name
                    break
            
            # Determine batch
            batch = "Batch 1" if "1751058" in csv_path or "1751059" in csv_path or "1751060" in csv_path else "Batch 2"
            
            print(f"\n📊 CHECKING: {token_name} ({batch})")
            print(f"   File: {os.path.basename(csv_path)}")
            
            match_count, matches = search_address_in_csv(csv_path, target_address)
            
            if match_count > 0:
                print(f"   ✅ FOUND {match_count} TRANSACTION(S)!")
                total_matches += match_count
                found_in_files.append((token_name, batch, csv_path))
                
                # Show transaction details
                for _, row in matches.iterrows():
                    print(f"      📅 Time: {row['Human Time']}")
                    print(f"      💰 Value: ${row['Value']}")
                    print(f"      🔧 Action: {row['Action']}")
                    if 'Token1' in row and 'Token2' in row:
                        print(f"      🔄 Tokens: {row['Token1']} -> {row['Token2']}")
                    print()
            else:
                print(f"   ❌ Not found")
        else:
            print(f"\n❌ FILE NOT FOUND: {csv_path}")
    
    print(f"\n🎯 SUMMARY")
    print("=" * 80)
    print(f"📊 Total matches found: {total_matches}")
    
    if found_in_files:
        print(f"✅ Address found in {len(found_in_files)} file(s):")
        for token_name, batch, file_path in found_in_files:
            print(f"   - {token_name} ({batch})")
    else:
        print(f"❌ Address {target_address} was NOT found in any of the provided CSV files")
        print(f"\n💡 This could mean:")
        print(f"   - The wallet's transactions occurred outside the 1,000-record limit")
        print(f"   - The wallet traded during different time periods")
        print(f"   - The wallet used different transaction patterns")

if __name__ == "__main__":
    main()

