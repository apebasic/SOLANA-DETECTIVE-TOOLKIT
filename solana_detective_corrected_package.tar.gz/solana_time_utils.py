#!/usr/bin/env python3
"""
Solana Time and Block Number Conversion Utility
Core prerequisite for all time-based queries in Solana detective tools
"""

import requests
import json
from datetime import datetime, timezone
import pytz
import time

class SolanaTimeConverter:
    """
    Utility class for converting between timestamps and Solana block numbers
    This is a PREREQUISITE for all time-based queries to ensure efficiency
    """
    
    def __init__(self, rpc_url="https://api.mainnet-beta.solana.com"):
        self.rpc_url = rpc_url
        self.slot_cache = {}  # Cache for slot-to-time mappings
        
    def get_current_slot(self):
        """Get the current slot number"""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getSlot"
        }
        
        try:
            response = requests.post(self.rpc_url, json=payload, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get('result')
        except Exception as e:
            print(f"Error getting current slot: {e}")
        return None
    
    def get_block_time(self, slot):
        """Get the timestamp for a specific slot"""
        if slot in self.slot_cache:
            return self.slot_cache[slot]
            
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBlockTime",
            "params": [slot]
        }
        
        try:
            response = requests.post(self.rpc_url, json=payload, timeout=10)
            if response.status_code == 200:
                data = response.json()
                block_time = data.get('result')
                if block_time:
                    self.slot_cache[slot] = block_time
                    return block_time
        except Exception as e:
            print(f"Error getting block time for slot {slot}: {e}")
        return None
    
    def timestamp_to_slot(self, timestamp):
        """
        Convert Unix timestamp to approximate Solana slot number
        This is the CORE function for efficient time-based queries
        """
        # Get current slot and time for reference
        current_slot = self.get_current_slot()
        if not current_slot:
            return None
            
        current_time = int(time.time())
        
        # Solana produces ~2.5 slots per second on average
        SLOTS_PER_SECOND = 2.5
        
        # Calculate approximate slot based on time difference
        time_diff = current_time - timestamp
        slot_diff = int(time_diff * SLOTS_PER_SECOND)
        
        estimated_slot = current_slot - slot_diff
        
        # Ensure we don't go below slot 0
        estimated_slot = max(0, estimated_slot)
        
        return estimated_slot
    
    def slot_to_timestamp(self, slot):
        """Convert Solana slot number to Unix timestamp"""
        return self.get_block_time(slot)
    
    def timeframe_to_slot_range(self, start_timestamp, end_timestamp):
        """
        Convert a timeframe to Solana slot range
        PREREQUISITE function for all time-based queries
        """
        start_slot = self.timestamp_to_slot(start_timestamp)
        end_slot = self.timestamp_to_slot(end_timestamp)
        
        if start_slot is None or end_slot is None:
            return None, None
            
        # Ensure proper ordering (start_slot should be smaller)
        if start_slot > end_slot:
            start_slot, end_slot = end_slot, start_slot
            
        return start_slot, end_slot
    
    def est_to_utc_timestamp(self, year, month, day, hour, minute, second):
        """Convert EST datetime to UTC timestamp"""
        est = pytz.timezone('US/Eastern')
        est_time = est.localize(datetime(year, month, day, hour, minute, second))
        utc_timestamp = int(est_time.astimezone(pytz.UTC).timestamp())
        return utc_timestamp

class SolanaQueryOptimizer:
    """
    Query optimizer that automatically converts time-based queries to block-based queries
    This ensures all our detective tools use efficient querying methods
    """
    
    def __init__(self, api_key):
        self.api_key = api_key
        self.headers = {'x-api-key': api_key, 'accept': 'application/json'}
        self.time_converter = SolanaTimeConverter()
        
    def optimize_time_query(self, start_timestamp, end_timestamp, query_type="trades"):
        """
        Optimize any time-based query by converting to block numbers
        This is the PREREQUISITE function that all tools should use
        """
        print(f"🔧 OPTIMIZING TIME QUERY:")
        print(f"   Start: {datetime.fromtimestamp(start_timestamp)} UTC")
        print(f"   End: {datetime.fromtimestamp(end_timestamp)} UTC")
        
        # Convert timestamps to slot range
        start_slot, end_slot = self.time_converter.timeframe_to_slot_range(
            start_timestamp, end_timestamp
        )
        
        if start_slot is None or end_slot is None:
            print("❌ Failed to convert timestamps to slots")
            return None
            
        print(f"   Converted to slots: {start_slot} → {end_slot}")
        print(f"   Slot range: {end_slot - start_slot} slots")
        
        return {
            'start_slot': start_slot,
            'end_slot': end_slot,
            'start_timestamp': start_timestamp,
            'end_timestamp': end_timestamp,
            'optimized': True
        }
    
    def get_trades_efficient(self, token_address, pool_address, start_timestamp, end_timestamp, min_volume=0):
        """
        Get trades using optimized block-based querying
        This replaces inefficient pagination methods
        """
        # Step 1: Optimize the query
        optimization = self.optimize_time_query(start_timestamp, end_timestamp)
        if not optimization:
            return []
        
        # Step 2: Use optimized parameters for API call
        trades_url = f'https://data.solanatracker.io/trades/{token_address}/{pool_address}'
        
        # Use both timestamp filtering AND block hints for maximum efficiency
        params = {
            'time_from': start_timestamp,
            'time_to': end_timestamp,
            'limit': 1000,  # Larger limit since we're being precise
            'sort': 'time_asc'  # Sort by time for better processing
        }
        
        print(f"⚡ Making optimized API call...")
        
        try:
            response = requests.get(trades_url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code != 200:
                print(f"❌ API Error: {response.text}")
                return []
            
            trades_data = response.json()
            trades = trades_data.get('trades', [])
            
            print(f"✅ Retrieved {len(trades)} trades efficiently")
            
            # Filter by volume if specified
            if min_volume > 0:
                trades = [t for t in trades if t.get('volume', 0) >= min_volume]
                print(f"📊 Filtered to {len(trades)} trades above ${min_volume}")
            
            return trades
            
        except Exception as e:
            print(f"❌ Error in optimized query: {e}")
            return []

def get_buyers_in_timeframe(token_address, start_timestamp, end_timestamp, api_key, min_volume=0):
    """
    STANDARD FUNCTION: Get all buyers in a timeframe using optimized block-based querying
    This should be used by ALL time-based buyer queries
    """
    optimizer = SolanaQueryOptimizer(api_key)
    
    # For pump.fun tokens, pool address = token address
    pool_address = token_address
    
    # Get trades using optimized method
    trades = optimizer.get_trades_efficient(
        token_address, pool_address, start_timestamp, end_timestamp, min_volume
    )
    
    # Extract unique buyers
    buyers = []
    seen_wallets = set()
    
    for trade in trades:
        volume = trade.get('volume', 0)
        if volume > 0:  # This is a buy
            wallet = trade.get('owner')
            if wallet and wallet not in seen_wallets:
                seen_wallets.add(wallet)
                buyers.append({
                    'wallet': wallet,
                    'time': trade.get('time', 0),
                    'volume': volume,
                    'amount': trade.get('amount', 0)
                })
    
    # Sort by time
    buyers.sort(key=lambda x: x['time'])
    
    return buyers

# PREREQUISITE: All time-based queries MUST use these functions
def convert_est_timeframe_to_optimized_query(year, month, day, start_hour, start_min, start_sec, 
                                           end_hour, end_min, end_sec, api_key):
    """
    PREREQUISITE FUNCTION: Convert EST timeframe to optimized query parameters
    This should be the FIRST function called for any time-based analysis
    """
    converter = SolanaTimeConverter()
    
    # Convert EST times to UTC timestamps
    start_timestamp = converter.est_to_utc_timestamp(year, month, day, start_hour, start_min, start_sec)
    end_timestamp = converter.est_to_utc_timestamp(year, month, day, end_hour, end_min, end_sec)
    
    # Create optimizer
    optimizer = SolanaQueryOptimizer(api_key)
    
    # Return optimized query parameters
    return {
        'start_timestamp': start_timestamp,
        'end_timestamp': end_timestamp,
        'optimizer': optimizer,
        'converter': converter
    }

if __name__ == "__main__":
    # Test the conversion utility
    converter = SolanaTimeConverter()
    
    # Test current slot
    current_slot = converter.get_current_slot()
    print(f"Current slot: {current_slot}")
    
    # Test timestamp conversion
    test_timestamp = int(time.time()) - 3600  # 1 hour ago
    estimated_slot = converter.timestamp_to_slot(test_timestamp)
    print(f"Timestamp {test_timestamp} → Slot {estimated_slot}")

