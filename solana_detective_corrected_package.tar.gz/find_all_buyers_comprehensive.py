#!/usr/bin/env python3
"""
Find ALL wallet addresses that bought ALL specified tokens
Searches through all transaction data, not just first buyers
"""

import requests
import json
from collections import defaultdict
import time

def get_all_buyers_for_token(token_address, api_key):
    """Get ALL buyers for a token by getting token info and then all trades"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    print(f"   🔍 Getting token info for {token_address[:8]}...")
    
    # Step 1: Get token info to find pools
    try:
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"   ❌ Error getting token info: {response.text}")
            return set()
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            print(f"   ❌ No pools found for token")
            return set()
        
        print(f"   ✅ Found {len(pools)} pools")
        
        # Step 2: Get all trades from all pools
        all_buyers = set()
        
        for pool in pools:
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
                
            print(f"   📊 Getting trades from pool {pool_id[:8]}...")
            
            # Get trades from this pool
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            page = 1
            while True:
                try:
                    params = {'page': page, 'limit': 100}
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        print(f"   ❌ Error getting trades page {page}: {response.text}")
                        break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        print(f"   ✅ Finished at page {page-1}")
                        break
                    
                    # Extract buyer wallets from buy trades
                    for trade in trades:
                        if trade.get('type') == 'buy':
                            wallet = trade.get('wallet')
                            if wallet:
                                all_buyers.add(wallet)
                    
                    print(f"   📄 Page {page}: {len(trades)} trades, {len(all_buyers)} unique buyers so far")
                    
                    page += 1
                    
                    # Rate limiting
                    time.sleep(1.1)
                    
                    # Safety limit to avoid infinite loops
                    if page > 100:
                        print(f"   ⚠️ Reached page limit (100), stopping")
                        break
                        
                except Exception as e:
                    print(f"   ❌ Exception getting trades: {e}")
                    break
        
        print(f"   ✅ Total unique buyers found: {len(all_buyers)}")
        return all_buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return set()

def find_wallets_bought_all_tokens():
    """Find wallets that bought ALL specified tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # List of tokens to analyze
    tokens = [
        "qfyhNU2WmMAT1P5kc3isJNBKRpHec3ZLiLWxn38pump",
        "DFVeSFxNohR5CVuReaXSz6rGuJ62LsKhxFpWsDbbjups", 
        "EoD6LKTTpkLjpWaf9Dyemo7C4qEzsxWjPqCRa76apump",
        "8CDe8CVX74r3mEpcr2LsGGrNoGdJFt4uSYWyGfKUpump",
        "4dmQFkCM1WiUhC75UndLkmMtWj78fQJUvfc4xpMLpump",
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump"
    ]
    
    print(f"🔍 COMPREHENSIVE ANALYSIS: Finding ALL wallets that bought ALL {len(tokens)} tokens")
    print("=" * 80)
    print("⚠️  This will search through ALL transaction data, not just first buyers")
    print("⏱️  This may take several minutes due to comprehensive data collection")
    print("=" * 80)
    
    # Step 1: Get ALL buyers for each token
    token_buyers = {}  # token -> set of all buyer wallets
    
    for i, token in enumerate(tokens, 1):
        print(f"\n📊 {i}/{len(tokens)} Processing token:")
        print(f"   {token}")
        
        buyers = get_all_buyers_for_token(token, api_key)
        token_buyers[token] = buyers
        
        print(f"   ✅ Found {len(buyers)} total buyers for this token")
    
    # Step 2: Find intersection - wallets that bought ALL tokens
    print(f"\n🎯 FINDING INTERSECTION:")
    print("=" * 50)
    
    if not token_buyers:
        print("❌ No token data collected")
        return
    
    # Start with buyers from first token
    first_token = tokens[0]
    common_wallets = token_buyers[first_token].copy()
    
    print(f"Starting with {len(common_wallets)} buyers from first token")
    
    # Find intersection with each subsequent token
    for i, token in enumerate(tokens[1:], 2):
        token_buyers_set = token_buyers[token]
        common_wallets = common_wallets.intersection(token_buyers_set)
        print(f"After token {i}: {len(common_wallets)} wallets remain")
        
        if len(common_wallets) == 0:
            print("❌ No common wallets found, stopping early")
            break
    
    # Results
    print(f"\n🎯 FINAL RESULTS:")
    print("=" * 50)
    
    if common_wallets:
        print(f"✅ Found {len(common_wallets)} wallet(s) that bought ALL {len(tokens)} tokens:")
        print()
        
        for i, wallet in enumerate(sorted(common_wallets), 1):
            print(f"{i}. {wallet}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for wallet in sorted(common_wallets):
            print(wallet)
    else:
        print(f"❌ No wallets found that bought ALL {len(tokens)} tokens")
        
        # Show some statistics
        print(f"\n📊 STATISTICS:")
        for i, token in enumerate(tokens, 1):
            buyers_count = len(token_buyers[token])
            print(f"   Token {i}: {buyers_count} total buyers")

if __name__ == "__main__":
    find_wallets_bought_all_tokens()
