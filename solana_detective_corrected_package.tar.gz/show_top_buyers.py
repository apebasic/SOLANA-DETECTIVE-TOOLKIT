#!/usr/bin/env python3
"""
Show wallets that bought the most tokens from the list
"""

import requests
import json
from collections import defaultdict, Counter

def show_top_buyers():
    """Show wallets that bought the most tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    # List of tokens to analyze
    tokens = [
        "qfyhNU2WmMAT1P5kc3isJNBKRpHec3ZLiLWxn38pump",
        "DFVeSFxNohR5CVuReaXSz6rGuJ62LsKhxFpWsDbbjups", 
        "EoD6LKTTpkLjpWaf9Dyemo7C4qEzsxWjPqCRa76apump",
        "8CDe8CVX74r3mEpcr2LsGGrNoGdJFt4uSYWyGfKUpump",
        "4dmQFkCM1WiUhC75UndLkmMtWj78fQJUvfc4xpMLpump",
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump"
    ]
    
    print(f"🔍 SHOWING TOP BUYERS: Wallets that bought the most tokens")
    print("=" * 80)
    
    # Get first buyers for each token
    all_buyers = defaultdict(set)  # wallet -> set of tokens they bought
    token_buyers = {}  # token -> list of buyers
    
    for i, token in enumerate(tokens, 1):
        print(f"📊 {i}/{len(tokens)} Processing token: {token[:8]}...")
        
        try:
            url = f'{base_url}/first-buyers/{token}'
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                buyers = response.json()
                if isinstance(buyers, list):
                    token_buyers[token] = buyers
                    
                    # Track which tokens each wallet bought
                    for buyer in buyers:
                        wallet = buyer.get('wallet')
                        if wallet:
                            all_buyers[wallet].add(token)
                            
        except Exception as e:
            print(f"   ❌ Exception: {e}")
    
    # Find top buyers (those who bought the most tokens)
    print(f"\n🎯 TOP BUYERS ANALYSIS:")
    print("=" * 50)
    
    # Sort wallets by number of tokens bought
    sorted_buyers = sorted(all_buyers.items(), key=lambda x: len(x[1]), reverse=True)
    
    # Show top buyers
    max_tokens = max(len(tokens_bought) for tokens_bought in all_buyers.values()) if all_buyers else 0
    
    print(f"📊 Maximum tokens bought by any wallet: {max_tokens}/{len(tokens)}")
    
    # Show wallets that bought the most tokens
    for token_count in range(max_tokens, 0, -1):
        wallets_with_count = [wallet for wallet, tokens_bought in all_buyers.items() 
                             if len(tokens_bought) == token_count]
        
        if wallets_with_count and token_count >= 3:  # Show wallets with 3+ tokens
            print(f"\n📋 {len(wallets_with_count)} WALLETS THAT BOUGHT {token_count}/{len(tokens)} TOKENS:")
            
            for i, wallet in enumerate(wallets_with_count, 1):
                print(f"\n{i}. {wallet}")
                
                # Show which tokens this wallet bought
                wallet_tokens = all_buyers[wallet]
                print(f"   Tokens bought ({len(wallet_tokens)}):")
                for token in wallet_tokens:
                    print(f"      {token}")
            
            # If this is the highest count, show copy-paste list
            if token_count == max_tokens:
                print(f"\n📝 COPY-PASTE LIST (TOP {len(wallets_with_count)} WALLETS):")
                for wallet in wallets_with_count:
                    print(wallet)

if __name__ == "__main__":
    show_top_buyers()
