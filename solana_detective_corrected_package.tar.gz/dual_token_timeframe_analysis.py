#!/usr/bin/env python3
"""
Dual Token Timeframe Analysis
Analyzes Mortgage (UTC) and 神经蛙 (EST) tokens with their specific timeframes
"""

import requests
import json
import time
from datetime import datetime, timezone
import pytz
from typing import Dict, List, Set, Tuple

class DualTokenTimeframeAnalyzer:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {"x-api-key": api_key}
    
    def get_token_info(self, token_address: str) -> Dict:
        """Get token information including pools"""
        url = f"{self.base_url}/tokens/{token_address}"
        response = requests.get(url, headers=self.headers)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def get_top_liquidity_pool(self, token_address: str) -> Tuple[str, float]:
        """Get the pool with highest liquidity for a token"""
        token_info = self.get_token_info(token_address)
        if not token_info:
            return "", 0
        
        pools = token_info.get('pools', [])
        if not pools:
            return "", 0
        
        # Sort pools by liquidity (USD) and take top one
        pools_with_liquidity = []
        for pool in pools:
            liquidity_usd = pool.get('liquidity', {}).get('usd', 0)
            pools_with_liquidity.append((pool, liquidity_usd))
        
        pools_with_liquidity.sort(key=lambda x: x[1], reverse=True)
        top_pool = pools_with_liquidity[0][0]
        top_liquidity = pools_with_liquidity[0][1]
        
        return top_pool.get('poolId', ''), top_liquidity
    
    def est_to_unix_timestamp(self, year: int, month: int, day: int, 
                             hour: int, minute: int, second: int = 0) -> int:
        """Convert EST time to Unix timestamp"""
        est = pytz.timezone('US/Eastern')
        dt = datetime(year, month, day, hour, minute, second)
        dt_est = est.localize(dt)
        return int(dt_est.timestamp() * 1000)  # Convert to milliseconds
    
    def utc_to_unix_timestamp(self, year: int, month: int, day: int, 
                             hour: int, minute: int, second: int = 0) -> int:
        """Convert UTC time to Unix timestamp"""
        dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)  # Convert to milliseconds
    
    def get_trades_in_timeframe(self, token_address: str, pool_address: str,
                               start_timestamp: int, end_timestamp: int,
                               transaction_type: str = None) -> List[Dict]:
        """
        Get trades within a specific timeframe
        transaction_type: 'buy', 'sell', or None for both
        """
        trades_in_timeframe = []
        page = 1
        max_pages = 100  # Safety limit
        
        print(f"  🔍 Searching {transaction_type or 'all'} transactions from {start_timestamp} to {end_timestamp}")
        
        while page <= max_pages:
            url = f"{self.base_url}/trades/{token_address}/{pool_address}"
            params = {"page": page}
            
            response = requests.get(url, headers=self.headers, params=params)
            if response.status_code != 200:
                break
            
            data = response.json()
            trades = data.get('trades', [])
            
            if not trades:
                break
            
            found_in_timeframe = False
            for trade in trades:
                trade_time = trade.get('time', 0)
                
                # Check if trade is in our timeframe
                if start_timestamp <= trade_time <= end_timestamp:
                    # Filter by transaction type if specified
                    if transaction_type is None or trade.get('type') == transaction_type:
                        trades_in_timeframe.append(trade)
                        found_in_timeframe = True
                
                # If we've gone past our timeframe, we can stop
                elif trade_time < start_timestamp:
                    print(f"    📄 Reached end of timeframe at page {page}")
                    return trades_in_timeframe
            
            if not found_in_timeframe and page > 5:
                # If we haven't found anything in recent pages, likely past our timeframe
                break
            
            print(f"    📄 Page {page}: Found {len([t for t in trades if start_timestamp <= t.get('time', 0) <= end_timestamp])} trades in timeframe")
            page += 1
            time.sleep(1.1)  # Rate limiting
        
        return trades_in_timeframe
    
    def analyze_single_timeframe_token(self, token_address: str, token_name: str,
                                     timeframe: Tuple[int, int]) -> Dict:
        """
        Analyze a token where buy and sell happen in the same timeframe
        """
        print(f"🚀 Analyzing {token_name} ({token_address[:8]}...)")
        print("=" * 70)
        
        # Get top liquidity pool
        pool_address, liquidity = self.get_top_liquidity_pool(token_address)
        if not pool_address:
            print(f"❌ No pools found for {token_name}")
            return {}
        
        print(f"📊 Using top liquidity pool: ${liquidity:,.2f}")
        print(f"🔍 Pool: {pool_address}")
        
        # Get all trades in timeframe
        print(f"\n🔍 Finding all transactions between {timeframe[0]} and {timeframe[1]}")
        all_trades = self.get_trades_in_timeframe(
            token_address, pool_address, timeframe[0], timeframe[1]
        )
        
        # Separate buyers and sellers
        buyers = set()
        sellers = set()
        buy_trades = []
        sell_trades = []
        
        for trade in all_trades:
            wallet = trade.get('wallet')
            trade_type = trade.get('type')
            
            if wallet and trade_type == 'buy':
                buyers.add(wallet)
                buy_trades.append(trade)
            elif wallet and trade_type == 'sell':
                sellers.add(wallet)
                sell_trades.append(trade)
        
        print(f"✅ Found {len(buy_trades)} buy transactions from {len(buyers)} unique wallets")
        print(f"✅ Found {len(sell_trades)} sell transactions from {len(sellers)} unique wallets")
        
        # Find intersection
        print(f"\n🎯 Finding wallets that both bought AND sold")
        intersection = buyers & sellers
        
        print(f"🔍 Buyers: {len(buyers)} wallets")
        print(f"🔍 Sellers: {len(sellers)} wallets")
        print(f"🎯 Intersection: {len(intersection)} wallets")
        
        # Detailed analysis of intersection wallets
        results = {
            'token_name': token_name,
            'token_address': token_address,
            'pool_address': pool_address,
            'pool_liquidity': liquidity,
            'timeframe': timeframe,
            'total_buyers': len(buyers),
            'total_sellers': len(sellers),
            'intersection_wallets': list(intersection),
            'intersection_count': len(intersection),
            'buy_trades': buy_trades,
            'sell_trades': sell_trades,
            'all_buyers': list(buyers),
            'all_sellers': list(sellers)
        }
        
        if intersection:
            print(f"\n🎉 FOUND {len(intersection)} WALLET(S) THAT BOUGHT AND SOLD:")
            for i, wallet in enumerate(intersection, 1):
                print(f"  {i}. {wallet}")
                
                # Get detailed info for this wallet
                wallet_buy_trades = [t for t in buy_trades if t.get('wallet') == wallet]
                wallet_sell_trades = [t for t in sell_trades if t.get('wallet') == wallet]
                
                print(f"     📊 {len(wallet_buy_trades)} buy(s), {len(wallet_sell_trades)} sell(s)")
                
                # Show trade details
                for buy_trade in wallet_buy_trades:
                    amount = buy_trade.get('amount', 0)
                    price = buy_trade.get('priceUsd', 0)
                    volume = buy_trade.get('volume', 0)
                    trade_time = buy_trade.get('time', 0)
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                    print(f"     🛒 BUY: {amount:,.0f} tokens, ${price:.6f}, ${volume:.2f} @ {dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
                
                for sell_trade in wallet_sell_trades:
                    amount = sell_trade.get('amount', 0)
                    price = sell_trade.get('priceUsd', 0)
                    volume = sell_trade.get('volume', 0)
                    trade_time = sell_trade.get('time', 0)
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                    print(f"     💰 SELL: {amount:,.0f} tokens, ${price:.6f}, ${volume:.2f} @ {dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        else:
            print(f"\n❌ No wallets found that both bought and sold in the specified timeframe")
        
        return results
    
    def analyze_dual_timeframe_token(self, token_address: str, token_name: str,
                                   buy_timeframe: Tuple[int, int],
                                   sell_timeframe: Tuple[int, int]) -> Dict:
        """
        Analyze a token with separate buy and sell timeframes
        """
        print(f"🚀 Analyzing {token_name} ({token_address[:8]}...)")
        print("=" * 70)
        
        # Get top liquidity pool
        pool_address, liquidity = self.get_top_liquidity_pool(token_address)
        if not pool_address:
            print(f"❌ No pools found for {token_name}")
            return {}
        
        print(f"📊 Using top liquidity pool: ${liquidity:,.2f}")
        print(f"🔍 Pool: {pool_address}")
        
        # Get buyers in first timeframe
        print(f"\n🛒 PHASE 1: Finding buyers between {buy_timeframe[0]} and {buy_timeframe[1]}")
        buy_trades = self.get_trades_in_timeframe(
            token_address, pool_address, buy_timeframe[0], buy_timeframe[1], 'buy'
        )
        
        buyers = set()
        for trade in buy_trades:
            wallet = trade.get('wallet')
            if wallet:
                buyers.add(wallet)
        
        print(f"✅ Found {len(buy_trades)} buy transactions from {len(buyers)} unique wallets")
        
        # Get sellers in second timeframe
        print(f"\n💰 PHASE 2: Finding sellers between {sell_timeframe[0]} and {sell_timeframe[1]}")
        sell_trades = self.get_trades_in_timeframe(
            token_address, pool_address, sell_timeframe[0], sell_timeframe[1], 'sell'
        )
        
        sellers = set()
        for trade in sell_trades:
            wallet = trade.get('wallet')
            if wallet:
                sellers.add(wallet)
        
        print(f"✅ Found {len(sell_trades)} sell transactions from {len(sellers)} unique wallets")
        
        # Find intersection
        print(f"\n🎯 PHASE 3: Finding wallets that both bought AND sold")
        intersection = buyers & sellers
        
        print(f"🔍 Buyers: {len(buyers)} wallets")
        print(f"🔍 Sellers: {len(sellers)} wallets")
        print(f"🎯 Intersection: {len(intersection)} wallets")
        
        # Detailed analysis of intersection wallets
        results = {
            'token_name': token_name,
            'token_address': token_address,
            'pool_address': pool_address,
            'pool_liquidity': liquidity,
            'buy_timeframe': buy_timeframe,
            'sell_timeframe': sell_timeframe,
            'total_buyers': len(buyers),
            'total_sellers': len(sellers),
            'intersection_wallets': list(intersection),
            'intersection_count': len(intersection),
            'buy_trades': buy_trades,
            'sell_trades': sell_trades,
            'all_buyers': list(buyers),
            'all_sellers': list(sellers)
        }
        
        if intersection:
            print(f"\n🎉 FOUND {len(intersection)} WALLET(S) THAT BOUGHT AND SOLD:")
            for i, wallet in enumerate(intersection, 1):
                print(f"  {i}. {wallet}")
                
                # Get detailed info for this wallet
                wallet_buy_trades = [t for t in buy_trades if t.get('wallet') == wallet]
                wallet_sell_trades = [t for t in sell_trades if t.get('wallet') == wallet]
                
                print(f"     📊 {len(wallet_buy_trades)} buy(s), {len(wallet_sell_trades)} sell(s)")
                
                # Show trade details
                for buy_trade in wallet_buy_trades:
                    amount = buy_trade.get('amount', 0)
                    price = buy_trade.get('priceUsd', 0)
                    volume = buy_trade.get('volume', 0)
                    trade_time = buy_trade.get('time', 0)
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                    print(f"     🛒 BUY: {amount:,.0f} tokens, ${price:.6f}, ${volume:.2f} @ {dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
                
                for sell_trade in wallet_sell_trades:
                    amount = sell_trade.get('amount', 0)
                    price = sell_trade.get('priceUsd', 0)
                    volume = sell_trade.get('volume', 0)
                    trade_time = sell_trade.get('time', 0)
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                    print(f"     💰 SELL: {amount:,.0f} tokens, ${price:.6f}, ${volume:.2f} @ {dt.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        else:
            print(f"\n❌ No wallets found that both bought and sold in the specified timeframes")
        
        return results

def main():
    # Load API key
    try:
        with open('/home/ubuntu/config.json', 'r') as f:
            config = json.load(f)
            api_key = config.get('api_key', '')
    except:
        print("❌ Could not load API key from config.json")
        return
    
    if not api_key:
        print("❌ No API key found in config")
        return
    
    analyzer = DualTokenTimeframeAnalyzer(api_key)
    
    print("🚀 DUAL TOKEN TIMEFRAME ANALYSIS")
    print("=" * 70)
    
    # Token 1: Mortgage (UTC timeframe)
    mortgage_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    mortgage_name = "Mortgage"
    
    # Convert UTC timeframe: June 25, 19:30 UTC to 19:45 UTC
    mortgage_start = analyzer.utc_to_unix_timestamp(2025, 6, 25, 19, 30, 0)
    mortgage_end = analyzer.utc_to_unix_timestamp(2025, 6, 25, 19, 45, 0)
    
    print(f"🕐 Mortgage timeframe (UTC): {mortgage_start} to {mortgage_end}")
    
    # Analyze Mortgage
    mortgage_results = analyzer.analyze_single_timeframe_token(
        mortgage_address, mortgage_name, (mortgage_start, mortgage_end)
    )
    
    print("\n" + "=" * 70)
    
    # Token 2: 神经蛙 (EST timeframes)
    neural_frog_address = "4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk"
    neural_frog_name = "神经蛙"
    
    # Convert EST timeframes
    # Buy: June 26, 10:00 PM EST to 10:30 PM EST
    buy_start = analyzer.est_to_unix_timestamp(2025, 6, 26, 22, 0, 0)
    buy_end = analyzer.est_to_unix_timestamp(2025, 6, 26, 22, 30, 0)
    
    # Sell: June 27, 1:50 AM EST to 2:01 AM EST  
    sell_start = analyzer.est_to_unix_timestamp(2025, 6, 27, 1, 50, 0)
    sell_end = analyzer.est_to_unix_timestamp(2025, 6, 27, 2, 1, 0)
    
    print(f"🕐 神经蛙 buy timeframe (EST): {buy_start} to {buy_end}")
    print(f"🕐 神经蛙 sell timeframe (EST): {sell_start} to {sell_end}")
    
    # Analyze 神经蛙
    neural_frog_results = analyzer.analyze_dual_timeframe_token(
        neural_frog_address, neural_frog_name,
        (buy_start, buy_end),
        (sell_start, sell_end)
    )
    
    # Save results
    combined_results = {
        'mortgage': mortgage_results,
        'neural_frog': neural_frog_results
    }
    
    with open('/home/ubuntu/dual_token_analysis_results.json', 'w') as f:
        json.dump(combined_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Results saved to dual_token_analysis_results.json")
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 SUMMARY")
    print("=" * 70)
    
    if mortgage_results:
        print(f"🏠 Mortgage: {mortgage_results.get('intersection_count', 0)} wallets found")
        if mortgage_results.get('intersection_wallets'):
            for wallet in mortgage_results['intersection_wallets']:
                print(f"   - {wallet}")
    
    if neural_frog_results:
        print(f"🐸 神经蛙: {neural_frog_results.get('intersection_count', 0)} wallets found")
        if neural_frog_results.get('intersection_wallets'):
            for wallet in neural_frog_results['intersection_wallets']:
                print(f"   - {wallet}")

if __name__ == "__main__":
    main()

