#!/usr/bin/env python3

import requests
import json

api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
headers = {'x-api-key': api_key, 'accept': 'application/json'}

token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"

print(f"🔍 Checking if token exists: {token_address}")
print("=" * 80)

# Try different endpoints to find the token
endpoints_to_try = [
    ("Graduated tokens", "https://data.solanatracker.io/tokens/multi/graduated"),
    ("All tokens", "https://data.solanatracker.io/tokens"),
    ("First buyers", f"https://data.solanatracker.io/first-buyers/{token_address}")
]

for name, url in endpoints_to_try:
    print(f"\n📊 Trying {name}: {url}")
    try:
        response = requests.get(url, headers=headers, timeout=30)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            if name == "First buyers":
                if isinstance(data, list) and len(data) > 0:
                    print(f"✅ Found {len(data)} first buyers!")
                    print("Token exists and has trading activity")
                else:
                    print("❌ No first buyers found")
            else:
                if isinstance(data, list):
                    found = False
                    for item in data:
                        if isinstance(item, dict):
                            token_mint = item.get('token', {}).get('mint') if 'token' in item else item.get('mint')
                            if token_mint == token_address:
                                print(f"✅ Found token in {name}!")
                                found = True
                                break
                    if not found:
                        print(f"❌ Token not found in {name}")
                else:
                    print(f"Unexpected data format: {type(data)}")
        else:
            print(f"❌ Error: {response.text}")
            
    except Exception as e:
        print(f"❌ Exception: {e}")

# Try to get pool info directly
print(f"\n📊 Trying to find pools for this token...")
try:
    # Check if it's a pump.fun token by trying the pump.fun pattern
    if token_address.endswith('pump'):
        print("✅ Token appears to be a pump.fun token (ends with 'pump')")
        
        # For pump.fun tokens, the pool address is often the same as token address
        pool_address = token_address
        trades_url = f'https://data.solanatracker.io/trades/{token_address}/{pool_address}'
        
        print(f"🔍 Trying trades endpoint with token as pool: {trades_url}")
        response = requests.get(trades_url, headers=headers, timeout=30)
        print(f"Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Trades endpoint works! Found data: {type(data)}")
            if isinstance(data, dict) and 'trades' in data:
                trades = data['trades']
                print(f"Found {len(trades)} trades")
        else:
            print(f"❌ Trades error: {response.text}")
            
except Exception as e:
    print(f"❌ Exception checking trades: {e}")
