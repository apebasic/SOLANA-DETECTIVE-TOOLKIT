#!/usr/bin/env python3
"""
Quality Check for Multi-Method Endpoints
Verifies all endpoints with multiple methods are properly documented
"""

import json

def run_quality_check():
    """Run comprehensive quality check for multi-method endpoints"""
    
    print("🔍 QUALITY CHECK - Multi-Method Endpoints")
    print("=" * 60)
    
    # Load documentation
    with open('MANUALLY_FIXED_SOLANA_API_DOCS.json', 'r') as f:
        documentation = json.load(f)
    
    # Expected multi-method endpoints based on user's original specification
    expected_multi_methods = {
        "Chart Data": [
            "GET /chart/{token}",
            "GET /chart/{token}/{pool}"
        ],
        "Top Traders": [
            "GET /top-traders/all", 
            "GET /top-traders/all/{page}"
        ],
        "Stats and Events": [
            "GET /stats/{token}",
            "GET /stats/{token}/{pool}"
        ],
        "Token Trending": [
            "GET /tokens/trending",
            "GET /tokens/trending/{timeframe}"
        ],
        "Token Volume": [
            "GET /tokens/volume", 
            "GET /tokens/volume/{timeframe}"
        ],
        "Price Multi": [
            "GET /price/multi",
            "POST /price/multi"
        ]
    }
    
    print("📋 Checking for all expected multi-method endpoints...")
    
    all_documented_endpoints = list(documentation['endpoints'].keys())
    
    missing_methods = []
    found_methods = []
    
    for category, methods in expected_multi_methods.items():
        print(f"\n🔍 {category}:")
        
        for method in methods:
            if method in all_documented_endpoints:
                print(f"   ✅ Found: {method}")
                found_methods.append(method)
            else:
                print(f"   ❌ Missing: {method}")
                missing_methods.append(method)
    
    print(f"\n📊 SUMMARY:")
    print(f"✅ Found methods: {len(found_methods)}")
    print(f"❌ Missing methods: {len(missing_methods)}")
    
    if missing_methods:
        print(f"\n🚨 MISSING METHODS:")
        for method in missing_methods:
            print(f"   - {method}")
    
    # Check interval notation issue
    print(f"\n🔍 Checking interval notation (1m vs 1mn)...")
    
    interval_issues = []
    for endpoint_name, endpoint_doc in documentation['endpoints'].items():
        intervals = endpoint_doc.get('available_intervals', [])
        if intervals:
            # Count occurrences of '1m'
            m_count = intervals.count('1m')
            if m_count > 1:
                interval_issues.append(f"{endpoint_name}: '1m' appears {m_count} times")
            elif '1m' in intervals and '1mn' not in intervals:
                interval_issues.append(f"{endpoint_name}: Has '1m' but missing '1mn'")
    
    if interval_issues:
        print(f"⚠️  Interval notation issues found:")
        for issue in interval_issues:
            print(f"   - {issue}")
    else:
        print(f"✅ No interval notation issues found")
    
    # Generate fixes if needed
    if missing_methods or interval_issues:
        print(f"\n🔧 Generating fixes...")
        generate_fixes(documentation, missing_methods, interval_issues)
    else:
        print(f"\n🎉 All multi-method endpoints properly documented!")
    
def generate_fixes(documentation, missing_methods, interval_issues):
    """Generate fixes for missing methods and interval issues"""
    
    # Fix missing methods (add placeholders)
    for method in missing_methods:
        if method not in documentation['endpoints']:
            # Create basic structure for missing method
            method_parts = method.split(' ', 1)
            http_method = method_parts[0]
            path = method_parts[1] if len(method_parts) > 1 else ""
            
            documentation['endpoints'][method] = {
                "endpoint": method,
                "url": f"https://docs.solanatracker.io/public-data-api/docs#{http_method.lower()}-{path.replace('/', '').replace('{', '').replace('}', '').replace('-', '')}",
                "method": http_method,
                "path": path,
                "description": f"[MISSING] {method} - Needs manual documentation",
                "query_parameters": [],
                "path_parameters": [],
                "request_body": None,
                "response_format": {},
                "example_response": "",
                "available_intervals": [],
                "notes": ["Missing method - needs manual documentation"],
                "pagination_supported": False,
                "authentication_required": True
            }
            print(f"   ✅ Added placeholder for: {method}")
    
    # Fix interval notation
    for endpoint_name, endpoint_doc in documentation['endpoints'].items():
        intervals = endpoint_doc.get('available_intervals', [])
        if intervals and '1m' in intervals:
            # Replace duplicate '1m' with '1mn' for month
            fixed_intervals = []
            m_count = 0
            for interval in intervals:
                if interval == '1m':
                    m_count += 1
                    if m_count == 1:
                        fixed_intervals.append('1m')  # First one is minute
                    else:
                        fixed_intervals.append('1mn')  # Second one is month
                else:
                    fixed_intervals.append(interval)
            
            if m_count > 1:
                documentation['endpoints'][endpoint_name]['available_intervals'] = fixed_intervals
                print(f"   ✅ Fixed intervals for: {endpoint_name}")
    
    # Save fixed documentation
    with open('QUALITY_CHECKED_SOLANA_API_DOCS.json', 'w', encoding='utf-8') as f:
        json.dump(documentation, f, indent=2, ensure_ascii=False)
    print(f"💾 Quality-checked documentation saved: QUALITY_CHECKED_SOLANA_API_DOCS.json")
    
    # Generate updated markdown
    generate_quality_checked_markdown(documentation)

def generate_quality_checked_markdown(documentation):
    """Generate quality-checked markdown documentation"""
    print("📝 Generating quality-checked markdown documentation...")
    
    markdown = f"""# SOLANA TRACKER API - QUALITY CHECKED DOCUMENTATION

**Base URL**: `{documentation['base_url']}`
**Authentication**: {documentation['authentication']}
**Total Endpoints**: {len(documentation['endpoints'])}
**Last Updated**: 2025-06-28 (Quality Checked)

## COMPLETE API REFERENCE (QUALITY CHECKED)

"""
    
    # Group endpoints by category
    categories = {
        "Token Endpoints": [],
        "Price Endpoints": [],
        "Wallet Endpoints": [],
        "Trade Endpoints": [],
        "Chart Data Endpoints": [],
        "PnL Data Endpoints": [],
        "Top Traders Endpoints": [],
        "Stats and Events Endpoints": [],
        "Credits Endpoints": []
    }
    
    # Categorize endpoints
    for endpoint_name, endpoint_doc in documentation['endpoints'].items():
        path = endpoint_doc.get('path', '')
        
        if path.startswith('/tokens'):
            categories["Token Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/price'):
            categories["Price Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/wallet'):
            categories["Wallet Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/trades'):
            categories["Trade Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/chart') or path.startswith('/holders'):
            categories["Chart Data Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/pnl') or path.startswith('/first-buyers'):
            categories["PnL Data Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/top-traders'):
            categories["Top Traders Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/stats') or path.startswith('/events'):
            categories["Stats and Events Endpoints"].append((endpoint_name, endpoint_doc))
        elif path.startswith('/credits'):
            categories["Credits Endpoints"].append((endpoint_name, endpoint_doc))
            
    # Generate detailed documentation
    for category, endpoints in categories.items():
        if endpoints:
            markdown += f"## {category}\n\n"
            
            for endpoint_name, endpoint_doc in endpoints:
                markdown += f"### {endpoint_name}\n\n"
                
                if endpoint_doc.get('description'):
                    markdown += f"**Description**: {endpoint_doc['description']}\n\n"
                    
                # Path Parameters
                if endpoint_doc.get('path_parameters'):
                    markdown += "**Path Parameters**:\n"
                    for param in endpoint_doc['path_parameters']:
                        required = " (required)" if param.get('required') else " (optional)"
                        markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                    markdown += "\n"
                    
                # Query Parameters
                if endpoint_doc.get('query_parameters'):
                    markdown += "**Query Parameters**:\n"
                    for param in endpoint_doc['query_parameters']:
                        required = " (required)" if param.get('required') else " (optional)"
                        markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                    markdown += "\n"
                    
                # Available Intervals (FIXED)
                if endpoint_doc.get('available_intervals'):
                    markdown += "**Available Intervals**: "
                    markdown += ", ".join(f"`{interval}`" for interval in endpoint_doc['available_intervals'])
                    markdown += "\n\n"
                    markdown += "**Note**: `1m` = 1 minute, `1mn` = 1 month\n\n"
                    
                # Pagination
                if endpoint_doc.get('pagination_supported'):
                    markdown += "**Pagination**: Supported (cursor-based)\n\n"
                    
                # Notes
                if endpoint_doc.get('notes'):
                    markdown += "**Notes**:\n"
                    for note in endpoint_doc['notes']:
                        markdown += f"- {note}\n"
                    markdown += "\n"
                    
                # Response Example
                if endpoint_doc.get('example_response'):
                    markdown += f"**Response Example**:\n```json\n{endpoint_doc['example_response']}\n```\n\n"
                    
                markdown += "---\n\n"
                
    filename = 'QUALITY_CHECKED_SOLANA_TRACKER_API_DOCS.md'
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(markdown)
        
    print(f"✅ Quality-checked markdown documentation generated: {filename}")

if __name__ == "__main__":
    run_quality_check()

