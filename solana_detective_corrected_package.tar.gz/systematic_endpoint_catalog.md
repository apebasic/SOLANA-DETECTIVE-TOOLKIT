# SYSTEMATIC SOLANA TRACKER API ENDPOINT CATALOG

## PHASE 1: ENDPOINT DISCOVERY AND CATALOGING

### METHODOLOGY:
1. **Systematic Navigation**: Visit each category section
2. **Complete Enumeration**: Count and list every endpoint
3. **URL Pattern Analysis**: Document the URL structure for each endpoint
4. **Quality Control**: Verify completeness before extraction

### ENDPOINT CATEGORIES IDENTIFIED:

From the main documentation page table of contents, I can see the following categories:

1. **Token Endpoints** (Badge: 19)
2. **Price Endpoints** (Badge: 20) 
3. **Wallet Endpoints** (Badge: 21)
4. **Trade Endpoints** (Badge: 22)
5. **Chart Data** (Badge: 23)
6. **PnL (Profit and Loss) Endpoints** (Badge: 24)
7. **Top Traders** (Badge: 25)
8. **Stats and Live Events** (Badge: 26)
9. **Credits** (Badge: 27)

**Additional Sections:**
- Pagination (Badge: 28)
- Extra Information (Badge: 29)

### SYSTEMATIC EXTRACTION PLAN:

#### Step 1: Navigate to each category and count exact endpoints
#### Step 2: Document the URL pattern for each endpoint
#### Step 3: Create comprehensive endpoint inventory
#### Step 4: Extract documentation for each endpoint systematically
#### Step 5: Quality control and validation

---

## ENDPOINT INVENTORY (TO BE COMPLETED)

### TOKEN ENDPOINTS:
- [x] Count: **13 endpoints**
- [x] Endpoints:
  1. GET /tokens/{tokenAddress} - Get Token Information
  2. GET /tokens/by-pool/{poolAddress} - Get Token by Pool Address  
  3. GET /tokens/{tokenAddress}/holders - Get Token Holders
  4. GET /tokens/{tokenAddress}/holders/top - Get Top 20 Token Holders
  5. GET /tokens/{tokenAddress}/ath - Get All-Time High Price
  6. GET /deployer/{wallet} - Get Tokens by Deployer
  7. GET /search - Advanced Token Search
  8. GET /tokens/latest - Get Latest Tokens
  9. POST /tokens/multi - Get Multiple Tokens
  10. GET /tokens/trending - Get Trending Tokens
  11. GET /tokens/volume - Get Tokens by Volume
  12. GET /tokens/multi/all - Get Token Overview
  13. GET /tokens/multi/graduated - Get Graduated Tokens

### PRICE ENDPOINTS:
- [x] Count: **6 endpoints**
- [x] Endpoints:
  1. GET /price - Get Token Price
  2. GET /price/history - Get Historic Price Information
  3. GET /price/history/timestamp - Get Price at Specific Timestamp
  4. GET /price/history/range - Get lowest and highest price in time range
  5. POST /price - Post Token Price
  6. GET/POST /price/multi - Get Multiple Token Prices

### WALLET ENDPOINTS:
- [x] Count: **5 endpoints**
- [x] Endpoints:
  1. GET /wallet/{owner} - Get Wallet Tokens
  2. GET /wallet/{owner}/basic - Get Basic Wallet Information
  3. GET /wallet/{owner}/page/{page} - Get Wallet Tokens with Pagination
  4. GET /wallet/{owner}/trades - Get Wallet Trades
  5. GET /wallet/{owner}/chart - Get Wallet Portfolio Chart

### TRADE ENDPOINTS:
- [x] Count: **3 endpoints**
- [x] Endpoints:
  1. GET /trades/{tokenAddress}/{poolAddress} - Get Pool-Specific Trades
  2. GET /trades/{tokenAddress}/{poolAddress}/{owner} - Get User-Specific Pool Trades
  3. GET /trades/{tokenAddress}/by-wallet/{owner} - Get User-Specific Token Trades

### CHART DATA:
- [x] Count: **2 endpoints**
- [x] Endpoints:
  1. GET /chart/{token} - Get OHLCV Data for a token / pool
  2. GET /holders/chart/{token} - Get Holders Chart Data

### PNL DATA:
- [x] Count: **3 endpoints**
- [x] Endpoints:
  1. GET /pnl/{wallet} - Get Wallet PnL
  2. GET /first-buyers/{token} - Get First Token Buyers
  3. GET /pnl/{wallet}/{token} - Get Token-Specific PnL

### TOP TRADERS:
- [x] Count: **2 endpoints**
- [x] Endpoints:
  1. GET /top-traders/all - Get Top Traders (All Tokens)
  2. GET /top-traders/{token} - Get Top Traders for Specific Token

### STATS AND LIVE EVENTS:
- [x] Count: **3 endpoints**
- [x] Endpoints:
  1. GET /stats/{token} - Get Token Stats
  2. GET /events/{tokenAddress} - Get Token Events
  3. GET /events/{tokenAddress}/{poolAddress} - Get Pool Events

### CREDITS:
- [x] Count: **1 endpoint**
- [x] Endpoints:
  1. GET /credits - Get API Credits

---

## TOTAL ENDPOINT COUNT: **38 ENDPOINTS**

### BREAKDOWN BY CATEGORY:
- Token Endpoints: 13
- Price Endpoints: 6
- Wallet Endpoints: 5
- Trade Endpoints: 3
- Chart Data: 2
- PnL Data: 3
- Top Traders: 2
- Stats and Live Events: 3
- Credits: 1

**TOTAL: 38 endpoints**

---

## QUALITY CONTROL CHECKLIST:

- [ ] All categories visited
- [ ] All endpoints counted
- [ ] All URL patterns documented
- [ ] All response formats captured
- [ ] All parameters documented
- [ ] Cross-reference with API playground
- [ ] Validate total count matches documentation

