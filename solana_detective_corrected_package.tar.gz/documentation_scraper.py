#!/usr/bin/env python3
"""
Solana Tracker API Documentation Scraper
Automatically extracts complete documentation for all endpoints
"""

import json
import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException

class SolanaTrackerDocScraper:
    def __init__(self):
        self.setup_driver()
        self.documentation = {
            "base_url": "https://data.solanatracker.io",
            "authentication": "x-api-key header",
            "endpoints": {}
        }
        
    def setup_driver(self):
        """Setup Chrome driver with appropriate options"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
    def navigate_to_docs(self):
        """Navigate to the documentation page"""
        print("🌐 Navigating to Solana Tracker API documentation...")
        self.driver.get("https://docs.solanatracker.io/public-data-api/docs")
        time.sleep(3)
        
    def find_all_endpoint_buttons(self):
        """Find all expandable endpoint buttons"""
        print("🔍 Finding all endpoint buttons...")
        
        # Look for buttons that contain endpoint information
        endpoint_buttons = self.driver.find_elements(
            By.XPATH, 
            "//button[contains(text(), 'GET ') or contains(text(), 'POST ')]"
        )
        
        print(f"📋 Found {len(endpoint_buttons)} endpoint buttons")
        return endpoint_buttons
        
    def extract_endpoint_info(self, button):
        """Extract information from a single endpoint"""
        try:
            # Get the endpoint text
            endpoint_text = button.text
            print(f"📖 Extracting: {endpoint_text}")
            
            # Click to expand
            self.driver.execute_script("arguments[0].click();", button)
            time.sleep(2)
            
            # Extract the expanded content
            endpoint_info = {
                "title": endpoint_text,
                "method": "",
                "path": "",
                "description": "",
                "parameters": {},
                "response_format": "",
                "example_response": ""
            }
            
            # Parse method and path from title
            if "GET " in endpoint_text:
                endpoint_info["method"] = "GET"
                endpoint_info["path"] = endpoint_text.split("GET ")[1].split(" - ")[0]
            elif "POST " in endpoint_text:
                endpoint_info["method"] = "POST"
                endpoint_info["path"] = endpoint_text.split("POST ")[1].split(" - ")[0]
                
            # Extract description
            if " - " in endpoint_text:
                endpoint_info["description"] = endpoint_text.split(" - ", 1)[1]
            
            # Look for expanded content
            try:
                # Find the parent container and look for response examples
                parent = button.find_element(By.XPATH, "./following-sibling::*[1]")
                
                # Extract any JSON response examples
                code_blocks = parent.find_elements(By.TAG_NAME, "code")
                for code_block in code_blocks:
                    code_text = code_block.text
                    if code_text.strip().startswith("{"):
                        endpoint_info["example_response"] = code_text
                        break
                        
                # Extract any parameter information from the content
                content_text = parent.text
                endpoint_info["raw_content"] = content_text
                
            except NoSuchElementException:
                print(f"⚠️  Could not find expanded content for {endpoint_text}")
            
            return endpoint_info
            
        except Exception as e:
            print(f"❌ Error extracting {endpoint_text}: {str(e)}")
            return None
            
    def scrape_all_endpoints(self):
        """Scrape all endpoints systematically"""
        print("🚀 Starting comprehensive endpoint scraping...")
        
        self.navigate_to_docs()
        
        # Scroll to make sure all content is loaded
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)
        self.driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(2)
        
        # Find all endpoint buttons
        endpoint_buttons = self.find_all_endpoint_buttons()
        
        total_endpoints = len(endpoint_buttons)
        successful_extractions = 0
        
        for i, button in enumerate(endpoint_buttons, 1):
            print(f"\n📊 Progress: {i}/{total_endpoints}")
            
            try:
                endpoint_info = self.extract_endpoint_info(button)
                if endpoint_info:
                    # Use the path as the key
                    key = endpoint_info["path"] or f"endpoint_{i}"
                    self.documentation["endpoints"][key] = endpoint_info
                    successful_extractions += 1
                    
            except Exception as e:
                print(f"❌ Failed to process endpoint {i}: {str(e)}")
                continue
                
            # Small delay between extractions
            time.sleep(1)
            
        print(f"\n✅ Scraping complete!")
        print(f"📈 Successfully extracted {successful_extractions}/{total_endpoints} endpoints")
        
    def save_documentation(self, filename="scraped_api_docs.json"):
        """Save the scraped documentation to a file"""
        print(f"💾 Saving documentation to {filename}...")
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.documentation, f, indent=2, ensure_ascii=False)
            
        print(f"✅ Documentation saved successfully!")
        
    def generate_markdown_docs(self, filename="complete_api_documentation.md"):
        """Generate markdown documentation from scraped data"""
        print(f"📝 Generating markdown documentation...")
        
        markdown_content = f"""# SOLANA TRACKER API - COMPLETE DOCUMENTATION

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}

## ENDPOINTS ({len(self.documentation['endpoints'])} total)

"""
        
        for path, endpoint in self.documentation['endpoints'].items():
            markdown_content += f"""### {endpoint['method']} {endpoint['path']}

**Description**: {endpoint['description']}

**Method**: `{endpoint['method']}`
**Path**: `{endpoint['path']}`

"""
            if endpoint.get('example_response'):
                markdown_content += f"""**Response Example**:
```json
{endpoint['example_response']}
```

"""
            
            if endpoint.get('raw_content'):
                markdown_content += f"""**Additional Details**:
```
{endpoint['raw_content'][:500]}...
```

"""
            markdown_content += "---\n\n"
            
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
            
        print(f"✅ Markdown documentation generated!")
        
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            
    def run_full_scrape(self):
        """Run the complete scraping process"""
        try:
            self.scrape_all_endpoints()
            self.save_documentation()
            self.generate_markdown_docs()
            
        except Exception as e:
            print(f"❌ Scraping failed: {str(e)}")
            
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("🤖 Solana Tracker API Documentation Scraper")
    print("=" * 50)
    
    scraper = SolanaTrackerDocScraper()
    scraper.run_full_scrape()
    
    print("\n🎉 Scraping process completed!")

