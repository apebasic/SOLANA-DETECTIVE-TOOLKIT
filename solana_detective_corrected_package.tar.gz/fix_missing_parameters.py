#!/usr/bin/env python3
"""
Fix Missing Query Parameters in Solana Tracker API Documentation
Identifies endpoints missing query parameters and extracts them
"""

import json
import time
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait

class ParameterFixer:
    def __init__(self):
        self.setup_driver()
        self.base_url = "https://docs.solanatracker.io/public-data-api/docs"
        
        # Load existing documentation
        with open('FINAL_COMPLETE_SOLANA_API_DOCS.json', 'r') as f:
            self.documentation = json.load(f)
            
        # Endpoints that likely have query parameters based on common patterns
        self.endpoints_to_check = [
            "GET /price",
            "GET /price/history", 
            "GET /price/history/timestamp",
            "GET /price/history/range",
            "GET /price/multi",
            "POST /price/multi",
            "GET /tokens/trending",
            "GET /tokens/trending/{timeframe}",
            "GET /tokens/volume",
            "GET /tokens/volume/{timeframe}",
            "GET /tokens/latest",
            "GET /search",
            "GET /deployer/{wallet}",
            "GET /wallet/{owner}",
            "GET /wallet/{owner}/trades",
            "GET /wallet/{owner}/chart",
            "GET /trades/{tokenAddress}/{poolAddress}",
            "GET /trades/{tokenAddress}/{poolAddress}/{owner}",
            "GET /trades/{tokenAddress}/by-wallet/{owner}",
            "GET /chart/{token}",
            "GET /chart/{token}/{pool}",
            "GET /holders/chart/{token}",
            "GET /pnl/{wallet}",
            "GET /first-buyers/{token}",
            "GET /pnl/{wallet}/{token}",
            "GET /top-traders/all",
            "GET /top-traders/all/{page}",
            "GET /top-traders/{token}",
            "GET /stats/{token}",
            "GET /stats/{token}/{pool}",
            "GET /events/{tokenAddress}",
            "GET /events/{tokenAddress}/{poolAddress}"
        ]
        
    def setup_driver(self):
        """Setup Chrome driver"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 15)
        
    def generate_url(self, endpoint):
        """Generate URL for endpoint using correct pattern"""
        method, path = endpoint.split(" ", 1)
        # Remove slashes, braces, and hyphens, keep only words
        clean_path = re.sub(r'[/{}-]', '', path)
        url_fragment = f"{method.lower()}-{clean_path}"
        return f"{self.base_url}#{url_fragment}"
        
    def extract_query_parameters(self, endpoint):
        """Extract query parameters for a specific endpoint"""
        try:
            url = self.generate_url(endpoint)
            print(f"🔍 Checking: {endpoint}")
            print(f"🔗 URL: {url}")
            
            self.driver.get(url)
            time.sleep(3)
            
            # Get page text
            page_text = self.driver.execute_script("return document.body.innerText;")
            lines = page_text.split('\n')
            
            query_parameters = []
            in_query_params = False
            
            for i, line in enumerate(lines):
                line = line.strip()
                
                # Look for Query Parameters section
                if line == "Query Parameters":
                    in_query_params = True
                    print(f"   ✅ Found Query Parameters section")
                    continue
                elif in_query_params and line in ["Response", "Request Body", "Available Intervals", "Developer Tip:", ""]:
                    in_query_params = False
                elif in_query_params and line:
                    # Parse parameter: name (type): description
                    param_match = re.match(r'(\w+)\s*\(([^)]+)\):\s*(.+)', line)
                    if param_match:
                        param_name, param_type, param_desc = param_match.groups()
                        query_parameters.append({
                            "name": param_name,
                            "type": param_type.strip(),
                            "description": param_desc.strip(),
                            "required": "required" in param_type.lower()
                        })
                        print(f"   📋 Found parameter: {param_name} ({param_type})")
                        
            return query_parameters
            
        except Exception as e:
            print(f"❌ Error extracting {endpoint}: {str(e)}")
            return []
            
    def identify_missing_parameters(self):
        """Identify which endpoints are missing query parameters"""
        missing_params = []
        
        print("🔍 Analyzing current documentation for missing query parameters...")
        
        for endpoint_name, endpoint_doc in self.documentation['endpoints'].items():
            query_params = endpoint_doc.get('query_parameters', [])
            
            if len(query_params) == 0 and endpoint_name in self.endpoints_to_check:
                missing_params.append(endpoint_name)
                print(f"❌ Missing parameters: {endpoint_name}")
            else:
                print(f"✅ Has parameters: {endpoint_name} ({len(query_params)} params)")
                
        return missing_params
        
    def fix_missing_parameters(self):
        """Fix missing query parameters for identified endpoints"""
        missing_endpoints = self.identify_missing_parameters()
        
        print(f"\n🔧 Found {len(missing_endpoints)} endpoints missing query parameters")
        print("🚀 Starting parameter extraction...")
        
        fixed_count = 0
        
        for endpoint in missing_endpoints:
            print(f"\n📈 Progress: {fixed_count + 1}/{len(missing_endpoints)}")
            
            query_params = self.extract_query_parameters(endpoint)
            
            if query_params:
                # Update documentation
                self.documentation['endpoints'][endpoint]['query_parameters'] = query_params
                fixed_count += 1
                print(f"✅ Fixed: {endpoint} - Added {len(query_params)} parameters")
            else:
                print(f"⚠️  No parameters found: {endpoint}")
                
            time.sleep(2)  # Be respectful to the server
            
        print(f"\n🎉 Parameter fixing completed!")
        print(f"📈 Fixed: {fixed_count}/{len(missing_endpoints)} endpoints")
        
        # Save updated documentation
        self.save_updated_documentation()
        self.generate_updated_markdown()
        
    def save_updated_documentation(self):
        """Save updated documentation with fixed parameters"""
        filename = 'FIXED_COMPLETE_SOLANA_API_DOCS.json'
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.documentation, f, indent=2, ensure_ascii=False)
        print(f"💾 Updated documentation saved: {filename}")
        
    def generate_updated_markdown(self):
        """Generate updated markdown with fixed parameters"""
        print("📝 Generating updated markdown documentation...")
        
        markdown = f"""# SOLANA TRACKER API - COMPLETE DOCUMENTATION (FIXED)

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}
**Total Endpoints**: {self.documentation['total_endpoints']}
**Last Updated**: {time.strftime('%Y-%m-%d %H:%M:%S')}

## COMPLETE API REFERENCE WITH FIXED PARAMETERS

"""
        
        # Group endpoints by category
        categories = {
            "Token Endpoints": [],
            "Price Endpoints": [],
            "Wallet Endpoints": [],
            "Trade Endpoints": [],
            "Chart Data Endpoints": [],
            "PnL Data Endpoints": [],
            "Top Traders Endpoints": [],
            "Stats and Events Endpoints": [],
            "Credits Endpoints": []
        }
        
        # Categorize endpoints
        for endpoint_name, endpoint_doc in self.documentation['endpoints'].items():
            path = endpoint_doc.get('path', '')
            
            if path.startswith('/tokens'):
                categories["Token Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/price'):
                categories["Price Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/wallet'):
                categories["Wallet Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/trades'):
                categories["Trade Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/chart') or path.startswith('/holders'):
                categories["Chart Data Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/pnl') or path.startswith('/first-buyers'):
                categories["PnL Data Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/top-traders'):
                categories["Top Traders Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/stats') or path.startswith('/events'):
                categories["Stats and Events Endpoints"].append((endpoint_name, endpoint_doc))
            elif path.startswith('/credits'):
                categories["Credits Endpoints"].append((endpoint_name, endpoint_doc))
                
        # Generate detailed documentation
        for category, endpoints in categories.items():
            if endpoints:
                markdown += f"## {category}\n\n"
                
                for endpoint_name, endpoint_doc in endpoints:
                    markdown += f"### {endpoint_name}\n\n"
                    
                    if endpoint_doc.get('description'):
                        markdown += f"**Description**: {endpoint_doc['description']}\n\n"
                        
                    # Path Parameters
                    if endpoint_doc.get('path_parameters'):
                        markdown += "**Path Parameters**:\n"
                        for param in endpoint_doc['path_parameters']:
                            required = " (required)" if param.get('required') else " (optional)"
                            markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                        markdown += "\n"
                        
                    # Query Parameters (FIXED)
                    if endpoint_doc.get('query_parameters'):
                        markdown += "**Query Parameters**:\n"
                        for param in endpoint_doc['query_parameters']:
                            required = " (required)" if param.get('required') else " (optional)"
                            markdown += f"- `{param['name']}`{required}: {param['description']}\n"
                        markdown += "\n"
                        
                    # Available Intervals
                    if endpoint_doc.get('available_intervals'):
                        markdown += "**Available Intervals**: "
                        markdown += ", ".join(f"`{interval}`" for interval in endpoint_doc['available_intervals'])
                        markdown += "\n\n"
                        
                    # Pagination
                    if endpoint_doc.get('pagination_supported'):
                        markdown += "**Pagination**: Supported (cursor-based)\n\n"
                        
                    # Notes
                    if endpoint_doc.get('notes'):
                        markdown += "**Notes**:\n"
                        for note in endpoint_doc['notes']:
                            markdown += f"- {note}\n"
                        markdown += "\n"
                        
                    # Response Example
                    if endpoint_doc.get('example_response'):
                        markdown += f"**Response Example**:\n```json\n{endpoint_doc['example_response']}\n```\n\n"
                        
                    markdown += "---\n\n"
                    
        filename = 'FIXED_COMPLETE_SOLANA_TRACKER_API_DOCS.md'
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(markdown)
            
        print(f"✅ Updated markdown documentation generated: {filename}")
        
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            
    def run(self):
        """Run the parameter fixing process"""
        try:
            self.fix_missing_parameters()
        except Exception as e:
            print(f"❌ Parameter fixing failed: {str(e)}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("🔧 PARAMETER FIXER - Solana Tracker API Documentation")
    print("📋 Identifying and fixing missing query parameters")
    print("=" * 80)
    
    fixer = ParameterFixer()
    fixer.run()
    
    print("\n🎉 Parameter fixing completed!")
    print("📁 Check FIXED_COMPLETE_SOLANA_API_DOCS.json and .md files for results")

