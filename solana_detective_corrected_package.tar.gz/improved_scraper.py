#!/usr/bin/env python3
"""
Improved Solana Tracker API Documentation Scraper
Uses browser console to extract documentation more reliably
"""

import json
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class ImprovedDocScraper:
    def __init__(self):
        self.setup_driver()
        self.documentation = {
            "base_url": "https://data.solanatracker.io",
            "authentication": "x-api-key header",
            "endpoints": {}
        }
        
    def setup_driver(self):
        """Setup Chrome driver"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
    def navigate_and_extract(self):
        """Navigate to docs and extract using JavaScript"""
        print("🌐 Navigating to documentation...")
        self.driver.get("https://docs.solanatracker.io/public-data-api/docs")
        time.sleep(5)
        
        # Use JavaScript to extract all the documentation content
        extraction_script = """
        // Function to extract all endpoint documentation
        function extractAllEndpoints() {
            const endpoints = [];
            
            // Find all endpoint buttons
            const buttons = document.querySelectorAll('button[class*=""]');
            
            buttons.forEach((button, index) => {
                const text = button.textContent.trim();
                
                // Check if this looks like an endpoint button
                if (text.includes('GET ') || text.includes('POST ')) {
                    console.log('Processing:', text);
                    
                    // Click the button to expand
                    button.click();
                    
                    // Wait a bit for expansion
                    setTimeout(() => {
                        // Try to find the expanded content
                        const parent = button.parentElement;
                        const nextSibling = button.nextElementSibling;
                        
                        let expandedContent = '';
                        let responseExample = '';
                        
                        // Look for expanded content in various ways
                        if (nextSibling) {
                            expandedContent = nextSibling.textContent || '';
                            
                            // Look for JSON response examples
                            const codeBlocks = nextSibling.querySelectorAll('code, pre');
                            codeBlocks.forEach(block => {
                                const blockText = block.textContent.trim();
                                if (blockText.startsWith('{') && blockText.includes('"')) {
                                    responseExample = blockText;
                                }
                            });
                        }
                        
                        // Extract method and path
                        let method = '';
                        let path = '';
                        let description = '';
                        
                        if (text.includes('GET ')) {
                            method = 'GET';
                            const parts = text.split('GET ')[1].split(' - ');
                            path = parts[0];
                            description = parts[1] || '';
                        } else if (text.includes('POST ')) {
                            method = 'POST';
                            const parts = text.split('POST ')[1].split(' - ');
                            path = parts[0];
                            description = parts[1] || '';
                        }
                        
                        endpoints.push({
                            title: text,
                            method: method,
                            path: path,
                            description: description,
                            expanded_content: expandedContent,
                            response_example: responseExample,
                            index: index
                        });
                        
                    }, 100);
                }
            });
            
            return endpoints;
        }
        
        // Also extract the visible documentation content
        function extractVisibleContent() {
            const content = document.body.textContent;
            return content;
        }
        
        return {
            endpoints: extractAllEndpoints(),
            page_content: extractVisibleContent()
        };
        """
        
        print("🔍 Extracting documentation using JavaScript...")
        result = self.driver.execute_script(extraction_script)
        
        # Wait for expansions to complete
        time.sleep(10)
        
        # Get the final page content
        final_content = self.driver.execute_script("return document.body.textContent;")
        
        return result, final_content
        
    def parse_page_content(self, content):
        """Parse the page content to extract endpoint information"""
        print("📝 Parsing page content...")
        
        lines = content.split('\n')
        current_endpoint = None
        in_response = False
        response_lines = []
        
        for line in lines:
            line = line.strip()
            
            # Check for endpoint headers
            if ('GET /' in line or 'POST /' in line) and (' - ' in line):
                # Save previous endpoint if exists
                if current_endpoint and response_lines:
                    current_endpoint['response_example'] = '\n'.join(response_lines)
                    
                # Start new endpoint
                current_endpoint = {
                    'title': line,
                    'method': 'GET' if line.startswith('GET') else 'POST',
                    'path': '',
                    'description': '',
                    'response_example': ''
                }
                
                # Parse path and description
                if 'GET /' in line:
                    parts = line.split('GET ')[1].split(' - ')
                    current_endpoint['path'] = parts[0]
                    current_endpoint['description'] = parts[1] if len(parts) > 1 else ''
                elif 'POST /' in line:
                    parts = line.split('POST ')[1].split(' - ')
                    current_endpoint['path'] = parts[0]
                    current_endpoint['description'] = parts[1] if len(parts) > 1 else ''
                    
                self.documentation['endpoints'][current_endpoint['path']] = current_endpoint
                in_response = False
                response_lines = []
                
            # Check for response sections
            elif line == 'Response' and current_endpoint:
                in_response = True
                response_lines = []
                
            # Collect response content
            elif in_response and line.startswith('{'):
                response_lines.append(line)
                
            # Stop collecting when we hit next section
            elif in_response and (line.startswith('GET ') or line.startswith('POST ') or 
                                line in ['Parameters', 'Request', 'Example']):
                in_response = False
                
        # Save last endpoint
        if current_endpoint and response_lines:
            current_endpoint['response_example'] = '\n'.join(response_lines)
            
    def run_extraction(self):
        """Run the complete extraction process"""
        try:
            result, page_content = self.navigate_and_extract()
            
            # Parse the page content
            self.parse_page_content(page_content)
            
            print(f"✅ Extracted {len(self.documentation['endpoints'])} endpoints")
            
            # Save results
            with open('scraped_documentation.json', 'w') as f:
                json.dump(self.documentation, f, indent=2)
                
            # Generate markdown
            self.generate_markdown()
            
        except Exception as e:
            print(f"❌ Extraction failed: {str(e)}")
            
        finally:
            self.driver.quit()
            
    def generate_markdown(self):
        """Generate markdown documentation"""
        print("📝 Generating markdown documentation...")
        
        markdown = f"""# SOLANA TRACKER API - COMPLETE DOCUMENTATION

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}

## ENDPOINTS ({len(self.documentation['endpoints'])} total)

"""
        
        for path, endpoint in self.documentation['endpoints'].items():
            markdown += f"""### {endpoint['method']} {endpoint['path']}

**Description**: {endpoint['description']}

"""
            if endpoint.get('response_example'):
                markdown += f"""**Response Example**:
```json
{endpoint['response_example']}
```

"""
            markdown += "---\n\n"
            
        with open('complete_api_documentation.md', 'w') as f:
            f.write(markdown)
            
        print("✅ Markdown documentation generated!")

if __name__ == "__main__":
    print("🤖 Improved Solana Tracker API Documentation Scraper")
    print("=" * 60)
    
    scraper = ImprovedDocScraper()
    scraper.run_extraction()
    
    print("\n🎉 Extraction completed!")

