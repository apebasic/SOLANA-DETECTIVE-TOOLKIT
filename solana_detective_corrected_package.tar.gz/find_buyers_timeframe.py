#!/usr/bin/env python3
"""
Find all wallets that bought a token in a specific time window using trades endpoint
"""

import requests
import json
from datetime import datetime, timezone, timedelta
import pytz
import time

def find_all_buyers_in_timeframe():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    
    token_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    
    print(f"🔍 Finding ALL buyers for token: {token_address}")
    print(f"⏰ Target time window: 3:00pm - 3:10pm EST")
    print("=" * 80)
    
    # Step 1: Get token information to find pool address
    print(f"📊 Step 1: Getting token information...")
    try:
        token_url = f'https://data.solanatracker.io/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ Error getting token info: {response.text}")
            return
        
        token_data = response.json()
        
        # Extract pool address (use the first pool with highest volume)
        pool_address = None
        if 'pools' in token_data and token_data['pools']:
            # Sort pools by transaction volume to get the most active one
            pools = token_data['pools']
            active_pools = [p for p in pools if p.get('txns', {}).get('total', 0) > 0]
            if active_pools:
                # Get pool with highest volume
                best_pool = max(active_pools, key=lambda p: p.get('txns', {}).get('total', 0))
                pool_address = best_pool.get('poolId')
            else:
                # Fallback to first pool
                pool_address = pools[0].get('poolId')
        
        if not pool_address:
            print(f"❌ Could not find pool address for token")
            return
        
        print(f"✅ Found pool address: {pool_address}")
        
    except Exception as e:
        print(f"❌ Exception getting token info: {e}")
        return
    
    # Step 2: Get all trades for the token/pool
    print(f"\n📊 Step 2: Getting all trades for token/pool...")
    
    all_trades = []
    cursor = None
    page = 1
    
    try:
        while True:
            print(f"   📄 Fetching page {page}...")
            
            # Build URL with cursor if available
            trades_url = f'https://data.solanatracker.io/trades/{token_address}/{pool_address}'
            params = {}
            if cursor:
                params['cursor'] = cursor
            
            response = requests.get(trades_url, headers=headers, params=params, timeout=30)
            
            if response.status_code != 200:
                print(f"❌ Error getting trades: {response.text}")
                break
            
            trades_data = response.json()
            
            # Check if we have trades
            if 'trades' not in trades_data or not trades_data['trades']:
                print(f"   ✅ No more trades found")
                break
            
            trades = trades_data['trades']
            all_trades.extend(trades)
            
            print(f"   ✅ Found {len(trades)} trades on page {page} (Total: {len(all_trades)})")
            
            # Check for pagination
            if not trades_data.get('hasNextPage', False):
                print(f"   ✅ Reached last page")
                break
            
            cursor = trades_data.get('nextCursor')
            if not cursor:
                print(f"   ✅ No next cursor available")
                break
            
            page += 1
            time.sleep(0.2)  # Be nice to API
            
            # Safety limit
            if page > 50:
                print(f"   ⚠️ Reached safety limit of 50 pages")
                break
        
        print(f"\n✅ Total trades collected: {len(all_trades)}")
        
    except Exception as e:
        print(f"❌ Exception getting trades: {e}")
        return
    
    if not all_trades:
        print(f"❌ No trades found for this token")
        return
    
    # Step 3: Filter trades by time window
    print(f"\n📊 Step 3: Filtering trades by time window...")
    
    # Define EST timezone
    est = pytz.timezone('US/Eastern')
    
    # Find the date range of trades
    trade_times = [trade.get('time', 0) for trade in all_trades if trade.get('time')]
    if not trade_times:
        print(f"❌ No valid trade times found")
        return
    
    earliest = min(trade_times)
    latest = max(trade_times)
    earliest_date = datetime.fromtimestamp(earliest / 1000, tz=est)
    latest_date = datetime.fromtimestamp(latest / 1000, tz=est)
    
    print(f"📊 Trade time range:")
    print(f"   Earliest: {earliest_date}")
    print(f"   Latest: {latest_date}")
    
    # Check all possible 3:00-3:10pm EST windows
    current_date = earliest_date.date()
    end_date = latest_date.date()
    
    matching_trades = []
    
    while current_date <= end_date:
        # Create 3:00pm and 3:10pm EST for this date
        start_time = est.localize(datetime.combine(current_date, datetime.min.time().replace(hour=15, minute=0)))
        end_time = est.localize(datetime.combine(current_date, datetime.min.time().replace(hour=15, minute=10)))
        
        # Convert to milliseconds timestamp
        start_timestamp = int(start_time.timestamp() * 1000)
        end_timestamp = int(end_time.timestamp() * 1000)
        
        print(f"\n🔍 Checking {current_date} 3:00-3:10pm EST:")
        print(f"   Start: {start_time}")
        print(f"   End: {end_time}")
        
        # Find trades in this time window
        day_matches = []
        for trade in all_trades:
            trade_time = trade.get('time')
            if trade_time and start_timestamp <= trade_time <= end_timestamp:
                trade_datetime = datetime.fromtimestamp(trade_time / 1000, tz=est)
                
                # Only include BUY trades
                if trade.get('type') == 'buy':
                    day_matches.append({
                        'wallet': trade.get('owner'),
                        'trade_time': trade_time,
                        'trade_datetime': trade_datetime,
                        'amount': trade.get('amount', 0),
                        'volume_usd': trade.get('volumeUsd', 0),
                        'price': trade.get('price', 0),
                        'signature': trade.get('signature', ''),
                        'type': trade.get('type', ''),
                        'from': trade.get('from', ''),
                        'to': trade.get('to', '')
                    })
        
        if day_matches:
            print(f"   ✅ Found {len(day_matches)} BUY trades")
            matching_trades.extend(day_matches)
            
            # Sort by time
            day_matches.sort(key=lambda x: x['trade_time'])
            
            # Show first few trades
            for i, match in enumerate(day_matches[:10], 1):
                wallet = match['wallet']
                time_str = match['trade_datetime'].strftime('%H:%M:%S')
                volume = match['volume_usd']
                amount = match['amount']
                
                print(f"      #{i}: {wallet}")
                print(f"          Time: {time_str} EST")
                print(f"          Volume: ${volume:.4f}")
                print(f"          Amount: {amount:.4f}")
            
            if len(day_matches) > 10:
                print(f"      ... and {len(day_matches) - 10} more trades")
        else:
            print(f"   ❌ No BUY trades found")
        
        current_date += timedelta(days=1)
    
    # Step 4: Generate final report
    print(f"\n" + "="*80)
    print(f"📊 FINAL RESULTS")
    print(f"="*80)
    
    if matching_trades:
        print(f"✅ Total BUY trades found: {len(matching_trades)}")
        print(f"💰 Total volume: ${sum(t['volume_usd'] for t in matching_trades):.2f}")
        
        # Get unique wallets
        unique_wallets = {}
        for trade in matching_trades:
            wallet = trade['wallet']
            if wallet not in unique_wallets:
                unique_wallets[wallet] = {
                    'trades': [],
                    'total_volume': 0,
                    'total_amount': 0
                }
            unique_wallets[wallet]['trades'].append(trade)
            unique_wallets[wallet]['total_volume'] += trade['volume_usd']
            unique_wallets[wallet]['total_amount'] += trade['amount']
        
        print(f"👥 Unique wallets: {len(unique_wallets)}")
        
        print(f"\n🎯 ALL WALLETS THAT BOUGHT 3:00-3:10PM EST:")
        print(f"-" * 80)
        
        # Sort wallets by total volume
        sorted_wallets = sorted(unique_wallets.items(), 
                              key=lambda x: x[1]['total_volume'], reverse=True)
        
        for i, (wallet, data) in enumerate(sorted_wallets, 1):
            trades_count = len(data['trades'])
            total_volume = data['total_volume']
            total_amount = data['total_amount']
            
            # Get first trade time
            first_trade = min(data['trades'], key=lambda x: x['trade_time'])
            first_time = first_trade['trade_datetime'].strftime('%m-%d %H:%M:%S')
            
            print(f"{i:2d}. {wallet}")
            print(f"    📊 {trades_count} trade(s) | First: {first_time} EST")
            print(f"    💰 Volume: ${total_volume:.4f} | Amount: {total_amount:.4f}")
            
            # Show individual trades if multiple
            if trades_count > 1:
                print(f"    📋 Trade times:")
                for trade in sorted(data['trades'], key=lambda x: x['trade_time']):
                    time_str = trade['trade_datetime'].strftime('%H:%M:%S')
                    print(f"        • {time_str}: ${trade['volume_usd']:.4f}")
            
            print()
        
        # Summary statistics
        print(f"📈 SUMMARY STATISTICS:")
        print(f"="*40)
        print(f"Total trades: {len(matching_trades)}")
        print(f"Unique wallets: {len(unique_wallets)}")
        print(f"Average trades per wallet: {len(matching_trades)/len(unique_wallets):.1f}")
        print(f"Total volume: ${sum(t['volume_usd'] for t in matching_trades):.2f}")
        print(f"Average volume per trade: ${sum(t['volume_usd'] for t in matching_trades)/len(matching_trades):.4f}")
        
        # Top traders
        print(f"\n💰 TOP 5 TRADERS BY VOLUME:")
        print(f"="*40)
        for i, (wallet, data) in enumerate(sorted_wallets[:5], 1):
            print(f"#{i} {wallet}: ${data['total_volume']:.4f}")
        
    else:
        print(f"❌ No BUY trades found between 3:00-3:10pm EST on any day")
        print(f"💡 The token may have had trading activity outside this time window")

if __name__ == "__main__":
    find_all_buyers_in_timeframe()

