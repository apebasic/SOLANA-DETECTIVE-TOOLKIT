#!/usr/bin/env python3

import requests
import json
from datetime import datetime
import pytz

api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
headers = {'x-api-key': api_key, 'accept': 'application/json'}
token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"

print("🔍 DEBUGGING LINGANG TRADES")
print("=" * 50)

# Get recent trades without time filter to see what's available
trades_url = f'https://data.solanatracker.io/trades/{token_address}/{token_address}'
params = {'limit': 10}

response = requests.get(trades_url, headers=headers, params=params, timeout=30)

if response.status_code == 200:
    trades_data = response.json()
    trades = trades_data.get('trades', [])
    
    print(f"✅ Got {len(trades)} recent trades")
    
    est = pytz.timezone('US/Eastern')
    
    for i, trade in enumerate(trades[:5], 1):
        trade_time = trade.get('time', 0)
        volume = trade.get('volume', 0)
        owner = trade.get('owner', 'Unknown')
        amount = trade.get('amount', 0)
        
        # Convert to EST
        trade_datetime = datetime.fromtimestamp(trade_time, tz=est)
        
        print(f"\n{i}. Trade:")
        print(f"   Time: {trade_datetime} EST")
        print(f"   Volume: ${volume}")
        print(f"   Amount: {amount}")
        print(f"   Owner: {owner[:8]}...")
        print(f"   Raw timestamp: {trade_time}")
        
        # Check if this is a buy or sell
        if volume > 0:
            print(f"   Type: BUY ✅")
        else:
            print(f"   Type: SELL ❌")
    
    # Check target timeframe
    target_start = 1750953380  # 11:56:20am EST
    target_end = 1750953740    # 12:02:20pm EST
    
    print(f"\n🎯 TARGET TIMEFRAME:")
    print(f"   Start: {target_start} ({datetime.fromtimestamp(target_start, tz=est)})")
    print(f"   End: {target_end} ({datetime.fromtimestamp(target_end, tz=est)})")
    
    # Check if any trades fall in target range
    target_trades = [t for t in trades if target_start <= t.get('time', 0) <= target_end]
    print(f"\n📊 Trades in target timeframe: {len(target_trades)}")
    
    if target_trades:
        for trade in target_trades:
            trade_time = datetime.fromtimestamp(trade.get('time', 0), tz=est)
            print(f"   - {trade_time}: ${trade.get('volume', 0)} by {trade.get('owner', '')[:8]}...")
    
else:
    print(f"❌ Error: {response.text}")
