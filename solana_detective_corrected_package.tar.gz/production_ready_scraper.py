#!/usr/bin/env python3
"""
Production-Ready Solana Tracker API Documentation Scraper
Extracts complete documentation with all parameters, intervals, and response formats
"""

import json
import time
import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait

class ProductionDocScraper:
    def __init__(self):
        self.setup_driver()
        self.base_url = "https://docs.solanatracker.io/public-data-api/docs"
        
        # Complete endpoint inventory with correct URL fragments
        self.endpoints = {
            # Token Endpoints (13)
            "GET /tokens/{tokenAddress}": f"{self.base_url}#get-tokenstokenaddress",
            "GET /tokens/by-pool/{poolAddress}": f"{self.base_url}#get-tokensby-poolpooladdress",
            "GET /tokens/{tokenAddress}/holders": f"{self.base_url}#get-tokenstokenaddressholders",
            "GET /tokens/{tokenAddress}/holders/top": f"{self.base_url}#get-tokenstokenaddressholderstop",
            "GET /tokens/{tokenAddress}/ath": f"{self.base_url}#get-tokenstokenaddressath",
            "GET /deployer/{wallet}": f"{self.base_url}#get-deployerwallet",
            "GET /search": f"{self.base_url}#get-search",
            "GET /tokens/latest": f"{self.base_url}#get-tokenslatest",
            "POST /tokens/multi": f"{self.base_url}#post-tokensmulti",
            "GET /tokens/trending": f"{self.base_url}#get-tokenstrending",
            "GET /tokens/volume": f"{self.base_url}#get-tokensvolume",
            "GET /tokens/multi/all": f"{self.base_url}#get-tokensmultiall",
            "GET /tokens/multi/graduated": f"{self.base_url}#get-tokensmultigraduated",
            
            # Price Endpoints (6)
            "GET /price": f"{self.base_url}#get-price",
            "GET /price/history": f"{self.base_url}#get-pricehistory",
            "GET /price/history/timestamp": f"{self.base_url}#get-pricehistorytimestamp",
            "GET /price/history/range": f"{self.base_url}#get-pricehistoryrange",
            "POST /price": f"{self.base_url}#post-price",
            "GET/POST /price/multi": f"{self.base_url}#get-pricemulti",
            
            # Wallet Endpoints (Need to verify count - user says 8)
            "GET /wallet/{owner}": f"{self.base_url}#get-walletowner",
            "GET /wallet/{owner}/basic": f"{self.base_url}#get-walletownerbasic",
            "GET /wallet/{owner}/page/{page}": f"{self.base_url}#get-walletownerpagepage",
            "GET /wallet/{owner}/trades": f"{self.base_url}#get-walletownertrades",
            "GET /wallet/{owner}/chart": f"{self.base_url}#get-walletownerchart",
            
            # Trade Endpoints (3)
            "GET /trades/{tokenAddress}/{poolAddress}": f"{self.base_url}#get-tradestokenaddresspooladdress",
            "GET /trades/{tokenAddress}/{poolAddress}/{owner}": f"{self.base_url}#get-tradestokenaddresspooladdressowner",
            "GET /trades/{tokenAddress}/by-wallet/{owner}": f"{self.base_url}#get-tradestokenaddressby-walletowner",
            
            # Chart Data (2)
            "GET /chart/{token}": f"{self.base_url}#get-charttoken",
            "GET /holders/chart/{token}": f"{self.base_url}#get-holderscharttoken",
            
            # PnL Data (3)
            "GET /pnl/{wallet}": f"{self.base_url}#get-pnlwallet",
            "GET /first-buyers/{token}": f"{self.base_url}#get-first-buyerstoken",
            "GET /pnl/{wallet}/{token}": f"{self.base_url}#get-pnlwallettoken",
            
            # Top Traders (2)
            "GET /top-traders/all": f"{self.base_url}#get-top-tradersall",
            "GET /top-traders/{token}": f"{self.base_url}#get-top-traderstoken",
            
            # Stats and Live Events (3)
            "GET /stats/{token}": f"{self.base_url}#get-statstoken",
            "GET /events/{tokenAddress}": f"{self.base_url}#get-eventstokenaddress",
            "GET /events/{tokenAddress}/{poolAddress}": f"{self.base_url}#get-eventstokenaddresspooladdress",
            
            # Credits (1)
            "GET /credits": f"{self.base_url}#get-credits"
        }
        
        self.documentation = {
            "base_url": "https://data.solanatracker.io",
            "authentication": "x-api-key header",
            "total_endpoints": len(self.endpoints),
            "endpoints": {}
        }
        
    def setup_driver(self):
        """Setup Chrome driver"""
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 10)
        
    def extract_complete_endpoint_docs(self, endpoint_name, url):
        """Extract complete documentation for a single endpoint"""
        try:
            print(f"📖 Extracting: {endpoint_name}")
            self.driver.get(url)
            time.sleep(3)
            
            # Get complete page content
            page_content = self.driver.page_source
            text_content = self.driver.execute_script("return document.body.textContent;")
            
            # Parse comprehensive endpoint information
            endpoint_info = {
                "endpoint": endpoint_name,
                "url": url,
                "method": endpoint_name.split()[0],
                "path": endpoint_name.split(" ", 1)[1] if " " in endpoint_name else "",
                "description": "",
                "query_parameters": [],
                "path_parameters": [],
                "request_body": "",
                "response_format": "",
                "example_response": "",
                "available_intervals": [],
                "notes": [],
                "pagination": False
            }
            
            # Extract detailed information from content
            lines = text_content.split('\n')
            
            # Extract description
            for line in lines:
                line = line.strip()
                if ("Gets " in line or "Retrieves " in line or "Returns " in line) and len(line) < 200:
                    endpoint_info["description"] = line
                    break
                    
            # Extract query parameters
            in_query_params = False
            in_response = False
            response_lines = []
            
            for i, line in enumerate(lines):
                line = line.strip()
                
                # Query Parameters section
                if line == "Query Parameters":
                    in_query_params = True
                    continue
                elif in_query_params and (line.startswith("Response") or line.startswith("Request Body")):
                    in_query_params = False
                elif in_query_params and line and not line.startswith("Note:"):
                    # Parse parameter format: parameter_name (optional/required): description
                    if "(" in line and "):" in line:
                        param_match = re.match(r'(\w+)\s*\(([^)]+)\):\s*(.+)', line)
                        if param_match:
                            param_name, param_type, param_desc = param_match.groups()
                            endpoint_info["query_parameters"].append({
                                "name": param_name,
                                "type": param_type,
                                "description": param_desc
                            })
                
                # Available Intervals section (for chart endpoints)
                if line == "Available Intervals":
                    # Look for interval table in next lines
                    for j in range(i+1, min(i+20, len(lines))):
                        interval_line = lines[j].strip()
                        if interval_line and not interval_line.startswith("Shorthand") and not interval_line.startswith("Note"):
                            # Extract intervals like "1s", "1m", etc.
                            intervals = re.findall(r'\b\d+[smhdw]|\d+mn\b', interval_line)
                            endpoint_info["available_intervals"].extend(intervals)
                
                # Response section
                if line == "Response":
                    in_response = True
                    response_lines = []
                    continue
                elif in_response and line.startswith('{'):
                    response_lines.append(line)
                elif in_response and (line.startswith('GET ') or line.startswith('POST ') or 
                                    line.startswith('###') or line == ""):
                    if response_lines:
                        in_response = False
                        
            # Join response lines
            if response_lines:
                endpoint_info["example_response"] = '\n'.join(response_lines)
                
            # Check for pagination
            if "cursor" in text_content.lower() or "page" in text_content.lower():
                endpoint_info["pagination"] = True
                
            return endpoint_info
            
        except Exception as e:
            print(f"❌ Error extracting {endpoint_name}: {str(e)}")
            return None
            
    def run_production_extraction(self):
        """Run complete production-ready extraction"""
        print("🚀 Starting PRODUCTION-READY documentation extraction...")
        print(f"📊 Total endpoints to process: {len(self.endpoints)}")
        
        successful_extractions = 0
        failed_extractions = []
        
        for i, (endpoint_name, url) in enumerate(self.endpoints.items(), 1):
            print(f"\n📈 Progress: {i}/{len(self.endpoints)}")
            
            try:
                endpoint_info = self.extract_complete_endpoint_docs(endpoint_name, url)
                
                if endpoint_info:
                    self.documentation["endpoints"][endpoint_name] = endpoint_info
                    successful_extractions += 1
                    print(f"✅ Successfully extracted: {endpoint_name}")
                else:
                    failed_extractions.append(endpoint_name)
                    print(f"⚠️  Failed to extract: {endpoint_name}")
                    
            except Exception as e:
                failed_extractions.append(endpoint_name)
                print(f"❌ Failed to process {endpoint_name}: {str(e)}")
                continue
                
            # Delay between requests
            time.sleep(2)
            
        print(f"\n🎉 Extraction completed!")
        print(f"📈 Successfully extracted: {successful_extractions}/{len(self.endpoints)}")
        
        if failed_extractions:
            print(f"❌ Failed extractions: {len(failed_extractions)}")
            for failed in failed_extractions:
                print(f"   - {failed}")
        
        # Save results
        self.save_production_docs()
        self.generate_production_markdown()
        self.run_quality_control()
        
    def save_production_docs(self):
        """Save production documentation to JSON"""
        with open('PRODUCTION_SOLANA_API_DOCS.json', 'w', encoding='utf-8') as f:
            json.dump(self.documentation, f, indent=2, ensure_ascii=False)
        print("💾 Production JSON documentation saved!")
        
    def generate_production_markdown(self):
        """Generate production-ready markdown documentation"""
        print("📝 Generating production markdown documentation...")
        
        markdown = f"""# SOLANA TRACKER API - PRODUCTION DOCUMENTATION

**Base URL**: `{self.documentation['base_url']}`
**Authentication**: {self.documentation['authentication']}
**Total Endpoints**: {self.documentation['total_endpoints']}

## COMPLETE ENDPOINT DOCUMENTATION

"""
        
        # Group by category
        categories = {
            "Token Endpoints": [],
            "Price Endpoints": [],
            "Wallet Endpoints": [],
            "Trade Endpoints": [],
            "Chart Data": [],
            "PnL Data": [],
            "Top Traders": [],
            "Stats and Events": [],
            "Credits": []
        }
        
        for endpoint_name, endpoint_info in self.documentation['endpoints'].items():
            path = endpoint_info.get('path', '')
            
            if path.startswith('/tokens'):
                categories["Token Endpoints"].append((endpoint_name, endpoint_info))
            elif path.startswith('/price'):
                categories["Price Endpoints"].append((endpoint_name, endpoint_info))
            elif path.startswith('/wallet'):
                categories["Wallet Endpoints"].append((endpoint_name, endpoint_info))
            elif path.startswith('/trades'):
                categories["Trade Endpoints"].append((endpoint_name, endpoint_info))
            elif path.startswith('/chart') or path.startswith('/holders'):
                categories["Chart Data"].append((endpoint_name, endpoint_info))
            elif path.startswith('/pnl') or path.startswith('/first-buyers'):
                categories["PnL Data"].append((endpoint_name, endpoint_info))
            elif path.startswith('/top-traders'):
                categories["Top Traders"].append((endpoint_name, endpoint_info))
            elif path.startswith('/stats') or path.startswith('/events'):
                categories["Stats and Events"].append((endpoint_name, endpoint_info))
            elif path.startswith('/credits'):
                categories["Credits"].append((endpoint_name, endpoint_info))
                
        # Generate detailed documentation by category
        for category, endpoints in categories.items():
            if endpoints:
                markdown += f"## {category}\n\n"
                
                for endpoint_name, endpoint_info in endpoints:
                    markdown += f"### {endpoint_name}\n\n"
                    
                    if endpoint_info.get('description'):
                        markdown += f"**Description**: {endpoint_info['description']}\n\n"
                        
                    # Query Parameters
                    if endpoint_info.get('query_parameters'):
                        markdown += "**Query Parameters**:\n"
                        for param in endpoint_info['query_parameters']:
                            markdown += f"- `{param['name']}` ({param['type']}): {param['description']}\n"
                        markdown += "\n"
                        
                    # Available Intervals
                    if endpoint_info.get('available_intervals'):
                        markdown += "**Available Intervals**: "
                        markdown += ", ".join(endpoint_info['available_intervals'])
                        markdown += "\n\n"
                        
                    # Pagination
                    if endpoint_info.get('pagination'):
                        markdown += "**Pagination**: Supported\n\n"
                        
                    # Response Example
                    if endpoint_info.get('example_response'):
                        markdown += f"**Response Example**:\n```json\n{endpoint_info['example_response']}\n```\n\n"
                        
                    markdown += "---\n\n"
                    
        with open('PRODUCTION_SOLANA_TRACKER_API_DOCS.md', 'w', encoding='utf-8') as f:
            f.write(markdown)
            
        print("✅ Production markdown documentation generated!")
        
    def run_quality_control(self):
        """Run quality control checks"""
        print("\n🔍 Running Quality Control...")
        
        total_endpoints = len(self.endpoints)
        extracted_endpoints = len(self.documentation['endpoints'])
        
        print(f"📊 Endpoint Coverage: {extracted_endpoints}/{total_endpoints} ({extracted_endpoints/total_endpoints*100:.1f}%)")
        
        # Check for missing critical information
        missing_descriptions = 0
        missing_parameters = 0
        missing_responses = 0
        
        for endpoint_name, endpoint_info in self.documentation['endpoints'].items():
            if not endpoint_info.get('description'):
                missing_descriptions += 1
            if not endpoint_info.get('query_parameters') and not endpoint_info.get('path_parameters'):
                missing_parameters += 1
            if not endpoint_info.get('example_response'):
                missing_responses += 1
                
        print(f"📝 Missing Descriptions: {missing_descriptions}")
        print(f"🔧 Missing Parameters: {missing_parameters}")
        print(f"📄 Missing Responses: {missing_responses}")
        
        if extracted_endpoints == total_endpoints and missing_descriptions == 0:
            print("✅ QUALITY CONTROL PASSED - Production Ready!")
        else:
            print("⚠️  QUALITY CONTROL ISSUES - Needs Review")
            
    def cleanup(self):
        """Clean up resources"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            
    def run(self):
        """Run the complete production process"""
        try:
            self.run_production_extraction()
        except Exception as e:
            print(f"❌ Production process failed: {str(e)}")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("🏭 PRODUCTION-READY Solana Tracker API Documentation Scraper")
    print("=" * 80)
    
    scraper = ProductionDocScraper()
    scraper.run()
    
    print("\n🎉 Production documentation extraction completed!")

