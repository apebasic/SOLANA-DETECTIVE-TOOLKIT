# SOLANA TRACKER API - COMPLETE DOCUMENTATION

**Base URL**: `https://data.solanatracker.io`
**Authentication**: x-api-key header

## ENDPOINTS (34 total)

### POST /tokens/{tokenAddress}

**Description**: 

---

### POST /tokens/by-pool/{poolAddress}

**Description**: Get Token by Pool Address

---

### POST /tokens/{tokenAddress}/holders

**Description**: Get Token Holders

---

### POST /tokens/{tokenAddress}/holders/top

**Description**: Get Top 20 Token Holders

---

### POST /tokens/{tokenAddress}/ath

**Description**: Get All-Time High Price

---

### POST /deployer/{wallet}

**Description**: Get Tokens by Deployer

---

### POST /search

**Description**: Advanced Token Search

---

### POST /tokens/latest

**Description**: Get Latest Tokens

---

### POST /tokens/multi

**Description**: Get Multiple Tokens

---

### POST /tokens/trending

**Description**: Get Trending Tokens

---

### POST /tokens/multi/graduated

**Description**: Get Graduated Tokens

---

### GET /price

**Description**: Get Token Price

---

### POST /price/history

**Description**: Get Historic Price Information

---

### POST /price/history/timestamp

**Description**: Get Price at Specific Timestamp

---

### POST /price/history/range

**Description**: Get lowest and highest price in time range

---

### POST /price, but accepts token address in the request body.Test in the Data API Playground ->Request Body[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}{

**Description**: 

---

### POST /price/multiGets price information for multiple tokens (up to 100).Test in the Data API Playground ->Query Parameters

**Description**: 

---

### GET /wallet/{owner}

**Description**: Get Wallet Tokens

---

### POST /wallet/{owner}/basic

**Description**: Get Basic Wallet Information

---

### POST /wallet/{owner}/page/{page}

**Description**: Get Wallet Tokens with Pagination

---

### POST /wallet/{owner}/chart

**Description**: Get Wallet Portfolio Chart

---

### POST /trades/{tokenAddress}

**Description**: Get Token Trades">

**Response Example**:
```json
{
{
{
```

---

### POST /trades/{tokenAddress}/{poolAddress}

**Description**: Get Pool-Specific Trades

---

### GET /chart/{token}

**Description**: Get OHLCV Data for a token / pool

---

### POST /holders/chart/{token}

**Description**: Get Holders Chart Data

---

### GET /pnl/{wallet}

**Description**: Get Wallet PnL

---

### POST /first-buyers/{token}

**Description**: Get First Token Buyers

---

### POST /pnl/{wallet}/{token}

**Description**: Get Token-Specific PnL

---

### GET /top-traders/all

**Description**: Get Top Traders (All Tokens)

---

### POST /top-traders/{token}

**Description**: Get Top Traders for Specific Token

---

### GET /stats/{token}

**Description**: Get Token Stats

---

### POST /events/{tokenAddress}

**Description**: Get Token Events

---

### POST /events/{tokenAddress}/{poolAddress}

**Description**: Get Pool Events

---

### GET /credits

**Description**: Get API Credits

---

