#!/usr/bin/env python3
"""
Interactive KOL Alt Wallet Detection Tool - FREE VERSION - Updated with Block Conversion Prerequisite

This script provides an easy-to-use interface for the KOL alt wallet detection tool
using Solana Tracker API (FREE TIER: 10,000 requests/month).

UPDATED: All time-based queries now use block number conversion for efficiency
"""

import json
import os
from kol_alt_detector_free import KOLAltWalletDetectorFree
from solana_time_utils import convert_est_timeframe_to_optimized_query, SolanaTimeConverter
import logging
from datetime import datetime, timedelta
import pytz

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_user_input():
    """Get input from user interactively"""
    print("=== KOL Alt Wallet Detection Tool - FREE VERSION ===")
    print("Uses Solana Tracker API (Free Tier: 10,000 requests/month)")
    print()
    
    # Get API key
    print("🔑 Get your FREE API key at: https://solanatracker.io")
    print("   - No credit card required")
    print("   - 10,000 requests/month free")
    print("   - Perfect for KOL analysis")
    print()
    api_key = input("Enter your Solana Tracker API key: ").strip()
    if not api_key:
        print("API key is required!")
        return None
    
    # Get KOL wallet address
    kol_wallet = input("Enter KOL's public wallet address: ").strip()
    if not kol_wallet:
        print("KOL wallet address is required!")
        return None
    
    # Get token addresses
    print("\nEnter token contract addresses (one per line, press Enter twice when done):")
    print("💡 Tip: Use tokens the KOL recently promoted or mentioned")
    token_addresses = []
    while True:
        token = input().strip()
        if not token:
            break
        token_addresses.append(token)
    
    if not token_addresses:
        print("At least one token address is required!")
        return None
    
    return {
        "api_key": api_key,
        "kol_wallet": kol_wallet,
        "token_addresses": token_addresses
    }

def load_config():
    """Load configuration from file"""
    config_path = "config_free.json"
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return None

def save_results(results, filename="analysis_results_free.json"):
    """Save results to file"""
    with open(filename, 'w') as f:
        json.dump(results, f, indent=2)
    return filename

def print_summary(results):
    """Print analysis summary"""
    summary = results["analysis_summary"]
    
    print("\n" + "="*60)
    print("🔍 ANALYSIS SUMMARY")
    print("="*60)
    print(f"KOL Wallet: {summary['kol_wallet']}")
    print(f"API Used: {summary['api_used']}")
    print(f"Tokens Analyzed: {summary['tokens_analyzed']}")
    print(f"Tokens with KOL Purchases: {summary['tokens_with_kol_purchases']}")
    print(f"Total First Buyers Found: {summary['total_first_buyers']}")
    print(f"Suspicious Wallets Found: {summary['suspicious_wallets_found']}")
    print(f"Min Volume Filter: ${summary['min_volume_filter_usd']}")
    
    if results["suspicious_wallets"]:
        print("\n" + "="*60)
        print("🚨 TOP SUSPICIOUS WALLETS")
        print("="*60)
        
        for i, wallet in enumerate(results["suspicious_wallets"][:5], 1):
            print(f"\n{i}. 🔍 Wallet: {wallet['wallet_address']}")
            print(f"   📊 Suspicion Score: {wallet['suspicion_score']:.3f}")
            print(f"   🎯 Tokens Bought Early: {wallet['tokens_bought_early']}")
            print(f"   📈 Consistency Rate: {wallet['consistency_rate']:.1%}")
            print(f"   ⏰ Avg Time Advantage: {wallet['avg_time_advantage_hours']:.1f} hours")
            print(f"   💰 Total Early Volume: ${wallet['total_early_volume_usd']:.2f}")
            
            if wallet['token_details']:
                print("   📋 Token Details:")
                for detail in wallet['token_details'][:3]:  # Show first 3 tokens
                    token_short = detail['token_address'][:8] + "..."
                    hours = detail['time_advantage_hours']
                    volume = detail['volume_usd']
                    print(f"     • {token_short} ({hours:.1f}h advantage, ${volume:.2f})")
                if len(wallet['token_details']) > 3:
                    print(f"     • ... and {len(wallet['token_details']) - 3} more tokens")
    else:
        print("\n" + "="*60)
        print("❌ NO SUSPICIOUS WALLETS FOUND")
        print("="*60)
        print("Possible reasons:")
        print("• KOL might not have alt wallets for these tokens")
        print("• Tokens might be too new (not in first buyers data)")
        print("• Try lowering min_frequency to 1 in config")
        print("• Try different tokens that the KOL promoted")

def print_api_usage_info(token_count):
    """Print API usage information"""
    estimated_requests = token_count * 2  # 2 requests per token
    
    print(f"\n" + "="*60)
    print("📊 API USAGE INFORMATION")
    print("="*60)
    print(f"Estimated Requests Used: {estimated_requests}")
    print(f"Free Tier Limit: 10,000 requests/month")
    print(f"Remaining (approx): {10000 - estimated_requests:,} requests")
    print(f"Rate Limit: 1 request/second (automatically handled)")
    print()
    print("💡 Tips to optimize usage:")
    print("• Analyze 3-5 tokens at a time")
    print("• Focus on recently promoted tokens")
    print("• Use tokens with good trading volume")
    print()
    print("🚀 Need more requests? Upgrade at https://solanatracker.io")

def main():
    """Main interactive function"""
    try:
        # Get user input
        user_input = get_user_input()
        if not user_input:
            return
        
        # Load configuration
        config = load_config()
        if config:
            print(f"\n✅ Loaded configuration from config_free.json")
        else:
            print(f"\n⚙️ Using default configuration")
        
        # Initialize detector
        print(f"\n🔧 Initializing detector...")
        detector = KOLAltWalletDetectorFree(user_input["api_key"], config)
        
        # Print API usage info
        print_api_usage_info(len(user_input["token_addresses"]))
        
        # Run analysis
        print(f"\n🚀 Starting analysis...")
        print(f"⏳ This may take a few minutes due to rate limiting (1 req/sec)")
        print(f"📊 Analyzing {len(user_input['token_addresses'])} tokens...")
        print(f"🔍 Looking for early buyers and cross-token patterns...")
        
        results = detector.analyze_kol_wallet(
            user_input["kol_wallet"], 
            user_input["token_addresses"]
        )
        
        # Save results
        output_file = save_results(results)
        print(f"\n💾 Results saved to: {output_file}")
        
        # Print summary
        print_summary(results)
        
        # Additional guidance
        print(f"\n" + "="*60)
        print("🎯 NEXT STEPS")
        print("="*60)
        print(f"1. 📄 Review full results in {output_file}")
        print(f"2. 🔍 Investigate suspicious wallets on solscan.io")
        print(f"3. 🔗 Look for direct connections between wallets")
        print(f"4. 📊 Check transaction patterns and timing")
        print(f"5. ⚙️ Adjust config_free.json if needed")
        print()
        print("🆓 This analysis used the FREE Solana Tracker API")
        print("🔑 Get your API key at: https://solanatracker.io")
        
    except KeyboardInterrupt:
        print("\n❌ Analysis interrupted by user.")
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        print(f"\n❌ Error: {e}")
        print("Please check your inputs and try again.")
        print()
        print("Common issues:")
        print("• Invalid API key")
        print("• Invalid wallet/token addresses")
        print("• Network connectivity issues")
        print("• API rate limit exceeded")

if __name__ == "__main__":
    main()

