#!/usr/bin/env python3
"""
Debug what data is available for the 4 tokens to find graduation times
"""

import requests
import json
from datetime import datetime

def debug_token_data(token_address, token_name, api_key):
    """Debug what data is available for a token"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    print(f"\n🔍 DEBUGGING {token_name}:")
    print(f"   {token_address}")
    
    try:
        # Get token info
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            token_data = response.json()
            
            print(f"   ✅ Token data retrieved")
            
            # Show all available fields
            print(f"   📋 Available fields:")
            for key, value in token_data.items():
                if isinstance(value, (int, float, str, bool)) and value:
                    if 'time' in key.lower() or 'date' in key.lower() or 'created' in key.lower() or 'grad' in key.lower():
                        # Try to convert timestamp fields
                        if isinstance(value, (int, float)) and value > 1000000000:
                            try:
                                if value > 1e12:  # Milliseconds
                                    dt = datetime.fromtimestamp(value / 1000)
                                else:  # Seconds
                                    dt = datetime.fromtimestamp(value)
                                print(f"      {key}: {value} ({dt.strftime('%Y-%m-%d %H:%M:%S')})")
                            except:
                                print(f"      {key}: {value}")
                        else:
                            print(f"      {key}: {value}")
                    else:
                        # Show other important fields
                        if key in ['name', 'symbol', 'marketCap', 'holders', 'pools']:
                            if key == 'pools' and isinstance(value, list):
                                print(f"      {key}: {len(value)} pools found")
                            else:
                                print(f"      {key}: {value}")
            
            # Check pools for creation times
            pools = token_data.get('pools', [])
            if pools:
                print(f"   🏊 Pool analysis:")
                for i, pool in enumerate(pools, 1):
                    pool_id = pool.get('poolId', 'Unknown')
                    created_at = pool.get('createdAt') or pool.get('created_at')
                    if created_at:
                        try:
                            if created_at > 1e12:
                                dt = datetime.fromtimestamp(created_at / 1000)
                            else:
                                dt = datetime.fromtimestamp(created_at)
                            print(f"      Pool {i} ({pool_id[:8]}...): created {dt.strftime('%Y-%m-%d %H:%M:%S')}")
                        except:
                            print(f"      Pool {i} ({pool_id[:8]}...): created {created_at}")
                    else:
                        print(f"      Pool {i} ({pool_id[:8]}...): no creation time")
            
        else:
            print(f"   ❌ Error {response.status_code}: {response.text}")
            
    except Exception as e:
        print(f"   ❌ Exception: {e}")

def main():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    tokens = {
        "PFP": "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",
        "GIRLIES": "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
        "SYN": "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "PUMPHOUSE": "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump"
    }
    
    print(f"🔍 TOKEN DATA DEBUG")
    print("=" * 50)
    print("Checking what data is available for graduation time detection")
    print("=" * 50)
    
    for name, token in tokens.items():
        debug_token_data(token, name, api_key)

if __name__ == "__main__":
    main()
