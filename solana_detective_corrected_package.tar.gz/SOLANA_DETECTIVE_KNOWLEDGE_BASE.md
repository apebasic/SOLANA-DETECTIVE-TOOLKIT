# SOLANA DETECTIVE KNOWLEDGE BASE
*Comprehensive guide for blockchain investigation and analysis*

## 🎯 **MISSION STATEMENT**
Transform into a comprehensive Solana blockchain sleuth capable of detecting trading patterns, identifying suspicious wallets, analyzing token behaviors, and uncovering coordinated trading activities.

---

## 📋 **CORE OBJECTIVES**

### Primary Investigation Goals:
1. **KOL Alt Wallet Detection** - Identify hidden wallets used by Key Opinion Leaders
2. **Cross-Token Pattern Analysis** - Find wallets that systematically buy across multiple tokens
3. **Time-Window Analysis** - Analyze trading activity in specific timeframes
4. **Coordinated Trading Detection** - Spot synchronized trading behaviors
5. **Bot vs Human Classification** - Distinguish automated from manual trading
6. **Market Manipulation Detection** - Identify pump/dump schemes and insider trading

### Secondary Analysis Capabilities:
- Token graduation monitoring (pump.fun → Raydium)
- Volume and holder analysis
- Liquidity tracking
- Price movement correlation
- Network effect analysis

---

## 🛠️ **TECHNICAL ARCHITECTURE**

### API Infrastructure:
- **Primary**: Solana Tracker API (d69a0997-86cb-4a69-8f0b-c3435a11b45b)
- **Backup**: Free Solana RPC, Helius, Shyft
- **Rate Limits**: Respect API limits, implement pagination
- **Error Handling**: Robust retry mechanisms and fallback strategies

### ⚡ **BLOCK NUMBER CONVERSION PREREQUISITE**
**MANDATORY**: All time-based queries MUST use block number conversion for efficiency

#### Core Utilities:
- **`solana_time_utils.py`** - Core prerequisite utility
- **`SolanaTimeConverter`** - Timestamp ↔ block number conversion
- **`SolanaQueryOptimizer`** - Automatic query optimization
- **`convert_est_timeframe_to_optimized_query()`** - PREREQUISITE function

#### Conversion Workflow:
1. **Convert timeframe** → Solana slot range (PREREQUISITE)
2. **Optimize query** → Use block-aware parameters
3. **Execute efficiently** → Single API call vs pagination
4. **Process results** → Standard data processing

### Data Processing Pipeline:
1. **⚡ Time Conversion** → Convert timeframes to block numbers (PREREQUISITE)
2. **Data Collection** → Optimized API calls with block awareness
3. **Data Cleaning** → Filter bots, normalize timestamps
4. **Pattern Analysis** → Cross-reference wallets across tokens
5. **Scoring Algorithm** → Rank suspicious activities
6. **Results Formatting** → Mobile-friendly, copyable outputs

---

## 🔍 **INVESTIGATION METHODOLOGIES**

### KOL Alt Wallet Detection Algorithm:
```
For each token the KOL bought:
  1. Find KOL's first purchase timestamp
  2. Get all wallets that bought BEFORE that timestamp
  3. Record these "early buyer" wallets
  
Cross-reference early buyers across all tokens:
  - Wallets appearing in 2+ tokens = suspicious
  - Wallets appearing in 3+ tokens = highly suspicious
  - Factor in timing advantage and volume
```

### Bot Identification Criteria:
- **High Frequency**: >1000 daily transactions
- **Systematic Timing**: Consistent sub-second execution
- **Volume Patterns**: Similar trade sizes across tokens
- **Behavioral Consistency**: Automated-looking patterns

### Suspicion Scoring Formula:
```
Score = (Token_Count * 50) + (Volume_Weight * 25) + (Timing_Advantage * 25)
Where:
- Token_Count: Number of tokens wallet appears in
- Volume_Weight: Normalized investment volume
- Timing_Advantage: Average seconds before KOL
```

---

## 📊 **DATA REQUIREMENTS & FORMATS**

### Input Data Standards:
- **Wallet Addresses**: 44-character base58 Solana addresses
- **Token Addresses**: Contract addresses (usually ending in 'pump')
- **Timestamps**: Unix timestamps in seconds (UTC)
- **Volume Thresholds**: USD amounts for filtering significance

### Output Format Requirements:
- **Mobile-Friendly**: Contract addresses on separate lines
- **Copyable**: Easy selection without copying entire response
- **Structured**: Clear headers, metrics, and rankings
- **Actionable**: Specific wallet addresses for investigation

---

## 🚀 **OPERATIONAL RULES**

### ⚡ **BLOCK CONVERSION PREREQUISITE (MANDATORY):**
1. **All time-based queries** MUST use `convert_est_timeframe_to_optimized_query()`
2. **No pagination** for time-window analysis - use block-optimized single calls
3. **Import solana_time_utils** in all new detective tools
4. **Test block conversion** before implementing any time-based feature

### Response Formatting:
1. **Contract Addresses**: Always on separate lines for mobile copying
2. **Metrics Display**: Consistent format with bullet points
3. **Time References**: Always include timezone (EST/UTC)
4. **Volume Data**: Include both token amounts and USD values
5. **Ranking**: Always rank results by suspicion/relevance

### Tool Development Standards:
1. **Consolidation**: Don't create multiple versions, update existing files
2. **Documentation**: Update TOOLSET_REFERENCE.md for new tools
3. **Error Handling**: Robust API error management
4. **Efficiency**: Use block conversion and timestamp filtering over pagination
5. **Modularity**: Build reusable components

### Environment Management:
- **File Organization**: Keep environment tidy, remove duplicates
- **Version Control**: Single source of truth for each tool
- **Backup System**: Maintain tar.gz backups of complete toolset
- **Documentation**: Always update reference files

---

## 🔧 **TECHNICAL SPECIFICATIONS**

### Solana Tracker API Endpoints:
- `/first-buyers/{token}` - Get first 100 buyers of a token
- `/trades/{token}/{pool}` - Get all trades with timestamp filtering
- `/tokens/multi/graduated` - Get recently graduated tokens
- `/chart/{token}` - Get price/volume data with time filtering
- `/token/{address}` - Get token metadata and statistics

### Key Parameters:
- `time_from` & `time_to` - Unix timestamps for filtering
- `limit` - Results per page (max 250 for trades)
- `offset` - Pagination offset
- `sort` - Sorting criteria (usually by time)

### Data Structures:
```json
{
  "wallet": "address",
  "first_buy_time": unix_timestamp,
  "volume": dollar_amount,
  "holding": token_amount,
  "transactions": count
}
```

---

## 📈 **INVESTIGATION WORKFLOWS**

### Standard KOL Analysis:
1. Input: KOL wallet + token list
2. Get KOL's first buy timestamps
3. Fetch first buyers for each token
4. Filter buyers who bought before KOL
5. Cross-reference across tokens
6. Score and rank suspicious wallets
7. Present results with evidence

### Time-Window Investigation:
1. Input: Token + time range + volume threshold
2. Convert time to Unix timestamps
3. Use trades API with time filtering
4. Filter by volume threshold
5. Extract unique wallet addresses
6. Present formatted results

### Token Graduation Monitoring:
1. Fetch latest graduated tokens
2. Calculate graduation timing
3. Get holder counts and volumes
4. Check market cap and liquidity
5. Present top candidates

---

## 🎯 **SUCCESS METRICS**

### Investigation Quality:
- **Accuracy**: Correctly identify suspicious vs legitimate activity
- **Efficiency**: Minimize API calls while maximizing data quality
- **Actionability**: Provide specific wallets for further investigation
- **Evidence**: Support findings with concrete data

### Tool Performance:
- **Speed**: Complete analysis in <60 seconds
- **Reliability**: Handle API errors gracefully
- **Scalability**: Process multiple tokens efficiently
- **Usability**: Mobile-friendly outputs

---

## 🔮 **FUTURE ENHANCEMENTS**

### Planned Capabilities:
- **Real-time Monitoring**: Alert system for suspicious activities
- **Network Analysis**: Map wallet connections through funding sources
- **Profit Tracking**: Follow money across multiple transactions
- **Advanced Bot Detection**: ML-based classification
- **Market Manipulation Detection**: Sophisticated pattern recognition

### API Integrations:
- **Additional Data Sources**: Helius, Shyft, QuickNode integration
- **Cross-Chain Analysis**: Extend to other blockchains
- **Social Media Integration**: Correlate with Twitter/Discord activity
- **News Integration**: Factor in announcement timing

---

## 📚 **KNOWLEDGE BASE MAINTENANCE**

### Update Triggers:
- New investigation methodologies discovered
- API changes or new endpoints
- Tool improvements or consolidations
- New suspicious pattern types identified
- User feedback and requirements changes

### Version Control:
- Document all changes with timestamps
- Maintain backward compatibility
- Archive deprecated methodologies
- Update all related tools and documentation

---

*Last Updated: June 25, 2025*
*Version: 1.0*
*Status: Active Development*



## 📝 **ADDITIONAL TOKEN CONTRACTS (Updated)**

**神经蛙 (Neural Frog)**
- Contract: `4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk`
- Added: June 27, 2025
- Source: User provided during wallet investigation


