#!/usr/bin/env python3
"""
Wallet Transaction Analyzer
Analyzes specific wallets for buy/sell transaction counts across tokens
"""

import requests
import json
import time
from typing import Dict, List, Set, Tuple

class WalletTransactionAnalyzer:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {"x-api-key": api_key}
    
    def get_token_info(self, token_address: str) -> Dict:
        """Get token information including pools"""
        url = f"{self.base_url}/tokens/{token_address}"
        response = requests.get(url, headers=self.headers)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def get_trades_page(self, token_address: str, pool_address: str, page: int = 1) -> Dict:
        """Get trades for a specific page"""
        url = f"{self.base_url}/trades/{token_address}/{pool_address}"
        params = {"page": page}
        
        response = requests.get(url, headers=self.headers, params=params)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def get_top_liquidity_pool(self, token_address: str) -> Tuple[str, float]:
        """Get the pool with highest liquidity for a token"""
        token_info = self.get_token_info(token_address)
        if not token_info:
            return "", 0
        
        pools = token_info.get('pools', [])
        if not pools:
            return "", 0
        
        # Sort pools by liquidity (USD) and take top one
        pools_with_liquidity = []
        for pool in pools:
            liquidity_usd = pool.get('liquidity', {}).get('usd', 0)
            pools_with_liquidity.append((pool, liquidity_usd))
        
        pools_with_liquidity.sort(key=lambda x: x[1], reverse=True)
        top_pool = pools_with_liquidity[0][0]
        top_liquidity = pools_with_liquidity[0][1]
        
        return top_pool.get('poolId', ''), top_liquidity
    
    def analyze_wallet_transactions(self, wallet_address: str, token_address: str, 
                                  token_name: str, max_pages: int = 50) -> Dict:
        """
        Analyze a specific wallet's transactions for a token
        Returns buy/sell counts and transaction details
        """
        print(f"🔍 Analyzing wallet {wallet_address[:8]}... for {token_name}")
        
        # Get top liquidity pool
        pool_address, liquidity = self.get_top_liquidity_pool(token_address)
        if not pool_address:
            print(f"❌ No pools found for {token_name}")
            return {}
        
        print(f"  📊 Using top pool: ${liquidity:,.2f} liquidity")
        
        # Track transactions for this wallet
        buy_count = 0
        sell_count = 0
        buy_transactions = []
        sell_transactions = []
        
        # Search through pages to find this wallet's transactions
        for page in range(1, max_pages + 1):
            trades_data = self.get_trades_page(token_address, pool_address, page)
            
            if not trades_data or 'trades' not in trades_data:
                break
            
            trades = trades_data['trades']
            if not trades:
                break
            
            # Look for this wallet's transactions
            found_wallet_in_page = False
            for trade in trades:
                if trade.get('wallet') == wallet_address:
                    found_wallet_in_page = True
                    trade_type = trade.get('type', '')
                    
                    if trade_type == 'buy':
                        buy_count += 1
                        buy_transactions.append({
                            'amount': trade.get('amount', 0),
                            'priceUsd': trade.get('priceUsd', 0),
                            'volume': trade.get('volume', 0),
                            'time': trade.get('time', 0)
                        })
                    elif trade_type == 'sell':
                        sell_count += 1
                        sell_transactions.append({
                            'amount': trade.get('amount', 0),
                            'priceUsd': trade.get('priceUsd', 0),
                            'volume': trade.get('volume', 0),
                            'time': trade.get('time', 0)
                        })
            
            # Rate limiting
            time.sleep(1.1)
            
            # If we haven't found the wallet in recent pages, it might not be in later pages
            if page > 10 and not found_wallet_in_page:
                break
        
        result = {
            'wallet': wallet_address,
            'token': token_name,
            'buy_count': buy_count,
            'sell_count': sell_count,
            'total_transactions': buy_count + sell_count,
            'has_both_buy_and_sell': buy_count > 0 and sell_count > 0,
            'buy_transactions': buy_transactions,
            'sell_transactions': sell_transactions
        }
        
        print(f"  ✅ Found {buy_count} buys, {sell_count} sells")
        return result
    
    def analyze_multiple_wallets(self, wallet_addresses: List[str], 
                               token_configs: List[Dict]) -> Dict:
        """
        Analyze multiple wallets across multiple tokens
        token_configs: [{'address': 'token_addr', 'name': 'token_name'}, ...]
        """
        results = {}
        
        print(f"🚀 Analyzing {len(wallet_addresses)} wallets across {len(token_configs)} tokens")
        print("=" * 70)
        
        for wallet in wallet_addresses:
            print(f"\n📋 Wallet: {wallet}")
            results[wallet] = {}
            
            for token_config in token_configs:
                token_address = token_config['address']
                token_name = token_config['name']
                
                analysis = self.analyze_wallet_transactions(
                    wallet, token_address, token_name
                )
                
                if analysis:
                    results[wallet][token_name] = analysis
        
        return results
    
    def generate_summary_report(self, analysis_results: Dict) -> str:
        """Generate a summary report of the analysis"""
        report = "\n" + "=" * 70 + "\n"
        report += "📊 WALLET TRANSACTION ANALYSIS SUMMARY\n"
        report += "=" * 70 + "\n"
        
        # Find wallets that have both buy and sell for all tokens
        candidates = []
        
        for wallet, tokens in analysis_results.items():
            report += f"\n🔍 Wallet: {wallet}\n"
            
            has_both_for_all = True
            token_summary = []
            
            for token_name, data in tokens.items():
                buy_count = data.get('buy_count', 0)
                sell_count = data.get('sell_count', 0)
                has_both = data.get('has_both_buy_and_sell', False)
                
                status = "✅" if has_both else "❌"
                token_summary.append(f"  {status} {token_name}: {buy_count} buys, {sell_count} sells")
                
                if not has_both:
                    has_both_for_all = False
            
            for line in token_summary:
                report += line + "\n"
            
            if has_both_for_all and len(tokens) > 1:
                candidates.append(wallet)
                report += "  🎯 CANDIDATE: Has both buy and sell for all tokens!\n"
        
        report += "\n" + "=" * 70 + "\n"
        report += "🎯 FINAL CANDIDATES (have both buy and sell for all tokens):\n"
        
        if candidates:
            for i, candidate in enumerate(candidates, 1):
                report += f"  {i}. {candidate}\n"
        else:
            report += "  ❌ No wallets found with both buy and sell for all tokens\n"
        
        return report

def main():
    # Load API key
    try:
        with open('/home/ubuntu/config.json', 'r') as f:
            config = json.load(f)
            api_key = config.get('api_key', '')
    except:
        print("❌ Could not load API key from config.json")
        return
    
    if not api_key:
        print("❌ No API key found in config")
        return
    
    # The 5 wallets that bought both PFP and GIRLIES
    target_wallets = [
        "9mXRorN5knxtJuyMiHPWt9ZazZC2vtBaXPfhvmNSxzvP",
        "HuTshmtwcQkWBLzgW3m4uwcmik7Lmz4YFpYcTqMJpXiP",
        "47ftMbRNQqZLjyHdFSR3kpSiPBU4QRkRF7EWjWaDJ8ch",
        "8TPWakvWw4xQbk7uAYdNjZiDKKHgv9GE5GebzsbtUaHr",
        "Bu4vvv2Mj6Zadtin3Kp4L15XqXeRYUSSPF1YsVBARSaS"
    ]
    
    # Token configurations
    tokens = [
        {
            'address': '4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump',
            'name': 'PFP'
        },
        {
            'address': 'DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump',
            'name': 'GIRLIES'
        }
    ]
    
    analyzer = WalletTransactionAnalyzer(api_key)
    
    # Analyze the wallets
    results = analyzer.analyze_multiple_wallets(target_wallets, tokens)
    
    # Generate and display report
    report = analyzer.generate_summary_report(results)
    print(report)
    
    # Save report to file
    with open('/home/ubuntu/wallet_analysis_report.txt', 'w') as f:
        f.write(report)
    
    print("\n📄 Report saved to wallet_analysis_report.txt")

if __name__ == "__main__":
    main()

