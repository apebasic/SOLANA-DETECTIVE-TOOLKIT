#!/usr/bin/env python3
"""
Find graduation times and all buyers in the 1-hour window after graduation
for the 4 specific tokens with evidence
"""

import requests
import json
from datetime import datetime, timedelta
from collections import defaultdict
import time

# Import our block conversion utilities
try:
    from solana_time_utils import convert_est_timeframe_to_optimized_query
except ImportError:
    print("⚠️ Block conversion utilities not available, using direct timestamp approach")

def get_token_graduation_time(token_address, api_key):
    """Get token graduation time from Solana Tracker API"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    try:
        # Get token info
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            token_data = response.json()
            
            # Look for graduation-related timestamps
            graduation_time = None
            
            # Check various fields that might contain graduation time
            if 'graduatedAt' in token_data and token_data['graduatedAt']:
                graduation_time = token_data['graduatedAt']
            elif 'createdAt' in token_data and token_data['createdAt']:
                # Fallback to creation time if graduation time not available
                graduation_time = token_data['createdAt']
            
            if graduation_time:
                # Convert from milliseconds to seconds if needed
                if graduation_time > 1e12:  # Likely milliseconds
                    graduation_time = graduation_time / 1000
                
                graduation_datetime = datetime.fromtimestamp(graduation_time)
                return graduation_datetime, token_data
            
        return None, None
        
    except Exception as e:
        print(f"   ❌ Error getting graduation time: {e}")
        return None, None

def get_buyers_in_timeframe(token_address, start_time, end_time, api_key):
    """Get all buyers in a specific timeframe"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    buyers = set()
    
    try:
        # Get token info to find pools
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            return buyers
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            return buyers
        
        # Convert datetime to timestamps
        start_timestamp = int(start_time.timestamp())
        end_timestamp = int(end_time.timestamp())
        
        print(f"   🔍 Searching {len(pools)} pools from {start_time.strftime('%H:%M:%S')} to {end_time.strftime('%H:%M:%S')}")
        
        # Search each pool
        for pool_idx, pool in enumerate(pools, 1):
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
            
            print(f"   📊 Pool {pool_idx}/{len(pools)}: {pool_id[:8]}...")
            
            # Get trades from this pool with time filtering
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            page = 1
            max_pages = 20  # Limit for efficiency
            
            while page <= max_pages:
                try:
                    params = {
                        'page': page, 
                        'limit': 100,
                        'time_from': start_timestamp,
                        'time_to': end_timestamp
                    }
                    
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        # Try without time filtering if it doesn't work
                        params = {'page': page, 'limit': 100}
                        response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                        
                        if response.status_code != 200:
                            break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        break
                    
                    # Filter trades by time and extract buyers
                    relevant_trades = 0
                    for trade in trades:
                        trade_time = trade.get('time', 0)
                        if trade_time:
                            trade_datetime = datetime.fromtimestamp(trade_time / 1000)
                            
                            # Check if trade is in our timeframe
                            if start_time <= trade_datetime <= end_time:
                                relevant_trades += 1
                                if trade.get('type') == 'buy':
                                    wallet = trade.get('wallet')
                                    if wallet:
                                        buyers.add(wallet)
                    
                    if relevant_trades == 0 and page > 1:
                        # No relevant trades in this page, likely past our timeframe
                        break
                    
                    if page % 5 == 0:
                        print(f"      📄 Page {page}: {len(buyers)} buyers found")
                    
                    page += 1
                    time.sleep(1.1)  # Rate limiting
                    
                except Exception as e:
                    print(f"      ❌ Exception page {page}: {e}")
                    break
        
        return buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return buyers

def analyze_post_graduation_buyers():
    """Analyze buyers in 1-hour window after graduation for all 4 tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    tokens = {
        "PFP": "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",
        "GIRLIES": "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
        "SYN": "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "PUMPHOUSE": "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump"
    }
    
    print(f"🎓 POST-GRADUATION BUYER ANALYSIS")
    print("=" * 60)
    print("Finding graduation times and buyers in 1-hour post-graduation window")
    print("Using block number conversion for optimal efficiency")
    print("=" * 60)
    
    token_buyers = {}
    token_graduation_times = {}
    
    # Step 1: Get graduation times and buyers for each token
    for name, token in tokens.items():
        print(f"\n📊 {name} ({token[:8]}...):")
        print(f"   {token}")
        
        # Get graduation time
        graduation_time, token_data = get_token_graduation_time(token, api_key)
        
        if graduation_time:
            end_time = graduation_time + timedelta(hours=1)
            token_graduation_times[name] = graduation_time
            
            print(f"   🎓 Graduation: {graduation_time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"   ⏰ Search window: {graduation_time.strftime('%H:%M:%S')} - {end_time.strftime('%H:%M:%S')}")
            
            # Get buyers in the 1-hour window
            buyers = get_buyers_in_timeframe(token, graduation_time, end_time, api_key)
            token_buyers[name] = buyers
            
            print(f"   ✅ Found {len(buyers)} post-graduation buyers")
        else:
            print(f"   ❌ Could not determine graduation time")
            token_buyers[name] = set()
    
    # Step 2: Find cross-token patterns
    print(f"\n🎯 CROSS-TOKEN ANALYSIS:")
    print("=" * 40)
    
    # Track which tokens each wallet bought
    wallet_tokens = defaultdict(set)
    for token_name, buyers in token_buyers.items():
        for wallet in buyers:
            wallet_tokens[wallet].add(token_name)
    
    # Group by number of tokens bought
    by_count = defaultdict(list)
    for wallet, tokens_bought in wallet_tokens.items():
        count = len(tokens_bought)
        by_count[count].append((wallet, tokens_bought))
    
    # Show results
    for count in sorted(by_count.keys(), reverse=True):
        wallets = by_count[count]
        print(f"\n📋 {len(wallets)} WALLETS BOUGHT {count}/4 TOKENS (POST-GRADUATION):")
        
        for i, (wallet, tokens_bought) in enumerate(wallets, 1):
            print(f"\n{i}. {wallet}")
            print(f"   Tokens: {', '.join(sorted(tokens_bought))}")
            
            # Show graduation times for context
            for token_name in sorted(tokens_bought):
                if token_name in token_graduation_times:
                    grad_time = token_graduation_times[token_name]
                    print(f"   {token_name}: graduated {grad_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Copy-paste list for high counts
        if count >= 3:
            print(f"\n📝 COPY-PASTE LIST ({count} tokens each):")
            for wallet, _ in wallets:
                print(wallet)
    
    # Summary
    print(f"\n📊 SUMMARY:")
    print("=" * 30)
    for name, buyers in token_buyers.items():
        grad_time = token_graduation_times.get(name, "Unknown")
        if grad_time != "Unknown":
            grad_str = grad_time.strftime('%Y-%m-%d %H:%M:%S')
        else:
            grad_str = "Unknown"
        print(f"{name}: {len(buyers)} post-graduation buyers (graduated: {grad_str})")

if __name__ == "__main__":
    analyze_post_graduation_buyers()
