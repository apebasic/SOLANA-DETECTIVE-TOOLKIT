#!/usr/bin/env python3
"""
Cross-Token Overlap Analysis - Updated with Block Conversion Prerequisite
Find wallets that appear as first buyers across multiple tokens
UPDATED: All time-based analysis now uses block number conversion for efficiency
"""

import requests
import json
from datetime import datetime
from collections import defaultdict, Counter
import time
from solana_time_utils import SolanaTimeConverter, SolanaQueryOptimizer

class CrossTokenAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key
        self.headers = {'x-api-key': api_key, 'accept': 'application/json'}
        self.base_url = 'https://data.solanatracker.io'
        
        # PREREQUISITE: Initialize block conversion utilities
        self.time_converter = SolanaTimeConverter()
        self.query_optimizer = SolanaQueryOptimizer(api_key)
        
    def get_first_buyers(self, token_address):
        """Get first buyers for a token"""
        url = f'{self.base_url}/first-buyers/{token_address}'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Error getting first buyers for {token_address}: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting first buyers: {e}")
            return []
    
    def analyze_cross_token_overlaps(self, tokens):
        """Find wallets that appear across multiple tokens"""
        print(f"🔍 CROSS-TOKEN OVERLAP ANALYSIS")
        print(f"🎯 Analyzing {len(tokens)} tokens for overlapping wallets")
        print("=" * 80)
        
        # Store all wallet data
        all_wallet_data = defaultdict(list)  # wallet -> list of token appearances
        token_buyers = {}  # token -> list of buyers
        
        # Analyze each token
        for i, token_info in enumerate(tokens, 1):
            if isinstance(token_info, dict):
                token_address = token_info['address']
                token_name = token_info.get('name', f'Token {i}')
            else:
                token_address = token_info
                token_name = f'Token {i}'
            
            print(f"\n📊 Analyzing {token_name}")
            print(f"   Address: {token_address}")
            
            # Get first buyers
            first_buyers = self.get_first_buyers(token_address)
            
            if not first_buyers:
                print(f"   ❌ No first buyers found")
                continue
            
            print(f"   ✅ Found {len(first_buyers)} first buyers")
            token_buyers[token_address] = first_buyers
            
            # Store wallet appearances
            for buyer in first_buyers:
                wallet = buyer.get('wallet')
                if wallet:
                    all_wallet_data[wallet].append({
                        'token_name': token_name,
                        'token_address': token_address,
                        'first_buy_time': buyer.get('first_buy_time'),
                        'first_buy_date': datetime.fromtimestamp(buyer.get('first_buy_time', 0) / 1000),
                        'total_invested': buyer.get('total_invested', 0),
                        'volume_usd': buyer.get('first_buy', {}).get('volume_usd', 0),
                        'holding': buyer.get('holding', 0),
                        'buy_transactions': buyer.get('buy_transactions', 0)
                    })
            
            time.sleep(0.5)  # Be nice to API
        
        # Find overlapping wallets
        print(f"\n🔍 Finding cross-token patterns...")
        
        # Count wallet appearances
        wallet_counts = Counter()
        for wallet, appearances in all_wallet_data.items():
            wallet_counts[wallet] = len(appearances)
        
        # Filter wallets that appear in multiple tokens
        overlapping_wallets = {wallet: appearances for wallet, appearances in all_wallet_data.items() 
                             if len(appearances) >= 2}
        
        print(f"✅ Found {len(overlapping_wallets)} wallets appearing in multiple tokens")
        
        # Generate detailed report
        self.generate_overlap_report(overlapping_wallets, wallet_counts, len(tokens))
        
        return overlapping_wallets, token_buyers
    
    def generate_overlap_report(self, overlapping_wallets, wallet_counts, total_tokens):
        """Generate detailed overlap report"""
        print(f"\n" + "="*80)
        print(f"📊 CROSS-TOKEN OVERLAP RESULTS")
        print(f"="*80)
        
        if not overlapping_wallets:
            print(f"❌ No wallets found appearing in multiple tokens")
            return
        
        # Sort by number of token appearances
        sorted_wallets = sorted(overlapping_wallets.items(), 
                              key=lambda x: len(x[1]), reverse=True)
        
        print(f"\n🎯 WALLETS BY OVERLAP FREQUENCY:")
        print(f"="*60)
        
        # Group by frequency
        frequency_groups = defaultdict(list)
        for wallet, appearances in sorted_wallets:
            frequency_groups[len(appearances)].append((wallet, appearances))
        
        # Show results by frequency (highest first)
        for frequency in sorted(frequency_groups.keys(), reverse=True):
            wallets_in_group = frequency_groups[frequency]
            percentage = (frequency / total_tokens) * 100
            
            print(f"\n🔥 {frequency}/{total_tokens} TOKENS ({percentage:.1f}% overlap)")
            print(f"   Found {len(wallets_in_group)} wallets")
            print(f"   " + "-" * 50)
            
            for i, (wallet, appearances) in enumerate(wallets_in_group, 1):
                total_investment = sum(a['total_invested'] for a in appearances)
                total_volume = sum(a['volume_usd'] for a in appearances)
                avg_investment = total_investment / len(appearances) if appearances else 0
                
                print(f"\n   #{i} WALLET: {wallet}")
                print(f"      📊 Tokens: {len(appearances)}")
                print(f"      💰 Total Investment: ${total_investment:.2f}")
                print(f"      📈 Total Volume: ${total_volume:.2f}")
                print(f"      💵 Avg Investment: ${avg_investment:.2f}")
                
                # Show token details
                print(f"      🎪 Token Appearances:")
                for appearance in sorted(appearances, key=lambda x: x['first_buy_time']):
                    date = appearance['first_buy_date'].strftime('%m-%d %H:%M:%S')
                    investment = appearance['total_invested']
                    volume = appearance['volume_usd']
                    print(f"         • {appearance['token_name']}: {date} - ${investment:.2f} (Vol: ${volume:.2f})")
        
        # Summary statistics
        print(f"\n📈 SUMMARY STATISTICS:")
        print(f"="*40)
        print(f"Total unique wallets analyzed: {len(wallet_counts)}")
        print(f"Wallets in multiple tokens: {len(overlapping_wallets)}")
        print(f"Overlap rate: {len(overlapping_wallets)/len(wallet_counts)*100:.1f}%")
        
        # Top investors across tokens
        print(f"\n💰 TOP CROSS-TOKEN INVESTORS:")
        print(f"="*40)
        
        investor_totals = []
        for wallet, appearances in overlapping_wallets.items():
            total_investment = sum(a['total_invested'] for a in appearances)
            investor_totals.append((wallet, total_investment, len(appearances)))
        
        investor_totals.sort(key=lambda x: x[1], reverse=True)
        
        for i, (wallet, total_investment, token_count) in enumerate(investor_totals[:10], 1):
            print(f"#{i} {wallet}")
            print(f"    💰 ${total_investment:.2f} across {token_count} tokens")
        
        # Time pattern analysis
        print(f"\n⏰ TIME PATTERN ANALYSIS:")
        print(f"="*40)
        
        # Find wallets with consistent timing patterns
        consistent_wallets = []
        for wallet, appearances in overlapping_wallets.items():
            if len(appearances) >= 3:  # At least 3 tokens
                times = [a['first_buy_time'] for a in appearances]
                time_range = (max(times) - min(times)) / (1000 * 60 * 60)  # Hours
                consistent_wallets.append((wallet, len(appearances), time_range))
        
        consistent_wallets.sort(key=lambda x: x[2])  # Sort by time range (most consistent first)
        
        print(f"Most consistent timing patterns (3+ tokens):")
        for i, (wallet, token_count, time_range) in enumerate(consistent_wallets[:5], 1):
            print(f"#{i} {wallet}")
            print(f"    📊 {token_count} tokens over {time_range:.1f} hours")

def main():
    # Configuration
    API_KEY = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # Tokens to analyze
    TOKENS = [
        {"address": "8gHPxqgHj6JQ2sQtMSghQYVN5qRP8wm5T6HNejuwpump", "name": "Token-1"},
        {"address": "8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e", "name": "Token-2"},
        {"address": "3oQwNvAfZMuPWjVPC12ukY7RPA9JiGwLod6Pr4Lkpump", "name": "Token-3"},
        {"address": "tdzUKGeAchLRzpYBzmBWEGaoP7E8EQ8hPv8Eqi8pump", "name": "Token-4"},
        {"address": "9RjwNo6hBPkxayWHCqQD1VjaH8igSizEseNZNbddpump", "name": "Token-5"},
        {"address": "5c74v6Px9RKwdGWCfqLGfEk7UZfE3Y4qJbuYrLbVG63V", "name": "Token-6"},
        {"address": "79VE8a7seB6wdZaHMvhTCJUYQsWvDJPGhpZpjKsoNe9x", "name": "Token-7"}
    ]
    
    # Run analysis
    analyzer = CrossTokenAnalyzer(API_KEY)
    overlapping_wallets, token_buyers = analyzer.analyze_cross_token_overlaps(TOKENS)
    
    print(f"\n✅ Cross-token overlap analysis complete!")

if __name__ == "__main__":
    main()

