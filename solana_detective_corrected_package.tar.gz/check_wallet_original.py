#!/usr/bin/env python3

import requests
import json
from datetime import datetime

api_key = 'd69a0997-86cb-4a69-8f0b-c3435a11b45b'
headers = {'x-api-key': api_key, 'accept': 'application/json'}

# The top suspicious wallet from the new analysis
suspicious_wallet = '56S29mZ3wqvw8hATuUUFqKhGcSGYFASRRFNT38W8q7G3'

# Original 4 tokens
original_tokens = [
    '3oQwNvAfZMuPWjVPC12ukY7RPA9JiGwLod6Pr4Lkpump',
    'B7N8qDpQcYTa2fHypYdMif3WGxWdahDCYiXZGj6moon', 
    '7ADAuXkjjDhF2P5H4RJWRk7mndtGTcR62Vfi8V6wpump',
    'neA4KGDoctCQ5pUmgQMZszTtXkMmc3mqhp8QCy6moon'
]

print(f'🔍 Checking if wallet {suspicious_wallet} appears in original tokens...')

found_in_original = []

for i, token in enumerate(original_tokens, 1):
    print(f'\n📊 Checking Token {i}: {token}')
    
    try:
        url = f'https://data.solanatracker.io/first-buyers/{token}'
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            first_buyers = response.json()
            
            # Check if our suspicious wallet is in the first buyers
            wallet_found = False
            for buyer in first_buyers:
                if buyer.get('wallet') == suspicious_wallet:
                    wallet_found = True
                    print(f'  ✅ FOUND! Wallet appears in first buyers')
                    print(f'     First buy time: {buyer.get("first_buy_time")}')
                    print(f'     Investment: ${buyer.get("total_invested", 0):.4f}')
                    found_in_original.append({
                        'token': f'Token {i}',
                        'token_address': token,
                        'first_buy_time': buyer.get('first_buy_time'),
                        'investment': buyer.get('total_invested', 0)
                    })
                    break
            
            if not wallet_found:
                print(f'  ❌ Not found in first buyers')
        else:
            print(f'  ❌ Error getting first buyers: {response.status_code}')
            
    except Exception as e:
        print(f'  ❌ Exception: {e}')

print(f'\n🎯 SUMMARY:')
if found_in_original:
    print(f'✅ Wallet {suspicious_wallet} appears in {len(found_in_original)} of the original 4 tokens:')
    for finding in found_in_original:
        date = datetime.fromtimestamp(finding['first_buy_time'] / 1000)
        print(f'  - {finding["token"]}: {date}, ${finding["investment"]:.4f}')
    
    total_tokens = len(found_in_original) + 5  # 5 from new analysis
    print(f'\n🚨 TOTAL PATTERN: This wallet bought {total_tokens} out of {len(original_tokens) + 6} total tokens!')
else:
    print(f'❌ Wallet {suspicious_wallet} did NOT appear in any of the original 4 tokens')
    print(f'   This means it only appears in the new 6 tokens (5 of them)')

