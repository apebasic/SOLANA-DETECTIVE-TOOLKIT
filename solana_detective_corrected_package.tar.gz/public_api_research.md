# Solscan Public API Research

## Base URL
`https://public-api.solscan.io/`

## Rate Limits
- Default Limit: 150 requests/30 seconds
- 100k requests/day
- No API key required

## Available Endpoints

### Account Endpoints
- ✅ `/account/tokens` - Get tokens for an account
- ✅ `/account/transactions` - Get transactions for an account  
- ✅ `/account/stakeAccounts` - Get stake accounts
- ✅ `/account/splTransfers` - Get SPL token transfers
- ✅ `/account/solTransfers` - Get SOL transfers
- ⛔ `/account/exportTransactions` - Export transactions (not available)
- ✅ `/account/{account}` - Get account details

### Token Endpoints
- ✅ `/token/holders` - Get token holders
- ✅ `/token/meta` - Get token metadata
- ⛔ `/token/list` - Token list (not available)

### Transaction Endpoints
- ✅ `/transaction/last` - Get last transactions
- ✅ `/transaction/{signature}` - Get specific transaction

### Block Endpoints
- ✅ `/block/last` - Get last blocks
- ✅ `/block/transaction` - Get block transactions
- ✅ `/block/{block}` - Get specific block

### Market Endpoints
- ✅ `/market/token/{tokenAddress}` - Get token market data

## Key Findings for KOL Analysis
1. **Account SPL Transfers**: `/account/splTransfers` - This can get token transfers for a wallet
2. **Account Transactions**: `/account/transactions` - General transaction data
3. **Token Holders**: `/token/holders` - Can see who holds a token
4. **No API Key Required**: Free to use with rate limits

## Limitations vs Pro API
- No advanced filtering by time ranges
- No pagination control
- Limited to basic endpoints
- No bulk operations
- Rate limited to 150 requests/30 seconds



## Solana Tracker API - Perfect Solution!

### Base URL
`https://data.solanatracker.io`

### Authentication
- Requires API key in `x-api-key` header
- **FREE TIER**: 10,000 requests/month, 1 request/second
- No credit card required for free tier

### Key Endpoints for KOL Analysis

#### 1. `/first-buyers/{token}` - PERFECT FOR OUR USE CASE!
- Gets first 100 buyers of a token since API started recording
- Returns detailed data:
  - `wallet`: wallet address
  - `first_buy_time`: Unix timestamp of first purchase
  - `first_buy`: detailed transaction info (signature, amount, volume_usd, time)
  - PnL data and transaction counts

#### 2. `/wallet/{owner}/trades` - Get Wallet Trades
- Get all trades for a specific wallet
- Useful for analyzing KOL's trading patterns

#### 3. `/trades/{tokenAddress}/by-wallet/{owner}` - Get User-Specific Token Trades
- Get specific wallet's trades for a specific token
- Perfect for finding KOL's first purchase of a token

### Advantages over Solscan Pro API
1. **FREE TIER**: 10,000 requests/month vs paid Pro API
2. **FIRST BUYERS ENDPOINT**: Direct access to early buyers data
3. **COMPREHENSIVE DATA**: Includes PnL, timestamps, amounts
4. **EASY SIGNUP**: No credit card required for free tier

### Modified Algorithm Strategy
1. **Get KOL's trades** for each token using `/trades/{tokenAddress}/by-wallet/{kol_wallet}`
2. **Find KOL's first purchase** timestamp for each token
3. **Get first buyers** for each token using `/first-buyers/{token}`
4. **Filter early buyers** who bought before KOL's first purchase
5. **Cross-reference** early buyers across multiple tokens
6. **Score and rank** suspicious wallets

This API is much better suited for our use case than Solscan Pro API!

