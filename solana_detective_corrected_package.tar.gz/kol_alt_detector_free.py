#!/usr/bin/env python3
"""
KOL Alt Wallet Detection Tool - FREE VERSION - Updated with Block Conversion Prerequisite

This tool identifies potential "alt wallets" or "backdoor wallets" of KOLs (Key Opinion Leaders) 
on Solana by analyzing transaction timing patterns across multiple tokens.

Uses Solana Tracker API (FREE TIER: 10,000 requests/month)
UPDATED: All time-based queries now use block number conversion for efficiency

Usage:
    python kol_alt_detector_free.py --kol-wallet <wallet_address> --tokens <token1,token2,token3> --api-key <solana_tracker_api_key>
"""

import requests
import pandas as pd
import json
import time
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import logging
from dataclasses import dataclass
from collections import defaultdict
from solana_time_utils import SolanaTimeConverter, SolanaQueryOptimizer

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class TokenPurchase:
    """Data class for token purchase information"""
    token_address: str
    wallet_address: str
    timestamp: int
    amount: float
    transaction_id: str
    volume_usd: float

@dataclass
class SuspiciousWallet:
    """Data class for suspicious wallet analysis results"""
    wallet_address: str
    suspicion_score: float
    tokens_bought_early: int
    consistency_rate: float
    avg_time_advantage_hours: float
    total_early_volume_usd: float
    token_details: List[Dict]

class SolanaTrackerAPI:
    """Wrapper for Solana Tracker API (Free Tier) - Updated with Block Conversion Prerequisite"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {
            "x-api-key": api_key,
            "accept": "application/json"
        }
        self.rate_limit_delay = 1.1  # Free tier: 1 request/second, so 1.1s delay
        
        # PREREQUISITE: Initialize block conversion utilities
        self.time_converter = SolanaTimeConverter()
        self.query_optimizer = SolanaQueryOptimizer(api_key)
    
    def _make_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make API request with rate limiting and error handling"""
        url = f"{self.base_url}/{endpoint}"
        
        try:
            time.sleep(self.rate_limit_delay)
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response content: {e.response.text}")
            raise
    
    def get_first_buyers(self, token_address: str) -> List[Dict]:
        """Get first 100 buyers of a token"""
        logger.info(f"Fetching first buyers for token: {token_address}")
        
        try:
            response = self._make_request(f"first-buyers/{token_address}")
            return response if isinstance(response, list) else []
        except Exception as e:
            logger.error(f"Failed to get first buyers for {token_address}: {e}")
            return []
    
    def get_wallet_token_trades_optimized(self, token_address: str, wallet_address: str, 
                                        start_timestamp: Optional[int] = None, 
                                        end_timestamp: Optional[int] = None) -> List[Dict]:
        """
        UPDATED: Get wallet trades with optional time filtering using block conversion
        If timestamps provided, automatically converts to block numbers for efficiency
        """
        logger.info(f"Fetching trades for wallet {wallet_address} and token {token_address}")
        
        if start_timestamp and end_timestamp:
            # PREREQUISITE: Use block conversion for time-based queries
            logger.info(f"Converting time range to block numbers for efficient querying...")
            optimization = self.query_optimizer.optimize_time_query(start_timestamp, end_timestamp)
            
            if optimization:
                logger.info(f"Time range optimized: {optimization['start_slot']} → {optimization['end_slot']} slots")
        
        try:
            # Use optimized endpoint with time filtering if available
            endpoint = f"trades/{token_address}/by-wallet/{wallet_address}"
            params = {}
            
            if start_timestamp and end_timestamp:
                params.update({
                    'time_from': start_timestamp,
                    'time_to': end_timestamp
                })
            
            response = self._make_request(endpoint, params)
            return response if isinstance(response, list) else []
        except Exception as e:
            logger.error(f"Failed to get trades for wallet {wallet_address} and token {token_address}: {e}")
            return []
    
    def get_wallet_token_trades(self, token_address: str, wallet_address: str) -> List[Dict]:
        """Legacy method - redirects to optimized version"""
        return self.get_wallet_token_trades_optimized(token_address, wallet_address)

class KOLAltWalletDetectorFree:
    """Main class for detecting KOL alt wallets using free API"""
    
    def __init__(self, api_key: str, config: Dict = None):
        self.api = SolanaTrackerAPI(api_key)
        self.config = config or self._default_config()
        self.kol_purchases = {}
        self.early_buyers_data = {}
        
    def _default_config(self) -> Dict:
        """Default configuration parameters"""
        return {
            "min_frequency": 2,
            "min_consistency": 0.3,
            "frequency_weight": 0.5,
            "timing_weight": 0.3,
            "volume_weight": 0.2,
            "min_volume_usd": 10,  # Minimum $10 purchase to be considered
        }
    
    def analyze_kol_wallet(self, kol_wallet: str, token_addresses: List[str]) -> Dict:
        """Main analysis function"""
        logger.info(f"Starting FREE analysis for KOL wallet: {kol_wallet}")
        logger.info(f"Analyzing {len(token_addresses)} tokens")
        logger.info(f"Using Solana Tracker API (Free Tier: 10k requests/month)")
        
        # Phase 1: Get KOL's first purchase for each token
        self._collect_kol_first_purchases(kol_wallet, token_addresses)
        
        # Phase 2: Get first buyers for each token
        self._collect_first_buyers_data(token_addresses)
        
        # Phase 3: Identify early buyers (bought before KOL)
        early_buyers = self._identify_early_buyers()
        
        # Phase 4: Cross-token analysis
        suspicious_wallets = self._cross_token_analysis(early_buyers)
        
        # Phase 5: Generate results
        results = self._generate_results(kol_wallet, token_addresses, suspicious_wallets)
        
        return results
    
    def _collect_kol_first_purchases(self, kol_wallet: str, token_addresses: List[str]):
        """Collect KOL's first purchase data for each token"""
        logger.info("Phase 1: Collecting KOL's first purchase data")
        
        for token_address in token_addresses:
            logger.info(f"Analyzing KOL's trades for token: {token_address}")
            
            trades = self.api.get_wallet_token_trades(token_address, kol_wallet)
            
            if trades:
                # Find the first buy transaction
                buy_trades = [trade for trade in trades if trade.get('type') == 'buy']
                
                if buy_trades:
                    # Sort by timestamp to get the first purchase
                    first_trade = min(buy_trades, key=lambda x: x.get('time', float('inf')))
                    
                    self.kol_purchases[token_address] = TokenPurchase(
                        token_address=token_address,
                        wallet_address=kol_wallet,
                        timestamp=first_trade.get('time', 0),
                        amount=first_trade.get('amount', 0),
                        transaction_id=first_trade.get('signature', ''),
                        volume_usd=first_trade.get('volume_usd', 0)
                    )
                    
                    logger.info(f"Found KOL first purchase for {token_address} at timestamp {first_trade.get('time')}")
                else:
                    logger.warning(f"No buy trades found for KOL wallet in token {token_address}")
            else:
                logger.warning(f"No trades found for KOL wallet in token {token_address}")
    
    def _collect_first_buyers_data(self, token_addresses: List[str]):
        """Collect first buyers data for each token"""
        logger.info("Phase 2: Collecting first buyers data")
        
        for token_address in token_addresses:
            logger.info(f"Fetching first buyers for token: {token_address}")
            
            first_buyers = self.api.get_first_buyers(token_address)
            self.early_buyers_data[token_address] = first_buyers
            
            logger.info(f"Found {len(first_buyers)} first buyers for {token_address}")
    
    def _identify_early_buyers(self) -> Dict[str, List[TokenPurchase]]:
        """Identify wallets that bought before KOL for each token"""
        logger.info("Phase 3: Identifying early buyers")
        
        early_buyers = defaultdict(list)
        
        for token_address, kol_purchase in self.kol_purchases.items():
            kol_timestamp = kol_purchase.timestamp
            first_buyers = self.early_buyers_data.get(token_address, [])
            
            logger.info(f"Analyzing {len(first_buyers)} first buyers for {token_address}")
            logger.info(f"KOL first purchase timestamp: {kol_timestamp}")
            
            for buyer in first_buyers:
                buyer_timestamp = buyer.get('first_buy_time', 0)
                buyer_wallet = buyer.get('wallet', '')
                first_buy = buyer.get('first_buy', {})
                
                # Skip if it's the KOL wallet itself
                if buyer_wallet == kol_purchase.wallet_address:
                    continue
                
                # Check if buyer bought before KOL
                if buyer_timestamp < kol_timestamp and buyer_timestamp > 0:
                    # Check minimum volume filter
                    volume_usd = first_buy.get('volume_usd', 0)
                    if volume_usd >= self.config['min_volume_usd']:
                        
                        purchase = TokenPurchase(
                            token_address=token_address,
                            wallet_address=buyer_wallet,
                            timestamp=buyer_timestamp,
                            amount=first_buy.get('amount', 0),
                            transaction_id=first_buy.get('signature', ''),
                            volume_usd=volume_usd
                        )
                        
                        early_buyers[buyer_wallet].append(purchase)
            
            logger.info(f"Found {len([w for w in early_buyers.keys() if any(p.token_address == token_address for p in early_buyers[w])])} early buyers for {token_address}")
        
        return early_buyers
    
    def _cross_token_analysis(self, early_buyers: Dict[str, List[TokenPurchase]]) -> List[SuspiciousWallet]:
        """Analyze early buyers across multiple tokens"""
        logger.info("Phase 4: Cross-token analysis")
        
        suspicious_wallets = []
        total_tokens = len(self.kol_purchases)
        
        for wallet_address, purchases in early_buyers.items():
            # Group purchases by token
            tokens_bought = set(p.token_address for p in purchases)
            frequency = len(tokens_bought)
            
            # Apply minimum frequency filter
            if frequency < self.config["min_frequency"]:
                continue
            
            consistency_rate = frequency / total_tokens
            
            # Apply minimum consistency filter
            if consistency_rate < self.config["min_consistency"]:
                continue
            
            # Calculate timing advantages and volume
            time_advantages = []
            total_volume_usd = 0
            token_details = []
            
            for purchase in purchases:
                if purchase.token_address in self.kol_purchases:
                    kol_time = self.kol_purchases[purchase.token_address].timestamp
                    time_advantage = (kol_time - purchase.timestamp) / 3600  # Convert to hours
                    time_advantages.append(time_advantage)
                    total_volume_usd += purchase.volume_usd
                    
                    token_details.append({
                        "token_address": purchase.token_address,
                        "purchase_timestamp": purchase.timestamp,
                        "purchase_time": datetime.fromtimestamp(purchase.timestamp).isoformat(),
                        "amount": purchase.amount,
                        "volume_usd": purchase.volume_usd,
                        "time_advantage_hours": time_advantage,
                        "transaction_id": purchase.transaction_id
                    })
            
            avg_time_advantage = sum(time_advantages) / len(time_advantages) if time_advantages else 0
            
            # Calculate suspicion score
            suspicion_score = (
                self.config["frequency_weight"] * consistency_rate +
                self.config["timing_weight"] * min(avg_time_advantage / 24, 1.0) +  # Normalize to max 1 day
                self.config["volume_weight"] * min(total_volume_usd / 10000, 1.0)  # Normalize volume
            )
            
            suspicious_wallet = SuspiciousWallet(
                wallet_address=wallet_address,
                suspicion_score=suspicion_score,
                tokens_bought_early=frequency,
                consistency_rate=consistency_rate,
                avg_time_advantage_hours=avg_time_advantage,
                total_early_volume_usd=total_volume_usd,
                token_details=token_details
            )
            
            suspicious_wallets.append(suspicious_wallet)
        
        # Sort by suspicion score
        suspicious_wallets.sort(key=lambda x: x.suspicion_score, reverse=True)
        
        logger.info(f"Found {len(suspicious_wallets)} suspicious wallets")
        return suspicious_wallets
    
    def _generate_results(self, kol_wallet: str, token_addresses: List[str], 
                         suspicious_wallets: List[SuspiciousWallet]) -> Dict:
        """Generate final analysis results"""
        logger.info("Phase 5: Generating results")
        
        results = {
            "analysis_summary": {
                "kol_wallet": kol_wallet,
                "tokens_analyzed": len(token_addresses),
                "tokens_with_kol_purchases": len(self.kol_purchases),
                "total_first_buyers": sum(len(buyers) for buyers in self.early_buyers_data.values()),
                "suspicious_wallets_found": len(suspicious_wallets),
                "analysis_timestamp": datetime.now().isoformat(),
                "api_used": "Solana Tracker (Free Tier)",
                "min_volume_filter_usd": self.config['min_volume_usd']
            },
            "kol_purchases": {
                token: {
                    "first_purchase_timestamp": purchase.timestamp,
                    "first_purchase_time": datetime.fromtimestamp(purchase.timestamp).isoformat(),
                    "amount": purchase.amount,
                    "volume_usd": purchase.volume_usd,
                    "transaction_id": purchase.transaction_id
                }
                for token, purchase in self.kol_purchases.items()
            },
            "suspicious_wallets": [
                {
                    "wallet_address": wallet.wallet_address,
                    "suspicion_score": round(wallet.suspicion_score, 3),
                    "tokens_bought_early": wallet.tokens_bought_early,
                    "consistency_rate": round(wallet.consistency_rate, 3),
                    "avg_time_advantage_hours": round(wallet.avg_time_advantage_hours, 2),
                    "total_early_volume_usd": round(wallet.total_early_volume_usd, 2),
                    "token_details": wallet.token_details
                }
                for wallet in suspicious_wallets[:10]  # Top 10 most suspicious
            ]
        }
        
        return results

def main():
    """Main function for command line usage"""
    parser = argparse.ArgumentParser(description="KOL Alt Wallet Detection Tool (FREE VERSION)")
    parser.add_argument("--kol-wallet", required=True, help="KOL's public wallet address")
    parser.add_argument("--tokens", required=True, help="Comma-separated list of token addresses")
    parser.add_argument("--api-key", required=True, help="Solana Tracker API key (free tier available)")
    parser.add_argument("--output", default="results_free.json", help="Output file path")
    parser.add_argument("--config", help="Path to configuration JSON file")
    
    args = parser.parse_args()
    
    # Parse token addresses
    token_addresses = [token.strip() for token in args.tokens.split(",")]
    
    # Load configuration if provided
    config = None
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Initialize detector
    detector = KOLAltWalletDetectorFree(args.api_key, config)
    
    try:
        # Run analysis
        results = detector.analyze_kol_wallet(args.kol_wallet, token_addresses)
        
        # Save results
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"Analysis complete. Results saved to {args.output}")
        
        # Print summary
        summary = results["analysis_summary"]
        print(f"\n=== Analysis Summary ===")
        print(f"KOL Wallet: {summary['kol_wallet']}")
        print(f"API Used: {summary['api_used']}")
        print(f"Tokens Analyzed: {summary['tokens_analyzed']}")
        print(f"Tokens with KOL Purchases: {summary['tokens_with_kol_purchases']}")
        print(f"Suspicious Wallets Found: {summary['suspicious_wallets_found']}")
        
        if results["suspicious_wallets"]:
            print(f"\n=== Top Suspicious Wallets ===")
            for i, wallet in enumerate(results["suspicious_wallets"][:3], 1):
                print(f"{i}. {wallet['wallet_address']}")
                print(f"   Suspicion Score: {wallet['suspicion_score']}")
                print(f"   Tokens Bought Early: {wallet['tokens_bought_early']}")
                print(f"   Avg Time Advantage: {wallet['avg_time_advantage_hours']:.1f} hours")
                print(f"   Total Volume: ${wallet['total_early_volume_usd']:.2f}")
                print()
        
        print(f"\n=== API Usage Info ===")
        print(f"Free Tier Limit: 10,000 requests/month")
        print(f"Estimated requests used: {len(token_addresses) * 2} (2 per token)")
        print(f"Sign up for free at: https://solanatracker.io")
    
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        raise

if __name__ == "__main__":
    main()

