# KOL Alt Wallet Detection Tool - FREE VERSION

This tool identifies potential "alt wallets" or "backdoor wallets" of KOLs (Key Opinion Leaders) on Solana by analyzing transaction timing patterns across multiple tokens.

## 🆓 FREE VERSION FEATURES

- **No Credit Card Required**: Uses Solana Tracker's free API tier
- **10,000 Requests/Month**: Enough for extensive KOL analysis
- **First Buyers Data**: Direct access to early buyer information
- **Cross-Token Analysis**: Identifies patterns across multiple tokens
- **Easy Setup**: Simple signup process

## How It Works

The tool analyzes whether certain wallets consistently buy tokens BEFORE a KOL's public wallet makes purchases. If the same wallets appear as early buyers across multiple tokens, they could be the KOL's secret wallets.

### Algorithm Overview

1. **Get KOL's Trading Data**: Find the first purchase timestamp for each token in the KOL's public wallet
2. **Get First Buyers**: For each token, get the first 100 buyers from Solana Tracker
3. **Identify Early Buyers**: Filter buyers who bought BEFORE the KOL's first purchase
4. **Cross-Token Analysis**: Look for wallets that appear as early buyers across multiple tokens
5. **Scoring**: Calculate suspicion scores based on frequency, timing advantage, and volume

## Prerequisites

1. **Free Solana Tracker API Key**:
   - Sign up at [solanatracker.io](https://solanatracker.io)
   - No credit card required
   - 10,000 requests/month free
   - 1 request/second rate limit

2. **Python 3.7+**: Make sure you have Python installed

## Installation

1. Install required packages:
```bash
pip install -r requirements.txt
```

## Usage

### Option 1: Interactive Mode (Recommended)

Run the interactive script:
```bash
python interactive_detector_free.py
```

The script will prompt you for:
- Solana Tracker API key (free)
- KOL's public wallet address
- Token contract addresses (one per line)

### Option 2: Command Line

```bash
python kol_alt_detector_free.py --kol-wallet <wallet_address> --tokens <token1,token2,token3> --api-key <api_key>
```

Example:
```bash
python kol_alt_detector_free.py \
  --kol-wallet "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM" \
  --tokens "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263,So11111111111111111111111111111111111111112" \
  --api-key "your_solana_tracker_api_key"
```

## Configuration

Edit `config_free.json` to adjust analysis parameters:

```json
{
  "min_frequency": 2,           // Minimum tokens a wallet must appear in
  "min_consistency": 0.3,       // Minimum percentage of tokens (30%)
  "frequency_weight": 0.5,      // Weight for frequency in scoring
  "timing_weight": 0.3,         // Weight for timing advantage
  "volume_weight": 0.2,         // Weight for volume
  "min_volume_usd": 10          // Minimum $10 purchase to be considered
}
```

## Understanding Results

### Suspicion Score
- **0.7-1.0**: Highly suspicious - investigate immediately
- **0.5-0.7**: Moderately suspicious - worth investigating
- **0.3-0.5**: Low suspicion - may be coincidental
- **<0.3**: Very low suspicion

### Key Metrics
- **Tokens Bought Early**: How many tokens the wallet bought before the KOL
- **Consistency Rate**: Percentage of analyzed tokens where wallet was early
- **Time Advantage**: Average hours/days the wallet bought before the KOL
- **Total Early Volume**: Total USD value of early purchases

### Example Output
```json
{
  "analysis_summary": {
    "kol_wallet": "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
    "api_used": "Solana Tracker (Free Tier)",
    "tokens_analyzed": 5,
    "suspicious_wallets_found": 2
  },
  "suspicious_wallets": [
    {
      "wallet_address": "ABC123...",
      "suspicion_score": 0.85,
      "tokens_bought_early": 4,
      "consistency_rate": 0.8,
      "avg_time_advantage_hours": 12.5,
      "total_early_volume_usd": 1500.00
    }
  ]
}
```

## API Usage & Limits

### Free Tier Limits
- **10,000 requests/month**: Enough for analyzing 5,000 tokens
- **1 request/second**: Automatically handled by the tool
- **No credit card required**: Just sign up and get your key

### Request Estimation
- **2 requests per token**: One for KOL trades, one for first buyers
- **Analyzing 5 tokens**: Uses ~10 requests
- **Analyzing 50 tokens**: Uses ~100 requests

### Optimization Tips
1. **Focus on Recent Tokens**: Use tokens the KOL promoted in the last 3-6 months
2. **Quality over Quantity**: 3-5 well-chosen tokens often better than 20 random ones
3. **High Volume Tokens**: Choose tokens with good trading activity
4. **Batch Analysis**: Analyze related tokens together

## Manual Investigation Steps

After finding suspicious wallets:

1. **Check on Solscan**: Visit solscan.io and search for the suspicious wallet addresses
2. **Look for Connections**: Check if there are direct transfers between the suspicious wallet and KOL wallet
3. **Analyze Patterns**: Look at the timing and amounts of transactions
4. **Cross-Reference**: Check if the wallets interact with the same DEXs or protocols
5. **Volume Analysis**: Compare trading volumes and patterns

## Advantages Over Paid APIs

✅ **Completely Free**: No subscription or credit card required  
✅ **Perfect Data**: Direct access to first buyers via `/first-buyers/{token}` endpoint  
✅ **Easy Signup**: Get started in minutes  
✅ **Sufficient Limits**: 10k requests/month for extensive analysis  
✅ **Reliable**: Professional API with good uptime  
✅ **Comprehensive**: Includes volume, timing, and PnL data  

## Troubleshooting

### Common Issues

1. **"Invalid API key"**
   - Sign up at solanatracker.io and get a free API key
   - Make sure you're using the correct key format

2. **"No suspicious wallets found"**
   - Lower min_frequency to 1 in config_free.json
   - Try different tokens that the KOL actually promoted
   - Check if the KOL wallet address is correct

3. **"No trades found for KOL wallet"**
   - Verify the wallet address is correct
   - The KOL might not have traded these specific tokens
   - Try more recent tokens

4. **Slow Performance**
   - Free tier has 1 request/second limit (automatically handled)
   - Analyzing many tokens takes time but is worth the wait
   - Consider analyzing fewer tokens at once

## Files

- `kol_alt_detector_free.py`: Main detection tool (free version)
- `interactive_detector_free.py`: User-friendly interactive interface
- `config_free.json`: Configuration parameters for free version
- `requirements.txt`: Python dependencies
- `README_FREE.md`: This documentation

## Getting Your Free API Key

1. Go to [solanatracker.io](https://solanatracker.io)
2. Click "Sign Up" (no credit card required)
3. Verify your email
4. Go to your dashboard
5. Generate your free API key
6. Start analyzing!

## Legal and Ethical Considerations

This tool is for research and analysis purposes only. Always:
- Respect privacy and applicable laws
- Use findings responsibly
- Verify results through multiple sources
- Consider legitimate reasons for early purchases

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Verify your API key is working
3. Test with a smaller dataset first
4. Review the Solana Tracker API documentation

## License

This tool is provided as-is for educational and research purposes.

---

**🚀 Ready to find those alt wallets? Get your free API key and start analyzing!**

