# SOLANA TRACKER API - PRODUCTION DOCUMENTATION

**Base URL**: `https://data.solanatracker.io`
**Authentication**: x-api-key header
**Total Endpoints**: 38

## COMPLETE ENDPOINT DOCUMENTATION

## Token Endpoints

### GET /tokens/{tokenAddress}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/by-pool/{poolAddress}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/{tokenAddress}/holders

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/{tokenAddress}/holders/top

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/{tokenAddress}/ath

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/latest

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### POST /tokens/multi

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/trending

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/volume

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/multi/all

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /tokens/multi/graduated

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Price Endpoints

### GET /price

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /price/history

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /price/history/timestamp

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /price/history/range

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### POST /price

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET/POST /price/multi

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Wallet Endpoints

### GET /wallet/{owner}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /wallet/{owner}/basic

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /wallet/{owner}/page/{page}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /wallet/{owner}/trades

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /wallet/{owner}/chart

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Trade Endpoints

### GET /trades/{tokenAddress}/{poolAddress}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /trades/{tokenAddress}/{poolAddress}/{owner}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /trades/{tokenAddress}/by-wallet/{owner}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Chart Data

### GET /chart/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /holders/chart/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## PnL Data

### GET /pnl/{wallet}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /first-buyers/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /pnl/{wallet}/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Top Traders

### GET /top-traders/all

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /top-traders/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Stats and Events

### GET /stats/{token}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /events/{tokenAddress}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

### GET /events/{tokenAddress}/{poolAddress}

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

## Credits

### GET /credits

**Description**: }GET /deployer/{wallet} - Get Tokens by DeployerGET /deployer/{wallet}Retrieves all tokens created by a specific wallet with pagination support.Query Parameters

**Pagination**: Supported

**Response Example**:
```json
{
{
{
{
```

---

