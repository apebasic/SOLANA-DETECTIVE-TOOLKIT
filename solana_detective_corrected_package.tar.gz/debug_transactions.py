#!/usr/bin/env python3

import requests
import json

api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
headers = {'x-api-key': api_key, 'accept': 'application/json'}

# Gorkfather token address
token_address = "74Eyom7Y28urkxRgyZvNHs77wwG4djoQeQit6Csnpump"

print(f"🔍 Examining transaction data for Gorkfather token:")
print(f"Token: {token_address}")
print("=" * 80)

# Get token data from graduated tokens endpoint
print("\n📊 Getting token data from graduated tokens endpoint...")
url = "https://data.solanatracker.io/tokens/multi/graduated"
response = requests.get(url, headers=headers, timeout=30)

if response.status_code == 200:
    tokens = response.json()
    gorkfather_token = None
    
    for token in tokens:
        if token.get('token', {}).get('mint') == token_address:
            gorkfather_token = token
            break
    
    if gorkfather_token:
        print("✅ Found Gorkfather in graduated tokens")
        print("\n🔍 Raw token data structure:")
        print(json.dumps(gorkfather_token, indent=2))
        
        # Check what fields are available
        print("\n📋 Available fields:")
        for key, value in gorkfather_token.items():
            print(f"  {key}: {type(value)} = {value}")
    else:
        print("❌ Gorkfather not found in graduated tokens")
else:
    print(f"❌ Error: {response.text}")

# Also try to get token info directly
print(f"\n📊 Getting token info directly...")
direct_url = f"https://data.solanatracker.io/token/{token_address}"
direct_response = requests.get(direct_url, headers=headers, timeout=30)

if direct_response.status_code == 200:
    direct_data = direct_response.json()
    print("✅ Direct token data:")
    print(json.dumps(direct_data, indent=2))
else:
    print(f"❌ Direct token error: {direct_response.text}")
