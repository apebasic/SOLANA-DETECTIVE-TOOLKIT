#!/usr/bin/env python3
"""
Debug script to test API calls and see what's being returned
"""

import requests
import json

def test_api_calls():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {"x-api-key": api_key}
    base_url = "https://data.solanatracker.io"
    
    # Test token: PFP
    token_address = "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump"
    
    print(f"🔍 Testing API calls for token: {token_address}")
    print("=" * 60)
    
    # Get token info
    print("1. Getting token info...")
    url = f"{base_url}/tokens/{token_address}"
    response = requests.get(url, headers=headers)
    
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        token_data = response.json()
        print(f"Token name: {token_data.get('name', 'Unknown')}")
        print(f"Symbol: {token_data.get('symbol', 'Unknown')}")
        
        pools = token_data.get('pools', [])
        print(f"Number of pools: {len(pools)}")
        
        if pools:
            # Test first pool
            first_pool = pools[0]
            pool_address = first_pool.get('address', '')
            print(f"\n2. Testing first pool: {pool_address}")
            
            # Get trades for first pool
            trades_url = f"{base_url}/trades/{token_address}/{pool_address}"
            trades_response = requests.get(trades_url, headers=headers, params={"page": 1})
            
            print(f"Trades status: {trades_response.status_code}")
            if trades_response.status_code == 200:
                trades_data = trades_response.json()
                print(f"Response keys: {list(trades_data.keys())}")
                
                if 'trades' in trades_data:
                    trades = trades_data['trades']
                    print(f"Number of trades: {len(trades)}")
                    
                    if trades:
                        # Show first trade structure
                        first_trade = trades[0]
                        print(f"\nFirst trade structure:")
                        for key, value in first_trade.items():
                            print(f"  {key}: {value}")
                        
                        # Count buy transactions
                        buy_count = sum(1 for trade in trades if trade.get('type') == 'buy')
                        print(f"\nBuy transactions: {buy_count}/{len(trades)}")
                        
                        # Show unique wallets
                        wallets = set()
                        for trade in trades:
                            if trade.get('type') == 'buy' and trade.get('wallet'):
                                wallets.add(trade.get('wallet'))
                        print(f"Unique buyer wallets: {len(wallets)}")
                    else:
                        print("No trades found in response")
                else:
                    print("No 'trades' key in response")
                    print(f"Full response: {trades_data}")
            else:
                print(f"Error getting trades: {trades_response.text}")
        else:
            print("No pools found")
    else:
        print(f"Error getting token info: {response.text}")

if __name__ == "__main__":
    test_api_calls()

