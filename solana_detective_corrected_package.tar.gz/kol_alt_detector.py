#!/usr/bin/env python3
"""
KOL Alt Wallet Detection Tool

This tool identifies potential "alt wallets" or "backdoor wallets" of KOLs (Key Opinion Leaders) 
on Solana by analyzing transaction timing patterns across multiple tokens.

Usage:
    python kol_alt_detector.py --kol-wallet <wallet_address> --tokens <token1,token2,token3> --api-key <solscan_api_key>
"""

import requests
import pandas as pd
import json
import time
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import logging
from dataclasses import dataclass
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class TokenPurchase:
    """Data class for token purchase information"""
    token_address: str
    wallet_address: str
    timestamp: int
    amount: float
    transaction_id: str
    block_time: str

@dataclass
class SuspiciousWallet:
    """Data class for suspicious wallet analysis results"""
    wallet_address: str
    suspicion_score: float
    tokens_bought_early: int
    consistency_rate: float
    avg_time_advantage_hours: float
    total_early_volume: float
    token_details: List[Dict]

class SolscanAPI:
    """Wrapper for Solscan Pro API"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://pro-api.solscan.io/v2.0"
        self.headers = {
            "token": api_key,
            "accept": "application/json"
        }
        self.rate_limit_delay = 0.2  # 200ms between requests
    
    def _make_request(self, endpoint: str, params: Dict) -> Dict:
        """Make API request with rate limiting and error handling"""
        url = f"{self.base_url}/{endpoint}"
        
        try:
            time.sleep(self.rate_limit_delay)
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            raise
    
    def get_account_transfers(self, wallet_address: str, token_address: str = None, 
                            from_time: int = None, to_time: int = None, 
                            page_size: int = 100) -> List[Dict]:
        """Get transfer data for a specific wallet"""
        params = {
            "address": wallet_address,
            "page_size": page_size,
            "sort_by": "block_time",
            "sort_order": "asc"
        }
        
        if token_address:
            params["token"] = token_address
        if from_time:
            params["from_time"] = from_time
        if to_time:
            params["to_time"] = to_time
        
        all_transfers = []
        page = 1
        
        while True:
            params["page"] = page
            logger.info(f"Fetching transfers for {wallet_address}, page {page}")
            
            response = self._make_request("account/transfer", params)
            
            if not response.get("success") or not response.get("data"):
                break
            
            transfers = response["data"]
            all_transfers.extend(transfers)
            
            if len(transfers) < page_size:
                break
            
            page += 1
        
        return all_transfers
    
    def get_token_transfers(self, token_address: str, from_time: int = None, 
                          to_time: int = None, page_size: int = 100) -> List[Dict]:
        """Get all transfer data for a specific token"""
        params = {
            "address": token_address,
            "page_size": page_size,
            "sort_by": "block_time",
            "sort_order": "asc",
            "activity_type": ["ACTIVITY_SPL_TRANSFER"]
        }
        
        if from_time:
            params["block_time"] = [from_time, to_time or int(time.time())]
        
        all_transfers = []
        page = 1
        
        while True:
            params["page"] = page
            logger.info(f"Fetching token transfers for {token_address}, page {page}")
            
            response = self._make_request("token/transfer", params)
            
            if not response.get("success") or not response.get("data"):
                break
            
            transfers = response["data"]
            all_transfers.extend(transfers)
            
            if len(transfers) < page_size:
                break
            
            page += 1
        
        return all_transfers

class KOLAltWalletDetector:
    """Main class for detecting KOL alt wallets"""
    
    def __init__(self, api_key: str, config: Dict = None):
        self.api = SolscanAPI(api_key)
        self.config = config or self._default_config()
        self.kol_purchases = {}
        self.early_buyers = defaultdict(list)
        
    def _default_config(self) -> Dict:
        """Default configuration parameters"""
        return {
            "min_frequency": 2,
            "min_consistency": 0.3,
            "max_time_window_days": 180,
            "frequency_weight": 0.5,
            "timing_weight": 0.3,
            "volume_weight": 0.2,
            "exclude_addresses": [
                # Common DEX and protocol addresses to exclude
                "11111111111111111111111111111111",  # System program
                "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",  # Token program
            ]
        }
    
    def analyze_kol_wallet(self, kol_wallet: str, token_addresses: List[str]) -> Dict:
        """Main analysis function"""
        logger.info(f"Starting analysis for KOL wallet: {kol_wallet}")
        logger.info(f"Analyzing {len(token_addresses)} tokens")
        
        # Phase 1: Collect KOL purchase data
        self._collect_kol_purchases(kol_wallet, token_addresses)
        
        # Phase 2: Identify early buyers for each token
        self._identify_early_buyers(token_addresses)
        
        # Phase 3: Cross-token analysis
        suspicious_wallets = self._cross_token_analysis()
        
        # Phase 4: Generate results
        results = self._generate_results(kol_wallet, token_addresses, suspicious_wallets)
        
        return results
    
    def _collect_kol_purchases(self, kol_wallet: str, token_addresses: List[str]):
        """Collect first purchase data for KOL wallet across all tokens"""
        logger.info("Phase 1: Collecting KOL purchase data")
        
        for token_address in token_addresses:
            logger.info(f"Analyzing KOL purchases for token: {token_address}")
            
            # Get transfers for this token from KOL wallet
            transfers = self.api.get_account_transfers(
                wallet_address=kol_wallet,
                token_address=token_address
            )
            
            # Find first purchase (incoming transfer)
            first_purchase = None
            for transfer in transfers:
                if (transfer.get("to_address") == kol_wallet and 
                    transfer.get("token_address") == token_address and
                    transfer.get("activity_type") == "ACTIVITY_SPL_TRANSFER"):
                    first_purchase = transfer
                    break
            
            if first_purchase:
                self.kol_purchases[token_address] = TokenPurchase(
                    token_address=token_address,
                    wallet_address=kol_wallet,
                    timestamp=first_purchase["block_time"],
                    amount=float(first_purchase["amount"]) / (10 ** first_purchase["token_decimals"]),
                    transaction_id=first_purchase["trans_id"],
                    block_time=first_purchase["time"]
                )
                logger.info(f"Found KOL first purchase for {token_address} at {first_purchase['time']}")
            else:
                logger.warning(f"No purchases found for KOL wallet in token {token_address}")
    
    def _identify_early_buyers(self, token_addresses: List[str]):
        """Identify wallets that bought before KOL for each token"""
        logger.info("Phase 2: Identifying early buyers")
        
        for token_address in token_addresses:
            if token_address not in self.kol_purchases:
                continue
            
            kol_purchase_time = self.kol_purchases[token_address].timestamp
            logger.info(f"Finding early buyers for {token_address} before {kol_purchase_time}")
            
            # Get all transfers for this token before KOL's first purchase
            transfers = self.api.get_token_transfers(
                token_address=token_address,
                to_time=kol_purchase_time - 1  # 1 second before KOL purchase
            )
            
            # Process transfers to find unique buyers
            for transfer in transfers:
                if (transfer.get("activity_type") == "ACTIVITY_SPL_TRANSFER" and
                    transfer.get("to_address") not in self.config["exclude_addresses"]):
                    
                    buyer_wallet = transfer["to_address"]
                    
                    # Skip if it's the KOL wallet itself
                    if buyer_wallet == self.kol_purchases[token_address].wallet_address:
                        continue
                    
                    purchase = TokenPurchase(
                        token_address=token_address,
                        wallet_address=buyer_wallet,
                        timestamp=transfer["block_time"],
                        amount=float(transfer["amount"]) / (10 ** transfer["token_decimals"]),
                        transaction_id=transfer["trans_id"],
                        block_time=transfer["time"]
                    )
                    
                    self.early_buyers[buyer_wallet].append(purchase)
            
            logger.info(f"Found {len(set(t.wallet_address for t in self.early_buyers.values() if any(p.token_address == token_address for p in t)))} early buyers for {token_address}")
    
    def _cross_token_analysis(self) -> List[SuspiciousWallet]:
        """Analyze early buyers across multiple tokens"""
        logger.info("Phase 3: Cross-token analysis")
        
        suspicious_wallets = []
        total_tokens = len(self.kol_purchases)
        
        for wallet_address, purchases in self.early_buyers.items():
            # Group purchases by token
            tokens_bought = set(p.token_address for p in purchases)
            frequency = len(tokens_bought)
            
            # Apply minimum frequency filter
            if frequency < self.config["min_frequency"]:
                continue
            
            consistency_rate = frequency / total_tokens
            
            # Apply minimum consistency filter
            if consistency_rate < self.config["min_consistency"]:
                continue
            
            # Calculate timing advantages
            time_advantages = []
            total_volume = 0
            token_details = []
            
            for purchase in purchases:
                if purchase.token_address in self.kol_purchases:
                    kol_time = self.kol_purchases[purchase.token_address].timestamp
                    time_advantage = (kol_time - purchase.timestamp) / 3600  # Convert to hours
                    time_advantages.append(time_advantage)
                    total_volume += purchase.amount
                    
                    token_details.append({
                        "token_address": purchase.token_address,
                        "purchase_time": purchase.block_time,
                        "amount": purchase.amount,
                        "time_advantage_hours": time_advantage,
                        "transaction_id": purchase.transaction_id
                    })
            
            avg_time_advantage = sum(time_advantages) / len(time_advantages) if time_advantages else 0
            
            # Calculate suspicion score
            suspicion_score = (
                self.config["frequency_weight"] * consistency_rate +
                self.config["timing_weight"] * min(avg_time_advantage / 24, 1.0) +  # Normalize to max 1 day
                self.config["volume_weight"] * min(total_volume / 1000000, 1.0)  # Normalize volume
            )
            
            suspicious_wallet = SuspiciousWallet(
                wallet_address=wallet_address,
                suspicion_score=suspicion_score,
                tokens_bought_early=frequency,
                consistency_rate=consistency_rate,
                avg_time_advantage_hours=avg_time_advantage,
                total_early_volume=total_volume,
                token_details=token_details
            )
            
            suspicious_wallets.append(suspicious_wallet)
        
        # Sort by suspicion score
        suspicious_wallets.sort(key=lambda x: x.suspicion_score, reverse=True)
        
        logger.info(f"Found {len(suspicious_wallets)} suspicious wallets")
        return suspicious_wallets
    
    def _generate_results(self, kol_wallet: str, token_addresses: List[str], 
                         suspicious_wallets: List[SuspiciousWallet]) -> Dict:
        """Generate final analysis results"""
        logger.info("Phase 4: Generating results")
        
        results = {
            "analysis_summary": {
                "kol_wallet": kol_wallet,
                "tokens_analyzed": len(token_addresses),
                "tokens_with_kol_purchases": len(self.kol_purchases),
                "total_early_buyers": len(self.early_buyers),
                "suspicious_wallets_found": len(suspicious_wallets),
                "analysis_timestamp": datetime.now().isoformat()
            },
            "kol_purchases": {
                token: {
                    "first_purchase_time": purchase.block_time,
                    "amount": purchase.amount,
                    "transaction_id": purchase.transaction_id
                }
                for token, purchase in self.kol_purchases.items()
            },
            "suspicious_wallets": [
                {
                    "wallet_address": wallet.wallet_address,
                    "suspicion_score": round(wallet.suspicion_score, 3),
                    "tokens_bought_early": wallet.tokens_bought_early,
                    "consistency_rate": round(wallet.consistency_rate, 3),
                    "avg_time_advantage_hours": round(wallet.avg_time_advantage_hours, 2),
                    "total_early_volume": round(wallet.total_early_volume, 6),
                    "token_details": wallet.token_details
                }
                for wallet in suspicious_wallets[:10]  # Top 10 most suspicious
            ]
        }
        
        return results

def main():
    """Main function for command line usage"""
    parser = argparse.ArgumentParser(description="KOL Alt Wallet Detection Tool")
    parser.add_argument("--kol-wallet", required=True, help="KOL's public wallet address")
    parser.add_argument("--tokens", required=True, help="Comma-separated list of token addresses")
    parser.add_argument("--api-key", required=True, help="Solscan Pro API key")
    parser.add_argument("--output", default="results.json", help="Output file path")
    parser.add_argument("--config", help="Path to configuration JSON file")
    
    args = parser.parse_args()
    
    # Parse token addresses
    token_addresses = [token.strip() for token in args.tokens.split(",")]
    
    # Load configuration if provided
    config = None
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Initialize detector
    detector = KOLAltWalletDetector(args.api_key, config)
    
    try:
        # Run analysis
        results = detector.analyze_kol_wallet(args.kol_wallet, token_addresses)
        
        # Save results
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"Analysis complete. Results saved to {args.output}")
        
        # Print summary
        summary = results["analysis_summary"]
        print(f"\n=== Analysis Summary ===")
        print(f"KOL Wallet: {summary['kol_wallet']}")
        print(f"Tokens Analyzed: {summary['tokens_analyzed']}")
        print(f"Tokens with KOL Purchases: {summary['tokens_with_kol_purchases']}")
        print(f"Suspicious Wallets Found: {summary['suspicious_wallets_found']}")
        
        if results["suspicious_wallets"]:
            print(f"\n=== Top Suspicious Wallets ===")
            for i, wallet in enumerate(results["suspicious_wallets"][:3], 1):
                print(f"{i}. {wallet['wallet_address']}")
                print(f"   Suspicion Score: {wallet['suspicion_score']}")
                print(f"   Tokens Bought Early: {wallet['tokens_bought_early']}")
                print(f"   Avg Time Advantage: {wallet['avg_time_advantage_hours']:.1f} hours")
                print()
    
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        raise

if __name__ == "__main__":
    main()

