#!/usr/bin/env python3
"""
Debug Timeframe Search
Debug script to identify why no transactions are found in timeframes
"""

import requests
import json
import time
from datetime import datetime, timezone
import pytz
from typing import Dict, List, Set, Tuple

class DebugTimeframeSearch:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://data.solanatracker.io"
        self.headers = {"x-api-key": api_key}
    
    def get_token_info(self, token_address: str) -> Dict:
        """Get token information including pools"""
        url = f"{self.base_url}/tokens/{token_address}"
        response = requests.get(url, headers=self.headers)
        if response.status_code == 200:
            return response.json()
        return {}
    
    def get_top_liquidity_pool(self, token_address: str) -> Tuple[str, float]:
        """Get the pool with highest liquidity for a token"""
        token_info = self.get_token_info(token_address)
        if not token_info:
            return "", 0
        
        pools = token_info.get('pools', [])
        if not pools:
            return "", 0
        
        # Sort pools by liquidity (USD) and take top one
        pools_with_liquidity = []
        for pool in pools:
            liquidity_usd = pool.get('liquidity', {}).get('usd', 0)
            pools_with_liquidity.append((pool, liquidity_usd))
        
        pools_with_liquidity.sort(key=lambda x: x[1], reverse=True)
        top_pool = pools_with_liquidity[0][0]
        top_liquidity = pools_with_liquidity[0][1]
        
        return top_pool.get('poolId', ''), top_liquidity
    
    def utc_to_unix_timestamp(self, year: int, month: int, day: int, 
                             hour: int, minute: int, second: int = 0) -> int:
        """Convert UTC time to Unix timestamp"""
        dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)  # Convert to milliseconds
    
    def debug_trades_in_timeframe(self, token_address: str, pool_address: str,
                                 start_timestamp: int, end_timestamp: int) -> List[Dict]:
        """
        Debug version - shows all trades and their timestamps
        """
        print(f"🔍 DEBUG: Searching trades from {start_timestamp} to {end_timestamp}")
        print(f"🔍 DEBUG: Start time: {datetime.fromtimestamp(start_timestamp/1000, tz=timezone.utc)}")
        print(f"🔍 DEBUG: End time: {datetime.fromtimestamp(end_timestamp/1000, tz=timezone.utc)}")
        
        trades_in_timeframe = []
        page = 1
        max_pages = 20  # Limit for debugging
        
        while page <= max_pages:
            print(f"\n📄 DEBUG: Requesting page {page}")
            url = f"{self.base_url}/trades/{token_address}/{pool_address}"
            params = {"page": page}
            
            response = requests.get(url, headers=self.headers, params=params)
            print(f"📄 DEBUG: Response status: {response.status_code}")
            
            if response.status_code != 200:
                print(f"❌ DEBUG: API error: {response.text}")
                break
            
            data = response.json()
            trades = data.get('trades', [])
            
            print(f"📄 DEBUG: Page {page} returned {len(trades)} trades")
            
            if not trades:
                print(f"📄 DEBUG: No more trades, stopping at page {page}")
                break
            
            # Show first few trades for debugging
            if page <= 3:
                print(f"📄 DEBUG: First 3 trades on page {page}:")
                for i, trade in enumerate(trades[:3]):
                    trade_time = trade.get('time', 0)
                    trade_type = trade.get('type', 'unknown')
                    wallet = trade.get('wallet', 'unknown')
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                    in_range = start_timestamp <= trade_time <= end_timestamp
                    print(f"    {i+1}. Time: {trade_time} ({dt}) | Type: {trade_type} | In range: {in_range}")
            
            # Check all trades in this page
            found_in_timeframe = 0
            oldest_trade_time = None
            newest_trade_time = None
            
            for trade in trades:
                trade_time = trade.get('time', 0)
                
                if oldest_trade_time is None or trade_time < oldest_trade_time:
                    oldest_trade_time = trade_time
                if newest_trade_time is None or trade_time > newest_trade_time:
                    newest_trade_time = trade_time
                
                # Check if trade is in our timeframe
                if start_timestamp <= trade_time <= end_timestamp:
                    trades_in_timeframe.append(trade)
                    found_in_timeframe += 1
            
            print(f"📄 DEBUG: Page {page} - Found {found_in_timeframe} trades in timeframe")
            print(f"📄 DEBUG: Page {page} - Oldest trade: {datetime.fromtimestamp(oldest_trade_time/1000, tz=timezone.utc) if oldest_trade_time else 'None'}")
            print(f"📄 DEBUG: Page {page} - Newest trade: {datetime.fromtimestamp(newest_trade_time/1000, tz=timezone.utc) if newest_trade_time else 'None'}")
            
            # Check if we've gone past our timeframe
            if oldest_trade_time and oldest_trade_time < start_timestamp:
                print(f"📄 DEBUG: Reached trades older than timeframe, stopping search")
                break
            
            page += 1
            time.sleep(1.1)  # Rate limiting
        
        print(f"\n✅ DEBUG: Total trades found in timeframe: {len(trades_in_timeframe)}")
        return trades_in_timeframe

def main():
    # Load API key
    try:
        with open('/home/ubuntu/config.json', 'r') as f:
            config = json.load(f)
            api_key = config.get('api_key', '')
    except:
        print("❌ Could not load API key from config.json")
        return
    
    if not api_key:
        print("❌ No API key found in config")
        return
    
    debugger = DebugTimeframeSearch(api_key)
    
    print("🚀 DEBUG TIMEFRAME SEARCH")
    print("=" * 70)
    
    # Debug Mortgage token
    mortgage_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    
    # Get pool info
    pool_address, liquidity = debugger.get_top_liquidity_pool(mortgage_address)
    print(f"📊 Mortgage token: {mortgage_address}")
    print(f"📊 Top pool: {pool_address}")
    print(f"📊 Liquidity: ${liquidity:,.2f}")
    
    # Convert timeframe: June 25, 19:30 UTC to 19:45 UTC
    start_time = debugger.utc_to_unix_timestamp(2025, 6, 25, 19, 30, 0)
    end_time = debugger.utc_to_unix_timestamp(2025, 6, 25, 19, 45, 0)
    
    print(f"📊 Target timeframe: {start_time} to {end_time}")
    
    # Debug search
    if pool_address:
        trades = debugger.debug_trades_in_timeframe(
            mortgage_address, pool_address, start_time, end_time
        )
        
        print(f"\n📊 FINAL RESULT: {len(trades)} trades found in timeframe")
        
        if trades:
            print("\n🎯 TRADES IN TIMEFRAME:")
            for i, trade in enumerate(trades[:10]):  # Show first 10
                trade_time = trade.get('time', 0)
                trade_type = trade.get('type', 'unknown')
                wallet = trade.get('wallet', 'unknown')
                amount = trade.get('amount', 0)
                dt = datetime.fromtimestamp(trade_time / 1000, tz=timezone.utc)
                print(f"  {i+1}. {dt} | {trade_type} | {wallet[:8]}... | {amount:,.0f}")
    else:
        print("❌ No pool found for Mortgage token")

if __name__ == "__main__":
    main()

