#!/usr/bin/env python3
"""
Check sell volume using volumeSol field for consistency
"""

import requests
import json

def main():
    # Configuration
    wallet_address = "CGU2AJLzf28QzRq3Lz4F3sGSZhKCxPnRHe6fG9MoXzfZ"
    token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    
    # Load API key
    with open('/home/ubuntu/config.json', 'r') as f:
        config = json.load(f)
        api_key = config['api_key']
    
    # Get trades for this wallet and token
    url = f"https://data.solanatracker.io/trades/{token_address}/by-wallet/{wallet_address}"
    headers = {"x-api-key": api_key}
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            
            if 'trades' in data and data['trades']:
                trades = data['trades']
                
                # Filter for sell transactions
                sell_trades = [trade for trade in trades if trade.get('type') == 'sell']
                
                # Calculate using volumeSol field
                total_volume_sol = sum([float(trade.get('volumeSol', 0)) for trade in sell_trades])
                
                print(f"Number of sell transactions: {len(sell_trades)}")
                print(f"Total volume in SOL (volumeSol field): {total_volume_sol:.6f} SOL")
                
            else:
                print("No trades found")
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

