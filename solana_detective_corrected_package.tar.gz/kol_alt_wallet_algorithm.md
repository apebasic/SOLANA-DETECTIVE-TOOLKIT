# KOL Alt Wallet Detection Algorithm Design

## Overview
This tool identifies potential "alt wallets" or "backdoor wallets" of KOLs (Key Opinion Leaders) on Solana by analyzing transaction timing patterns across multiple tokens.

## Core Hypothesis
If a KOL has secret wallets, these wallets will consistently buy tokens BEFORE the KOL's public wallet makes purchases, creating a detectable pattern across multiple tokens.

## Algorithm Steps

### Phase 1: Data Collection for KOL Public Wallet
1. **Input Requirements:**
   - KOL's public wallet address
   - List of token contract addresses that the KOL bought
   - Time window for analysis (optional, default: last 6 months)

2. **For each token, collect:**
   - All transfers involving the KOL's public wallet
   - Find the FIRST purchase transaction timestamp
   - Record: `{token_address, first_purchase_timestamp, amount, transaction_id}`

### Phase 2: Identify Early Buyers
1. **For each token:**
   - Query all transfers for that token BEFORE the KOL's first purchase
   - Filter for "buy" transactions (transfers TO wallets, not FROM)
   - Collect all unique wallet addresses that bought before the KOL
   - Record: `{token_address, early_buyer_wallet, purchase_timestamp, amount}`

### Phase 3: Cross-Token Analysis
1. **Aggregate early buyers across all tokens:**
   - Create a frequency map: `{wallet_address: [list_of_tokens_bought_early]}`
   - Calculate metrics for each wallet:
     - Number of tokens bought before KOL (frequency)
     - Average time gap between early buyer and KOL purchase
     - Total volume of early purchases
     - Consistency score (frequency / total_tokens_analyzed)

### Phase 4: Scoring and Ranking
1. **Calculate suspicion score for each wallet:**
   ```
   suspicion_score = (
       frequency_weight * (tokens_bought_early / total_tokens) +
       timing_weight * avg_time_advantage_score +
       volume_weight * normalized_volume_score
   )
   ```

2. **Filtering criteria:**
   - Minimum frequency: Wallet must appear in at least 2 tokens
   - Minimum consistency: At least 30% of analyzed tokens
   - Exclude obvious DEX/protocol addresses

### Phase 5: Results and Validation
1. **Output ranked list of suspicious wallets with:**
   - Wallet address
   - Suspicion score
   - Number of tokens bought early
   - Average time advantage (hours/days before KOL)
   - Total early purchase volume
   - List of specific tokens and timestamps

2. **Additional validation checks:**
   - Check if suspicious wallets have any direct connections to KOL wallet
   - Analyze transaction patterns and timing
   - Look for fund transfers between wallets

## API Implementation Strategy

### Primary Data Sources:
1. **Solscan Account Transfer API** - For KOL wallet analysis
2. **Solscan Token Transfer API** - For token-specific early buyer analysis

### API Call Optimization:
1. Use time filtering to reduce data volume
2. Implement pagination for large datasets
3. Cache results to avoid redundant API calls
4. Respect rate limits with proper delays

### Data Processing:
1. Store intermediate results in local files
2. Use pandas for data analysis and aggregation
3. Implement progress tracking for long-running analysis

## Configuration Parameters:
- `min_frequency`: Minimum number of tokens a wallet must appear in (default: 2)
- `min_consistency`: Minimum percentage of tokens (default: 0.3)
- `max_time_window`: Maximum days to look back (default: 180)
- `frequency_weight`: Weight for frequency in scoring (default: 0.5)
- `timing_weight`: Weight for timing advantage (default: 0.3)
- `volume_weight`: Weight for volume (default: 0.2)

## Expected Output Format:
```json
{
  "analysis_summary": {
    "kol_wallet": "...",
    "tokens_analyzed": 5,
    "total_early_buyers": 1247,
    "suspicious_wallets_found": 3
  },
  "suspicious_wallets": [
    {
      "wallet_address": "...",
      "suspicion_score": 0.85,
      "tokens_bought_early": 4,
      "consistency_rate": 0.8,
      "avg_time_advantage_hours": 12.5,
      "total_early_volume_usd": 15000,
      "token_details": [...]
    }
  ]
}
```

This algorithm provides a systematic approach to identify potential alt wallets by leveraging transaction timing patterns and cross-token analysis.

