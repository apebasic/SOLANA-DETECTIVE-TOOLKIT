#!/usr/bin/env python3
"""
Find all buyers in the first hour after launch for the 4 tokens
Using earliest pool creation times as launch times
"""

import requests
import json
from datetime import datetime, timedelta
from collections import defaultdict
import time

def get_buyers_in_timeframe(token_address, start_time, end_time, api_key, token_name):
    """Get all buyers in a specific timeframe"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    buyers = set()
    
    try:
        # Get token info to find pools
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            return buyers
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            return buyers
        
        # Convert datetime to timestamps
        start_timestamp = int(start_time.timestamp())
        end_timestamp = int(end_time.timestamp())
        
        print(f"   🔍 Searching {len(pools)} pools from {start_time.strftime('%H:%M:%S')} to {end_time.strftime('%H:%M:%S')}")
        
        # Search each pool
        for pool_idx, pool in enumerate(pools, 1):
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
            
            print(f"   📊 Pool {pool_idx}/{len(pools)}: {pool_id[:8]}...")
            
            # Get trades from this pool
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            page = 1
            max_pages = 30  # Increased for first hour coverage
            
            while page <= max_pages:
                try:
                    params = {'page': page, 'limit': 100}
                    
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        break
                    
                    # Filter trades by time and extract buyers
                    relevant_trades = 0
                    page_buyers = 0
                    
                    for trade in trades:
                        trade_time = trade.get('time', 0)
                        if trade_time:
                            # Convert milliseconds to seconds
                            if trade_time > 1e12:
                                trade_time = trade_time / 1000
                            
                            trade_datetime = datetime.fromtimestamp(trade_time)
                            
                            # Check if trade is in our timeframe
                            if start_time <= trade_datetime <= end_time:
                                relevant_trades += 1
                                if trade.get('type') == 'buy':
                                    wallet = trade.get('wallet')
                                    if wallet:
                                        buyers.add(wallet)
                                        page_buyers += 1
                    
                    if page % 5 == 0:
                        print(f"      📄 Page {page}: {len(buyers)} total buyers, {relevant_trades} relevant trades")
                    
                    # If no relevant trades and we're past page 5, likely outside timeframe
                    if relevant_trades == 0 and page > 5:
                        break
                    
                    page += 1
                    time.sleep(0.8)  # Slightly faster for first hour analysis
                    
                except Exception as e:
                    print(f"      ❌ Exception page {page}: {e}")
                    break
        
        return buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return buyers

def analyze_first_hour_buyers():
    """Analyze buyers in first hour after launch for all 4 tokens"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # Launch times from earliest pool creation
    launch_times = {
        "PFP": datetime(2025, 6, 27, 9, 15, 48),
        "GIRLIES": datetime(2025, 6, 27, 4, 40, 11),
        "SYN": datetime(2025, 6, 26, 10, 49, 6),
        "PUMPHOUSE": datetime(2025, 6, 26, 10, 58, 25)
    }
    
    tokens = {
        "PFP": "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",
        "GIRLIES": "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
        "SYN": "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "PUMPHOUSE": "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump"
    }
    
    print(f"🚀 FIRST HOUR BUYER ANALYSIS")
    print("=" * 60)
    print("Finding all buyers in the first hour after launch")
    print("Using earliest pool creation times as launch times")
    print("=" * 60)
    
    token_buyers = {}
    
    # Step 1: Get buyers for each token in first hour
    for name, token in tokens.items():
        launch_time = launch_times[name]
        end_time = launch_time + timedelta(hours=1)
        
        print(f"\n📊 {name} ({token[:8]}...):")
        print(f"   {token}")
        print(f"   🚀 Launch: {launch_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   ⏰ First hour: {launch_time.strftime('%H:%M:%S')} - {end_time.strftime('%H:%M:%S')}")
        
        # Get buyers in the first hour
        buyers = get_buyers_in_timeframe(token, launch_time, end_time, api_key, name)
        token_buyers[name] = buyers
        
        print(f"   ✅ Found {len(buyers)} first-hour buyers")
    
    # Step 2: Find cross-token patterns
    print(f"\n🎯 CROSS-TOKEN ANALYSIS (FIRST HOUR):")
    print("=" * 50)
    
    # Track which tokens each wallet bought
    wallet_tokens = defaultdict(set)
    for token_name, buyers in token_buyers.items():
        for wallet in buyers:
            wallet_tokens[wallet].add(token_name)
    
    # Group by number of tokens bought
    by_count = defaultdict(list)
    for wallet, tokens_bought in wallet_tokens.items():
        count = len(tokens_bought)
        by_count[count].append((wallet, tokens_bought))
    
    # Show results
    found_matches = False
    for count in sorted(by_count.keys(), reverse=True):
        wallets = by_count[count]
        print(f"\n📋 {len(wallets)} WALLETS BOUGHT {count}/4 TOKENS (FIRST HOUR):")
        
        if count >= 2:  # Show wallets that bought 2+ tokens
            found_matches = True
            for i, (wallet, tokens_bought) in enumerate(wallets, 1):
                print(f"\n{i}. {wallet}")
                print(f"   Tokens: {', '.join(sorted(tokens_bought))}")
                
                # Show launch times for context
                for token_name in sorted(tokens_bought):
                    launch_time = launch_times[token_name]
                    print(f"   {token_name}: launched {launch_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Copy-paste list for high counts
        if count >= 3:
            print(f"\n📝 COPY-PASTE LIST ({count} tokens each):")
            for wallet, _ in wallets:
                print(wallet)
    
    # Summary
    print(f"\n📊 FIRST HOUR SUMMARY:")
    print("=" * 40)
    for name, buyers in token_buyers.items():
        launch_time = launch_times[name]
        print(f"{name}: {len(buyers)} first-hour buyers (launched: {launch_time.strftime('%Y-%m-%d %H:%M:%S')})")
    
    # Decision on extending to 2 hours
    max_cross_token = max(by_count.keys()) if by_count else 0
    
    if max_cross_token < 4:
        print(f"\n💡 RECOMMENDATION:")
        print(f"Max cross-token buyers in first hour: {max_cross_token}/4")
        if max_cross_token < 2:
            print("❌ No significant cross-token patterns found in first hour")
            print("🔄 Should extend analysis to 2 hours")
        else:
            print("⚠️ Some cross-token patterns found but not complete")
            print("🔄 Consider extending to 2 hours for more comprehensive results")
        
        return False  # Indicate we should extend to 2 hours
    else:
        print(f"\n🎉 SUCCESS: Found wallet(s) that bought all 4 tokens in first hour!")
        return True  # Found complete matches

if __name__ == "__main__":
    success = analyze_first_hour_buyers()
    if not success:
        print(f"\n🔄 NEXT STEP: Extend analysis to 2 hours for better coverage")
