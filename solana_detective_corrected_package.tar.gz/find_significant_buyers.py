#!/usr/bin/env python3
"""
Find wallets that bought a token between 3:00-3:10pm EST with minimum $140 volume
"""

import requests
import json
from datetime import datetime, timezone, timedelta
import pytz
import time

def find_significant_buyers():
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    
    token_address = "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN"
    min_volume = 140  # Minimum $140 filter
    
    print(f"🔍 Finding significant buyers (>${min_volume}) for token")
    print(f"⏰ Time window: 3:00pm - 3:10pm EST")
    print(f"💰 Minimum volume: ${min_volume}")
    print("=" * 60)
    
    # Get token info and pool address
    print(f"📊 Getting token information...")
    try:
        token_url = f'https://data.solanatracker.io/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ Error: {response.text}")
            return
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            print(f"❌ No pools found")
            return
        
        # Get most active pool
        active_pools = [p for p in pools if p.get('txns', {}).get('total', 0) > 0]
        if active_pools:
            best_pool = max(active_pools, key=lambda p: p.get('txns', {}).get('total', 0))
            pool_address = best_pool.get('poolId')
        else:
            pool_address = pools[0].get('poolId')
        
        print(f"✅ Pool: {pool_address}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return
    
    # Get trades with early exit for efficiency
    print(f"📊 Collecting trades...")
    
    all_significant_trades = []
    cursor = None
    page = 1
    max_pages = 100  # Increase to find older trades
    
    try:
        while page <= max_pages:
            print(f"   Page {page}...", end=" ")
            
            trades_url = f'https://data.solanatracker.io/trades/{token_address}/{pool_address}'
            params = {}
            if cursor:
                params['cursor'] = cursor
            
            response = requests.get(trades_url, headers=headers, params=params, timeout=30)
            
            if response.status_code != 200:
                print(f"❌ Error: {response.text}")
                break
            
            trades_data = response.json()
            trades = trades_data.get('trades', [])
            
            if not trades:
                print(f"No more trades")
                break
            
            # Filter for significant BUY trades only
            page_significant = []
            for trade in trades:
                if (trade.get('type') == 'buy' and 
                    trade.get('volume', 0) >= min_volume):
                    page_significant.append(trade)
            
            all_significant_trades.extend(page_significant)
            print(f"Found {len(page_significant)} significant buys (Total: {len(all_significant_trades)})")
            
            # Check pagination
            if not trades_data.get('hasNextPage', False):
                print(f"   ✅ Reached last page")
                break
            
            cursor = trades_data.get('nextCursor')
            if not cursor:
                break
            
            page += 1
            time.sleep(0.1)  # Be nice to API
        
        print(f"\n✅ Total significant trades: {len(all_significant_trades)}")
        
    except Exception as e:
        print(f"❌ Error collecting trades: {e}")
        return
    
    if not all_significant_trades:
        print(f"❌ No trades found with volume >= ${min_volume}")
        return
    
    # Filter by time window
    print(f"\n📊 Filtering by 3:00-3:10pm EST...")
    
    est = pytz.timezone('US/Eastern')
    matching_trades = []
    
    # Check trades for 3:00-3:10pm EST window
    for trade in all_significant_trades:
        trade_time = trade.get('time')
        if not trade_time:
            continue
        
        trade_datetime = datetime.fromtimestamp(trade_time / 1000, tz=est)
        
        # Check if trade is between 3:00-3:10pm EST
        if trade_datetime.hour == 15 and 0 <= trade_datetime.minute <= 10:
            matching_trades.append({
                'wallet': trade.get('wallet'),
                'trade_time': trade_time,
                'trade_datetime': trade_datetime,
                'volume_usd': trade.get('volume', 0),
                'amount': trade.get('amount', 0),
                'price': trade.get('priceUsd', 0),
                'signature': trade.get('tx', '')
            })
    
    # Generate results
    print(f"\n" + "="*60)
    print(f"📊 RESULTS")
    print(f"="*60)
    
    if matching_trades:
        print(f"✅ Found {len(matching_trades)} significant buys (>${min_volume}) between 3:00-3:10pm EST")
        
        # Sort by volume (highest first)
        matching_trades.sort(key=lambda x: x['volume_usd'], reverse=True)
        
        total_volume = sum(t['volume_usd'] for t in matching_trades)
        print(f"💰 Total volume: ${total_volume:,.2f}")
        
        print(f"\n🎯 ALL SIGNIFICANT BUYERS:")
        print(f"-" * 60)
        
        for i, trade in enumerate(matching_trades, 1):
            wallet = trade['wallet']
            time_str = trade['trade_datetime'].strftime('%m-%d %H:%M:%S')
            volume = trade['volume_usd']
            amount = trade['amount']
            
            print(f"{i:2d}. {wallet}")
            print(f"    ⏰ {time_str} EST")
            print(f"    💰 ${volume:,.2f} | {amount:,.0f} tokens")
            print()
        
        # Get unique wallets
        unique_wallets = set(t['wallet'] for t in matching_trades)
        print(f"👥 Unique wallets: {len(unique_wallets)}")
        
        if len(unique_wallets) < len(matching_trades):
            print(f"📊 Some wallets made multiple trades")
        
        print(f"\n📋 WALLET LIST (copy-paste ready):")
        print(f"-" * 60)
        for wallet in sorted(unique_wallets):
            print(wallet)
        
    else:
        print(f"❌ No significant buys (>${min_volume}) found between 3:00-3:10pm EST")
        
        # Show when significant trades actually happened
        if all_significant_trades:
            print(f"\n💡 But found {len(all_significant_trades)} significant trades at other times:")
            
            # Show time distribution
            time_counts = {}
            for trade in all_significant_trades[:20]:  # Show first 20
                trade_time = trade.get('time')
                if trade_time:
                    dt = datetime.fromtimestamp(trade_time / 1000, tz=est)
                    time_key = dt.strftime('%m-%d %H:%M')
                    time_counts[time_key] = time_counts.get(time_key, 0) + 1
            
            print(f"📊 Sample times with significant trades:")
            for time_key, count in sorted(time_counts.items())[:10]:
                print(f"   {time_key} EST: {count} trades")

if __name__ == "__main__":
    find_significant_buyers()

