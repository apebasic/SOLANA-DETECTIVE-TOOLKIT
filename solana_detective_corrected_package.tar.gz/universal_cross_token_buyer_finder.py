#!/usr/bin/env python3
"""
Universal Cross-Token Buyer Finder
Works with ANY number of token addresses - 2, 3, 5, 10, whatever you need
Finds wallets that bought ALL provided tokens
"""

import requests
import json
import sys
from collections import defaultdict
import time

def get_all_buyers_for_token(token_address, api_key, max_pages=50):
    """Get ALL buyers for a token using comprehensive approach"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    print(f"   🔍 Getting buyers for {token_address[:8]}...")
    
    try:
        # Get token info to find pools
        token_url = f'{base_url}/tokens/{token_address}'
        response = requests.get(token_url, headers=headers, timeout=30)
        
        if response.status_code != 200:
            print(f"   ❌ Error getting token info")
            return set()
        
        token_data = response.json()
        pools = token_data.get('pools', [])
        
        if not pools:
            print(f"   ❌ No pools found")
            return set()
        
        print(f"   ✅ Found {len(pools)} pools")
        
        # Get buyers from all pools
        all_buyers = set()
        
        for pool_idx, pool in enumerate(pools, 1):
            pool_id = pool.get('poolId')
            if not pool_id:
                continue
                
            print(f"   📊 Pool {pool_idx}/{len(pools)}: {pool_id[:8]}...")
            
            # Get trades from this pool
            trades_url = f'{base_url}/trades/{token_address}/{pool_id}'
            
            page = 1
            while page <= max_pages:
                try:
                    params = {'page': page, 'limit': 100}
                    response = requests.get(trades_url, headers=headers, params=params, timeout=30)
                    
                    if response.status_code != 200:
                        break
                    
                    trades_data = response.json()
                    trades = trades_data.get('trades', [])
                    
                    if not trades:
                        break
                    
                    # Extract buyer wallets from buy trades
                    page_buyers = 0
                    for trade in trades:
                        if trade.get('type') == 'buy':
                            wallet = trade.get('wallet')
                            if wallet:
                                all_buyers.add(wallet)
                                page_buyers += 1
                    
                    if page % 10 == 0:  # Show progress every 10 pages
                        print(f"      📄 Page {page}: {len(all_buyers)} total buyers")
                    
                    page += 1
                    time.sleep(1.1)  # Rate limiting
                    
                except Exception as e:
                    break
        
        print(f"   ✅ Total unique buyers: {len(all_buyers)}")
        return all_buyers
        
    except Exception as e:
        print(f"   ❌ Exception: {e}")
        return set()

def find_wallets_bought_all_tokens(token_addresses, api_key="d69a0997-86cb-4a69-8f0b-c3435a11b45b"):
    """
    Universal function: Find wallets that bought ALL provided tokens
    Works with any number of token addresses
    """
    
    if not token_addresses:
        print("❌ No token addresses provided")
        return []
    
    num_tokens = len(token_addresses)
    
    print(f"🔍 UNIVERSAL CROSS-TOKEN BUYER FINDER")
    print("=" * 60)
    print(f"🎯 Finding wallets that bought ALL {num_tokens} tokens")
    print("🏗️ Universal architecture - works with any number of tokens")
    print("=" * 60)
    
    # Step 1: Get ALL buyers for each token
    token_buyers = {}
    
    for i, token in enumerate(token_addresses, 1):
        print(f"\n📊 {i}/{num_tokens} Processing token:")
        print(f"   {token}")
        
        buyers = get_all_buyers_for_token(token, api_key)
        token_buyers[token] = buyers
        
        if len(buyers) == 0:
            print(f"   ⚠️ No buyers found for this token")
    
    # Step 2: Find intersection - wallets that bought ALL tokens
    print(f"\n🎯 CROSS-TOKEN INTERSECTION ANALYSIS:")
    print("=" * 50)
    
    if not token_buyers:
        print("❌ No data collected")
        return []
    
    # Start with buyers from first token
    first_token = token_addresses[0]
    common_wallets = token_buyers[first_token].copy()
    
    print(f"Starting with {len(common_wallets)} buyers from first token")
    
    # Find intersection with all other tokens
    for i, token in enumerate(token_addresses[1:], 2):
        if token in token_buyers:
            token_buyers_set = token_buyers[token]
            common_wallets = common_wallets.intersection(token_buyers_set)
            print(f"After token {i}: {len(common_wallets)} wallets remain")
            
            if len(common_wallets) == 0:
                print("❌ No common wallets found")
                break
    
    # Step 3: Results
    print(f"\n🎯 FINAL RESULTS:")
    print("=" * 50)
    
    if common_wallets:
        print(f"✅ Found {len(common_wallets)} wallet(s) that bought ALL {num_tokens} tokens:")
        print()
        
        wallet_list = sorted(common_wallets)
        for i, wallet in enumerate(wallet_list, 1):
            print(f"{i}. {wallet}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for wallet in wallet_list:
            print(wallet)
            
        return wallet_list
            
    else:
        print(f"❌ No wallets bought ALL {num_tokens} tokens")
        
        # Show statistics for debugging
        print(f"\n📊 BUYER STATISTICS:")
        for i, token in enumerate(token_addresses, 1):
            if token in token_buyers:
                buyers_count = len(token_buyers[token])
                print(f"   Token {i}: {buyers_count} total buyers")
            
        # Show pairwise intersections for debugging
        if num_tokens <= 5:  # Only show for reasonable numbers
            print(f"\n🔍 PAIRWISE INTERSECTIONS:")
            for i in range(len(token_addresses)):
                for j in range(i+1, len(token_addresses)):
                    token1, token2 = token_addresses[i], token_addresses[j]
                    if token1 in token_buyers and token2 in token_buyers:
                        intersection = token_buyers[token1].intersection(token_buyers[token2])
                        print(f"   Tokens {i+1} & {j+1}: {len(intersection)} common wallets")
        
        return []

def main():
    """Main function - can be called with command line arguments or interactively"""
    
    if len(sys.argv) > 1:
        # Command line usage
        token_addresses = sys.argv[1:]
        print(f"📥 Using {len(token_addresses)} token addresses from command line")
    else:
        # Interactive usage - example with the 3 tokens you requested
        token_addresses = [
            "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
            "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
            "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk"
        ]
        print(f"📥 Using 3 example token addresses")
    
    # Find wallets that bought all tokens
    result_wallets = find_wallets_bought_all_tokens(token_addresses)
    
    if result_wallets:
        print(f"\n🎉 SUCCESS: Found {len(result_wallets)} wallets!")
    else:
        print(f"\n💡 TIP: Try with fewer tokens or check if the tokens are correct")

if __name__ == "__main__":
    main()
