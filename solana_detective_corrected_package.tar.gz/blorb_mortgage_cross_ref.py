#!/usr/bin/env python3
"""
BLORB-Mortgage Cross Reference
Cross-reference BLORB sellers with Mortgage candidates
"""

import pandas as pd
import json
from datetime import datetime, timezone

def parse_csv_timestamp(timestamp_str: str) -> int:
    """Parse CSV timestamp string to Unix timestamp"""
    dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
    return int(dt.timestamp() * 1000)

def utc_to_unix_timestamp(year: int, month: int, day: int, 
                         hour: int, minute: int, second: int = 0) -> int:
    """Convert UTC time to Unix timestamp"""
    dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)

def determine_transaction_type(row: pd.Series, token_address: str) -> str:
    """Determine if transaction is buy or sell based on token flow"""
    token1 = row['Token1']
    token2 = row['Token2']
    sol_address = "So11111111111111111111111111111111111111112"
    
    if token1 == token_address and token2 == sol_address:
        return 'sell'  # Token -> SOL = SELL
    elif token1 == sol_address and token2 == token_address:
        return 'buy'   # SOL -> Token = BUY
    elif token1 == token_address or token2 == token_address:
        if token1 == token_address:
            return 'sell'  # User is giving away the token
        else:
            return 'buy'   # User is receiving the token
    
    return 'unknown'

def main():
    print("🔄 BLORB-MORTGAGE CROSS-REFERENCE")
    print("=" * 50)
    
    # Load Mortgage results
    try:
        with open('/home/ubuntu/csv_analysis_results.json', 'r') as f:
            results = json.load(f)
            mortgage_wallets = set(results['mortgage']['intersection_wallets'])
            print(f"📊 Loaded {len(mortgage_wallets)} Mortgage candidate wallets")
    except:
        print("❌ Could not load Mortgage results")
        return
    
    # Analyze BLORB sellers
    print("\n🎯 ANALYZING BLORB SELLERS")
    
    csv_path = "/home/ubuntu/upload/export_defi_activities_CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump_1751060100603.csv"
    df = pd.read_csv(csv_path)
    
    blorb_token = "CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump"
    
    # Parse timestamps
    df['timestamp_unix'] = df['Human Time'].apply(parse_csv_timestamp)
    
    # Sell timeframe: June 26, 21:07-21:09 UTC
    sell_start = utc_to_unix_timestamp(2025, 6, 26, 21, 7, 0)
    sell_end = utc_to_unix_timestamp(2025, 6, 26, 21, 9, 0)
    
    # Filter by sell timeframe
    sell_df = df[(df['timestamp_unix'] >= sell_start) & (df['timestamp_unix'] <= sell_end)]
    print(f"📊 Transactions in sell timeframe: {len(sell_df)}")
    
    # Determine transaction types and get sellers
    sell_df = sell_df.copy()
    sell_df['transaction_type'] = sell_df.apply(
        lambda row: determine_transaction_type(row, blorb_token), axis=1
    )
    
    # Get unique sellers
    blorb_sellers = set()
    sell_transactions = []
    
    for _, row in sell_df.iterrows():
        if row['transaction_type'] == 'sell':
            blorb_sellers.add(row['From'])
            sell_transactions.append(row.to_dict())
    
    print(f"💰 Unique BLORB sellers in timeframe: {len(blorb_sellers)}")
    
    # Cross-reference with Mortgage wallets
    print(f"\n🎯 CROSS-REFERENCING")
    intersection = mortgage_wallets & blorb_sellers
    
    print(f"🔍 Mortgage wallets: {len(mortgage_wallets)}")
    print(f"🔍 BLORB sellers: {len(blorb_sellers)}")
    print(f"🎯 INTERSECTION: {len(intersection)}")
    
    if intersection:
        print(f"\n🎉 FOUND {len(intersection)} WALLET(S) THAT TRADED BOTH TOKENS!")
        
        for i, wallet in enumerate(intersection, 1):
            print(f"\n{i}. 🌟 CANDIDATE WALLET: {wallet}")
            
            # Show BLORB sell transactions for this wallet
            wallet_sells = [tx for tx in sell_transactions if tx['From'] == wallet]
            print(f"   📊 BLORB sells in timeframe: {len(wallet_sells)}")
            
            for sell in wallet_sells:
                print(f"   💰 SELL: {sell['Human Time']} | Value: ${sell['Value']} | Action: {sell['Action']}")
            
            print(f"   ✅ This wallet also bought AND sold Mortgage on June 25, 19:30-19:45 UTC")
            
            # Check if this wallet is the bot we identified earlier
            if wallet == "HuTshmtwcQkWBLzgW3m4uwcmik7Lmz4YFpYcTqMJpXiP":
                print(f"   ⚠️  WARNING: This is the bot wallet we identified earlier")
        
        # Save results
        final_results = {
            'mortgage_candidates': list(mortgage_wallets),
            'blorb_sellers': list(blorb_sellers),
            'mortgage_blorb_intersection': list(intersection),
            'analysis_summary': {
                'mortgage_wallets_count': len(mortgage_wallets),
                'blorb_sellers_count': len(blorb_sellers),
                'intersection_count': len(intersection)
            }
        }
        
        with open('/home/ubuntu/mortgage_blorb_cross_reference.json', 'w') as f:
            json.dump(final_results, f, indent=2)
        
        print(f"\n📄 Results saved to mortgage_blorb_cross_reference.json")
        
    else:
        print(f"\n❌ No wallets found that traded both Mortgage and BLORB in the specified timeframes")
        
        # Show some sample wallets from each group for debugging
        print(f"\n🔍 SAMPLE MORTGAGE WALLETS:")
        for wallet in list(mortgage_wallets)[:5]:
            print(f"   - {wallet}")
        
        print(f"\n🔍 SAMPLE BLORB SELLERS:")
        for wallet in list(blorb_sellers)[:5]:
            print(f"   - {wallet}")

if __name__ == "__main__":
    main()

