#!/usr/bin/env python3
"""
Three Token Intersection Analysis
Find all wallets that have interacted with Mortgage, 神经蛙, and BLORB tokens
"""

import pandas as pd
import json

def main():
    print("🔍 THREE TOKEN INTERSECTION ANALYSIS")
    print("=" * 60)
    
    # Token information
    tokens = {
        'Mortgage': {
            'address': 'FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN',
            'csv_path': '/home/ubuntu/upload/export_defi_activities_FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN_1751061823537.csv'
        },
        '神经蛙': {
            'address': '4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk',
            'csv_path': '/home/ubuntu/upload/export_defi_activities_4QvVzhTaAQDH51TRBEL6eX3f3Wvte9g6jRK2iSPebonk_1751061865153.csv'
        },
        'BLORB': {
            'address': 'CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump',
            'csv_path': '/home/ubuntu/upload/export_defi_activities_CWDriFBrqoCu4vjtRJBgrhuDJ2nJyaLFmpuvUNvqpump_1751061700105.csv'
        }
    }
    
    # Dictionary to store wallets for each token
    token_wallets = {}
    
    # Process each token CSV
    for token_name, token_info in tokens.items():
        print(f"\n📊 ANALYZING {token_name} TOKEN")
        print(f"   Address: {token_info['address']}")
        
        try:
            # Read CSV
            df = pd.read_csv(token_info['csv_path'])
            print(f"   Total transactions: {len(df)}")
            
            # Get all unique wallets from 'From' column
            unique_wallets = set(df['From'].dropna().unique())
            token_wallets[token_name] = unique_wallets
            
            print(f"   Unique wallets: {len(unique_wallets)}")
            
            # Show some sample wallets
            sample_wallets = list(unique_wallets)[:3]
            for wallet in sample_wallets:
                print(f"     - {wallet}")
            
        except Exception as e:
            print(f"   ❌ Error reading CSV: {e}")
            token_wallets[token_name] = set()
    
    # Find intersections
    print(f"\n🎯 INTERSECTION ANALYSIS")
    print("=" * 60)
    
    if len(token_wallets) == 3:
        mortgage_wallets = token_wallets['Mortgage']
        neural_frog_wallets = token_wallets['神经蛙']
        blorb_wallets = token_wallets['BLORB']
        
        print(f"📊 WALLET COUNTS:")
        print(f"   Mortgage: {len(mortgage_wallets)} wallets")
        print(f"   神经蛙: {len(neural_frog_wallets)} wallets")
        print(f"   BLORB: {len(blorb_wallets)} wallets")
        
        # Two-way intersections
        mortgage_neural = mortgage_wallets & neural_frog_wallets
        mortgage_blorb = mortgage_wallets & blorb_wallets
        neural_blorb = neural_frog_wallets & blorb_wallets
        
        print(f"\n🔗 TWO-WAY INTERSECTIONS:")
        print(f"   Mortgage ∩ 神经蛙: {len(mortgage_neural)} wallets")
        print(f"   Mortgage ∩ BLORB: {len(mortgage_blorb)} wallets")
        print(f"   神经蛙 ∩ BLORB: {len(neural_blorb)} wallets")
        
        # Three-way intersection
        three_way_intersection = mortgage_wallets & neural_frog_wallets & blorb_wallets
        
        print(f"\n🎯 THREE-WAY INTERSECTION:")
        print(f"   Mortgage ∩ 神经蛙 ∩ BLORB: {len(three_way_intersection)} wallets")
        
        if three_way_intersection:
            print(f"\n🎉 FOUND {len(three_way_intersection)} WALLET(S) THAT INTERACTED WITH ALL THREE TOKENS!")
            
            for i, wallet in enumerate(three_way_intersection, 1):
                print(f"\n{i}. 🌟 CANDIDATE WALLET: {wallet}")
                
                # Count transactions for each token
                for token_name, token_info in tokens.items():
                    try:
                        df = pd.read_csv(token_info['csv_path'])
                        wallet_transactions = df[df['From'] == wallet]
                        transaction_count = len(wallet_transactions)
                        
                        print(f"   📊 {token_name}: {transaction_count} transactions")
                        
                        # Show date range of transactions
                        if transaction_count > 0:
                            earliest = wallet_transactions['Human Time'].min()
                            latest = wallet_transactions['Human Time'].max()
                            print(f"      📅 From {earliest} to {latest}")
                            
                            # Show sample transaction values
                            sample_values = wallet_transactions['Value'].head(3).tolist()
                            print(f"      💰 Sample values: {sample_values}")
                    
                    except Exception as e:
                        print(f"   ❌ Error analyzing {token_name}: {e}")
            
            # Save results
            results = {
                'analysis_summary': {
                    'mortgage_wallets_count': len(mortgage_wallets),
                    'neural_frog_wallets_count': len(neural_frog_wallets),
                    'blorb_wallets_count': len(blorb_wallets),
                    'three_way_intersection_count': len(three_way_intersection)
                },
                'two_way_intersections': {
                    'mortgage_neural_frog': list(mortgage_neural),
                    'mortgage_blorb': list(mortgage_blorb),
                    'neural_frog_blorb': list(neural_blorb)
                },
                'three_way_intersection': list(three_way_intersection),
                'token_addresses': {
                    'Mortgage': tokens['Mortgage']['address'],
                    '神经蛙': tokens['神经蛙']['address'],
                    'BLORB': tokens['BLORB']['address']
                }
            }
            
            with open('/home/ubuntu/three_token_intersection_results.json', 'w') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            print(f"\n📄 Results saved to three_token_intersection_results.json")
            
        else:
            print(f"\n❌ No wallets found that interacted with all three tokens")
            
            # Show some wallets from two-way intersections for reference
            if mortgage_neural:
                print(f"\n🔍 SAMPLE MORTGAGE ∩ 神经蛙 WALLETS:")
                for wallet in list(mortgage_neural)[:5]:
                    print(f"   - {wallet}")
            
            if mortgage_blorb:
                print(f"\n🔍 SAMPLE MORTGAGE ∩ BLORB WALLETS:")
                for wallet in list(mortgage_blorb)[:5]:
                    print(f"   - {wallet}")
            
            if neural_blorb:
                print(f"\n🔍 SAMPLE 神经蛙 ∩ BLORB WALLETS:")
                for wallet in list(neural_blorb)[:5]:
                    print(f"   - {wallet}")
    
    else:
        print("❌ Could not load all three token datasets")

if __name__ == "__main__":
    main()

