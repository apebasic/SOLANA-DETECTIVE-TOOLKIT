#!/usr/bin/env python3
"""
Optimized LINGANG Buyer Finder
Uses block number conversion as prerequisite for efficient querying
"""

from solana_time_utils import convert_est_timeframe_to_optimized_query, get_buyers_in_timeframe
from datetime import datetime
import pytz

def find_lingang_buyers_optimized():
    """
    Find LINGANG buyers using optimized block-based querying
    This demonstrates the new PREREQUISITE approach for all time-based queries
    """
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    
    print(f"🔍 Finding $LINGANG buyers (OPTIMIZED WITH BLOCK CONVERSION)")
    print(f"📍 Token: {token_address}")
    print(f"⏰ Time window: 11:56:20am - 12:02:20pm EST (June 26, 2025)")
    print("=" * 80)
    
    # PREREQUISITE: Convert EST timeframe to optimized query parameters
    print("🔧 STEP 1: Converting timeframe to optimized query parameters...")
    
    query_params = convert_est_timeframe_to_optimized_query(
        year=2025, month=6, day=26,
        start_hour=11, start_min=56, start_sec=20,
        end_hour=12, end_min=2, end_sec=20,
        api_key=api_key
    )
    
    start_timestamp = query_params['start_timestamp']
    end_timestamp = query_params['end_timestamp']
    
    # Display conversion results
    est = pytz.timezone('US/Eastern')
    start_est = datetime.fromtimestamp(start_timestamp, tz=est)
    end_est = datetime.fromtimestamp(end_timestamp, tz=est)
    
    print(f"✅ Timeframe converted:")
    print(f"   Start: {start_est} EST = {start_timestamp} UTC")
    print(f"   End: {end_est} EST = {end_timestamp} UTC")
    print()
    
    # STEP 2: Use optimized buyer finder
    print("⚡ STEP 2: Getting buyers using block-optimized querying...")
    
    buyers = get_buyers_in_timeframe(
        token_address=token_address,
        start_timestamp=start_timestamp,
        end_timestamp=end_timestamp,
        api_key=api_key,
        min_volume=0  # No minimum volume filter
    )
    
    # STEP 3: Display results
    print(f"\n🎯 RESULTS:")
    print(f"✅ Found {len(buyers)} unique buyers in the timeframe")
    
    if buyers:
        print(f"\n📋 WALLET ADDRESSES:")
        for i, buyer in enumerate(buyers, 1):
            trade_time = datetime.fromtimestamp(buyer['time'], tz=est)
            print(f"\n{i}. {buyer['wallet']}")
            print(f"   Time: {trade_time.strftime('%H:%M:%S')} EST")
            print(f"   Volume: ${buyer['volume']:.2f}")
        
        print(f"\n📝 COPY-PASTE LIST:")
        for buyer in buyers:
            print(buyer['wallet'])
    else:
        print("❌ No buyers found in the specified timeframe")
        print("\n🔍 DEBUGGING INFO:")
        print("This could mean:")
        print("1. No trading activity during that exact timeframe")
        print("2. All trades were sells (negative volume)")
        print("3. Timeframe conversion issue")
        
        # Let's check if there's ANY activity around that time
        print(f"\n🔍 Checking broader timeframe for debugging...")
        broader_start = start_timestamp - 300  # 5 minutes before
        broader_end = end_timestamp + 300      # 5 minutes after
        
        broader_buyers = get_buyers_in_timeframe(
            token_address=token_address,
            start_timestamp=broader_start,
            end_timestamp=broader_end,
            api_key=api_key,
            min_volume=0
        )
        
        print(f"📊 Found {len(broader_buyers)} buyers in broader timeframe (±5 minutes)")
        if broader_buyers:
            print("✅ Token has trading activity - timeframe might be too specific")
            print("Recent activity around your timeframe:")
            for buyer in broader_buyers[:3]:  # Show first 3
                trade_time = datetime.fromtimestamp(buyer['time'], tz=est)
                print(f"   {buyer['wallet'][:8]}... at {trade_time.strftime('%H:%M:%S')} EST")

if __name__ == "__main__":
    find_lingang_buyers_optimized()

