#!/usr/bin/env python3
"""
Calculate SOL spent by specific wallet buying specific token
"""

import requests
import json

def main():
    # Configuration
    wallet_address = "CGU2AJLzf28QzRq3Lz4F3sGSZhKCxPnRHe6fG9MoXzfZ"
    token_address = "7DKFa79o6QfbGGEtBZ5ZYBJw1qLJWyNuVoMD5rxbpump"
    
    # Load API key
    with open('/home/ubuntu/config.json', 'r') as f:
        config = json.load(f)
        api_key = config['api_key']
    
    print(f"🔍 ANALYZING WALLET SPENDING")
    print("=" * 60)
    print(f"📊 Wallet: {wallet_address}")
    print(f"🎯 Token: {token_address}")
    
    # Get trades for this wallet and token
    url = f"https://data.solanatracker.io/trades/{token_address}/by-wallet/{wallet_address}"
    headers = {"x-api-key": api_key}
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            
            if 'trades' in data and data['trades']:
                trades = data['trades']
                print(f"📊 Total trades found: {len(trades)}")
                
                # Filter for buy transactions and calculate total SOL spent
                buy_trades = [trade for trade in trades if trade.get('type') == 'buy']
                total_sol_spent = sum([float(trade.get('volume', 0)) for trade in buy_trades])
                
                print(f"🛒 Buy transactions: {len(buy_trades)}")
                print(f"💰 Total SOL spent on buys: {total_sol_spent:.6f} SOL")
                
                if buy_trades:
                    print(f"\n📋 BUY TRANSACTION DETAILS:")
                    for i, trade in enumerate(buy_trades, 1):
                        from datetime import datetime
                        timestamp = trade.get('time', 0)
                        date_str = datetime.fromtimestamp(timestamp/1000).strftime('%Y-%m-%d %H:%M:%S UTC') if timestamp else "Unknown"
                        
                        print(f"   {i}. 📅 {date_str}")
                        print(f"      💰 SOL spent: {trade.get('volume', 0)} SOL")
                        print(f"      🎯 Token amount: {trade.get('amount', 0)}")
                        print(f"      💵 USD value: ${trade.get('priceUsd', 0)}")
                        print()
                
                # Also show sell transactions for context
                sell_trades = [trade for trade in trades if trade.get('type') == 'sell']
                if sell_trades:
                    total_sol_received = sum([float(trade.get('volume', 0)) for trade in sell_trades])
                    print(f"💸 Sell transactions: {len(sell_trades)}")
                    print(f"💰 Total SOL received from sells: {total_sol_received:.6f} SOL")
                    print(f"📊 Net SOL: {total_sol_spent - total_sol_received:.6f} SOL")
                
            else:
                print("❌ No trades found for this wallet and token combination")
                
        else:
            print(f"❌ API Error {response.status_code}: {response.text}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()

