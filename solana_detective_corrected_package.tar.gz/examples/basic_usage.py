#!/usr/bin/env python3
"""
Basic Usage Examples for Solana Detective Package
Demonstrates common use cases and functionality
"""

import sys
import os
from datetime import datetime, timedelta

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solana_detective import SolanaDetective
from solana_detective.exceptions import APIError, ValidationError

def main():
    """Main example function"""
    print("🔍 SOLANA DETECTIVE - BASIC USAGE EXAMPLES")
    print("=" * 60)
    
    # Initialize client (you need to provide your API key)
    api_key = os.getenv("SOLANA_TRACKER_API_KEY")
    if not api_key:
        print("❌ Please set SOLANA_TRACKER_API_KEY environment variable")
        print("   export SOLANA_TRACKER_API_KEY='your_api_key_here'")
        return
    
    try:
        detective = SolanaDetective(api_key=api_key)
        print("✅ Solana Detective client initialized successfully")
        
        # Example 1: Get token information
        print("\n📊 EXAMPLE 1: Get Token Information")
        print("-" * 40)
        
        # Using SOL token as example
        sol_token = "So11111111111111111111111111111111111111112"
        token_info = detective.get_token_info(sol_token)
        
        print(f"Token Name: {token_info['token']['name']}")
        print(f"Symbol: {token_info['token']['symbol']}")
        print(f"Decimals: {token_info['token']['decimals']}")
        print(f"Number of pools: {len(token_info['pools'])}")
        
        # Example 2: Get current token price
        print("\n💰 EXAMPLE 2: Get Token Price")
        print("-" * 40)
        
        price_info = detective.get_token_price(sol_token, price_changes=True)
        print(f"Current price: ${price_info.get('price', 'N/A')}")
        if 'priceChanges' in price_info:
            print(f"24h change: {price_info['priceChanges'].get('24h', 'N/A')}%")
        
        # Example 3: Search for tokens
        print("\n🔍 EXAMPLE 3: Search Tokens")
        print("-" * 40)
        
        search_results = detective.search_tokens("USDC", limit=5)
        print(f"Found {len(search_results.get('tokens', []))} tokens matching 'USDC'")
        
        for token in search_results.get('tokens', [])[:3]:
            print(f"- {token.get('name', 'Unknown')} ({token.get('symbol', 'N/A')})")
        
        # Example 4: Get wallet information
        print("\n👛 EXAMPLE 4: Get Wallet Information")
        print("-" * 40)
        
        # Example wallet (replace with actual wallet address)
        example_wallet = "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D"
        
        try:
            wallet_info = detective.get_wallet_basic(example_wallet)
            print(f"Wallet analyzed successfully")
            print(f"Total tokens: {len(wallet_info.get('tokens', []))}")
        except APIError as e:
            print(f"Wallet analysis failed: {e}")
        
        # Example 5: Get chart data
        print("\n📈 EXAMPLE 5: Get Chart Data")
        print("-" * 40)
        
        chart_data = detective.get_chart_data(
            token=sol_token,
            interval="1h",
            market_cap=False,
            remove_outliers=True
        )
        
        ohlcv_data = chart_data.get('oclhv', [])
        print(f"Retrieved {len(ohlcv_data)} data points")
        
        if ohlcv_data:
            latest = ohlcv_data[-1]
            print(f"Latest OHLCV:")
            print(f"  Open: {latest.get('open', 'N/A')}")
            print(f"  High: {latest.get('high', 'N/A')}")
            print(f"  Low: {latest.get('low', 'N/A')}")
            print(f"  Close: {latest.get('close', 'N/A')}")
            print(f"  Volume: {latest.get('volume', 'N/A')}")
        
        # Example 6: Get top holders
        print("\n🏆 EXAMPLE 6: Get Top Token Holders")
        print("-" * 40)
        
        top_holders = detective.get_token_holders_top(sol_token)
        
        print(f"Top {len(top_holders)} holders:")
        for i, holder in enumerate(top_holders[:5], 1):
            address = holder.get('address', 'Unknown')
            percentage = holder.get('percentage', 0)
            print(f"{i}. {address[:8]}...{address[-8:]} ({percentage:.2f}%)")
        
        # Example 7: Health check
        print("\n🏥 EXAMPLE 7: Health Check")
        print("-" * 40)
        
        health = detective.health_check()
        print(f"API Status: {health['status']}")
        print(f"Credits remaining: {health.get('credits_remaining', 'Unknown')}")
        
        # Example 8: List available endpoints
        print("\n📋 EXAMPLE 8: Available Endpoints")
        print("-" * 40)
        
        endpoints = detective.get_available_endpoints()
        print(f"Total available endpoints: {len(endpoints)}")
        print("Sample endpoints:")
        for endpoint in endpoints[:10]:
            print(f"- {endpoint}")
        
        print("\n✅ All examples completed successfully!")
        
    except ValidationError as e:
        print(f"❌ Validation Error: {e}")
    except APIError as e:
        print(f"❌ API Error: {e}")
    except Exception as e:
        print(f"❌ Unexpected Error: {e}")

if __name__ == "__main__":
    main()

