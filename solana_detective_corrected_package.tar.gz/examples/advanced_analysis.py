#!/usr/bin/env python3
"""
Advanced Analysis Examples for Solana Detective Package
Demonstrates complex analysis scenarios combining multiple endpoints
"""

import sys
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solana_detective import SolanaDetective
from solana_detective.exceptions import APIError, ValidationError

class SolanaAnalyzer:
    """Advanced Solana analysis using multiple API endpoints"""
    
    def __init__(self, api_key: str):
        self.detective = SolanaDetective(api_key=api_key)
    
    def analyze_wallet_net_sol_on_token(self, wallet: str, token: str) -> Dict[str, Any]:
        """
        Calculate net SOL spent/gained by a wallet on a specific token
        
        Args:
            wallet: Wallet address
            token: Token address
            
        Returns:
            Analysis results with buy/sell volumes and net position
        """
        print(f"🔍 Analyzing wallet {wallet[:8]}...{wallet[-8:]} on token {token[:8]}...{token[-8:]}")
        
        try:
            # Get wallet trades for the specific token
            trades = self.detective.get_token_wallet_trades(token, wallet)
            
            buy_volume = 0
            sell_volume = 0
            buy_count = 0
            sell_count = 0
            
            for trade in trades.get('trades', []):
                volume_sol = trade.get('volumeSol', 0)
                trade_type = trade.get('type', '').lower()
                
                if trade_type == 'buy':
                    buy_volume += volume_sol
                    buy_count += 1
                elif trade_type == 'sell':
                    sell_volume += volume_sol
                    sell_count += 1
            
            net_sol = sell_volume - buy_volume  # Positive = profit, Negative = loss
            
            return {
                "wallet": wallet,
                "token": token,
                "buy_volume_sol": buy_volume,
                "sell_volume_sol": sell_volume,
                "net_sol": net_sol,
                "buy_count": buy_count,
                "sell_count": sell_count,
                "total_trades": buy_count + sell_count,
                "is_profitable": net_sol > 0
            }
            
        except APIError as e:
            return {"error": str(e), "wallet": wallet, "token": token}
    
    def find_profitable_wallets(self, token: str, min_trades: int = 5) -> List[Dict[str, Any]]:
        """
        Find wallets that are profitable on a specific token
        
        Args:
            token: Token address
            min_trades: Minimum number of trades to consider
            
        Returns:
            List of profitable wallets with their performance
        """
        print(f"🏆 Finding profitable wallets for token {token[:8]}...{token[-8:]}")
        
        try:
            # Get top traders for the token
            top_traders = self.detective.get_top_traders_token(token)
            
            profitable_wallets = []
            
            for trader in top_traders.get('traders', [])[:20]:  # Analyze top 20
                wallet = trader.get('wallet')
                if not wallet:
                    continue
                
                analysis = self.analyze_wallet_net_sol_on_token(wallet, token)
                
                if (analysis.get('total_trades', 0) >= min_trades and 
                    analysis.get('is_profitable', False)):
                    profitable_wallets.append(analysis)
                
                # Add small delay to respect rate limits
                time.sleep(0.1)
            
            # Sort by net SOL (most profitable first)
            profitable_wallets.sort(key=lambda x: x.get('net_sol', 0), reverse=True)
            
            return profitable_wallets
            
        except APIError as e:
            return [{"error": str(e)}]
    
    def analyze_token_volume_velocity(self, token: str, hours: int = 24) -> Dict[str, Any]:
        """
        Analyze volume velocity (rate of change) for a token
        
        Args:
            token: Token address
            hours: Number of hours to analyze
            
        Returns:
            Volume velocity analysis
        """
        print(f"📊 Analyzing volume velocity for token {token[:8]}...{token[-8:]} over {hours} hours")
        
        try:
            # Get hourly chart data
            end_time = int(time.time())
            start_time = end_time - (hours * 3600)
            
            chart_data = self.detective.get_chart_data(
                token=token,
                interval="1h",
                time_from=start_time,
                time_to=end_time
            )
            
            ohlcv_data = chart_data.get('oclhv', [])
            
            if len(ohlcv_data) < 2:
                return {"error": "Insufficient data for velocity analysis"}
            
            # Calculate volume changes
            volumes = [point.get('volume', 0) for point in ohlcv_data]
            volume_changes = []
            
            for i in range(1, len(volumes)):
                if volumes[i-1] > 0:
                    change = ((volumes[i] - volumes[i-1]) / volumes[i-1]) * 100
                    volume_changes.append(change)
            
            # Calculate statistics
            avg_volume = sum(volumes) / len(volumes)
            max_volume = max(volumes)
            min_volume = min(volumes)
            
            if volume_changes:
                avg_velocity = sum(volume_changes) / len(volume_changes)
                max_velocity = max(volume_changes)
                min_velocity = min(volume_changes)
            else:
                avg_velocity = max_velocity = min_velocity = 0
            
            return {
                "token": token,
                "analysis_hours": hours,
                "data_points": len(ohlcv_data),
                "average_volume": avg_volume,
                "max_volume": max_volume,
                "min_volume": min_volume,
                "average_velocity_percent": avg_velocity,
                "max_velocity_percent": max_velocity,
                "min_velocity_percent": min_velocity,
                "volume_volatility": max_volume - min_volume if max_volume > 0 else 0
            }
            
        except APIError as e:
            return {"error": str(e), "token": token}
    
    def detect_potential_bots(self, token: str, trade_threshold: int = 50) -> List[Dict[str, Any]]:
        """
        Detect potential bot wallets based on trading patterns
        
        Args:
            token: Token address
            trade_threshold: Minimum trades to consider for bot detection
            
        Returns:
            List of potential bot wallets with analysis
        """
        print(f"🤖 Detecting potential bots for token {token[:8]}...{token[-8:]}")
        
        try:
            # Get top traders
            top_traders = self.detective.get_top_traders_token(token)
            
            potential_bots = []
            
            for trader in top_traders.get('traders', [])[:30]:  # Analyze top 30
                wallet = trader.get('wallet')
                if not wallet:
                    continue
                
                # Get wallet trades
                trades_data = self.detective.get_token_wallet_trades(token, wallet)
                trades = trades_data.get('trades', [])
                
                if len(trades) < trade_threshold:
                    continue
                
                # Analyze trading patterns for bot-like behavior
                trade_times = [trade.get('time', 0) for trade in trades]
                trade_amounts = [trade.get('volumeSol', 0) for trade in trades]
                
                # Calculate pattern indicators
                time_intervals = []
                for i in range(1, len(trade_times)):
                    interval = trade_times[i] - trade_times[i-1]
                    time_intervals.append(interval)
                
                # Bot indicators
                avg_interval = sum(time_intervals) / len(time_intervals) if time_intervals else 0
                interval_variance = self._calculate_variance(time_intervals)
                amount_variance = self._calculate_variance(trade_amounts)
                
                # Simple bot detection heuristics
                is_potential_bot = (
                    len(trades) > trade_threshold and
                    interval_variance < avg_interval * 0.1 and  # Very regular timing
                    amount_variance < sum(trade_amounts) / len(trade_amounts) * 0.1  # Very similar amounts
                )
                
                if is_potential_bot:
                    potential_bots.append({
                        "wallet": wallet,
                        "trade_count": len(trades),
                        "avg_interval_seconds": avg_interval,
                        "interval_variance": interval_variance,
                        "amount_variance": amount_variance,
                        "bot_confidence": "HIGH" if interval_variance < avg_interval * 0.05 else "MEDIUM"
                    })
                
                # Add delay to respect rate limits
                time.sleep(0.1)
            
            return potential_bots
            
        except APIError as e:
            return [{"error": str(e)}]
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of a list of values"""
        if not values:
            return 0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance

def main():
    """Main advanced analysis examples"""
    print("🚀 SOLANA DETECTIVE - ADVANCED ANALYSIS EXAMPLES")
    print("=" * 70)
    
    # Initialize analyzer
    api_key = os.getenv("SOLANA_TRACKER_API_KEY")
    if not api_key:
        print("❌ Please set SOLANA_TRACKER_API_KEY environment variable")
        return
    
    try:
        analyzer = SolanaAnalyzer(api_key)
        
        # Example token and wallet (replace with real addresses)
        example_token = "So11111111111111111111111111111111111111112"  # SOL
        example_wallet = "5dAHQsk9EkLLGFeYvzHSU5jwBLAqTgdiJLarwibwRN6D"
        
        # Example 1: Analyze wallet performance on token
        print("\n💰 EXAMPLE 1: Wallet Net SOL Analysis")
        print("-" * 50)
        
        wallet_analysis = analyzer.analyze_wallet_net_sol_on_token(example_wallet, example_token)
        
        if "error" not in wallet_analysis:
            print(f"Wallet: {wallet_analysis['wallet'][:8]}...{wallet_analysis['wallet'][-8:]}")
            print(f"Total trades: {wallet_analysis['total_trades']}")
            print(f"Buy volume: {wallet_analysis['buy_volume_sol']:.4f} SOL")
            print(f"Sell volume: {wallet_analysis['sell_volume_sol']:.4f} SOL")
            print(f"Net position: {wallet_analysis['net_sol']:.4f} SOL")
            print(f"Profitable: {'✅ Yes' if wallet_analysis['is_profitable'] else '❌ No'}")
        else:
            print(f"Analysis failed: {wallet_analysis['error']}")
        
        # Example 2: Find profitable wallets
        print("\n🏆 EXAMPLE 2: Find Profitable Wallets")
        print("-" * 50)
        
        profitable_wallets = analyzer.find_profitable_wallets(example_token, min_trades=3)
        
        if profitable_wallets and "error" not in profitable_wallets[0]:
            print(f"Found {len(profitable_wallets)} profitable wallets:")
            for i, wallet in enumerate(profitable_wallets[:5], 1):
                print(f"{i}. {wallet['wallet'][:8]}...{wallet['wallet'][-8:]} "
                      f"(+{wallet['net_sol']:.4f} SOL, {wallet['total_trades']} trades)")
        else:
            print("No profitable wallets found or analysis failed")
        
        # Example 3: Volume velocity analysis
        print("\n📊 EXAMPLE 3: Volume Velocity Analysis")
        print("-" * 50)
        
        velocity_analysis = analyzer.analyze_token_volume_velocity(example_token, hours=24)
        
        if "error" not in velocity_analysis:
            print(f"Analysis period: {velocity_analysis['analysis_hours']} hours")
            print(f"Data points: {velocity_analysis['data_points']}")
            print(f"Average volume: {velocity_analysis['average_volume']:.2f}")
            print(f"Volume volatility: {velocity_analysis['volume_volatility']:.2f}")
            print(f"Average velocity: {velocity_analysis['average_velocity_percent']:.2f}%")
            print(f"Max velocity: {velocity_analysis['max_velocity_percent']:.2f}%")
        else:
            print(f"Velocity analysis failed: {velocity_analysis['error']}")
        
        # Example 4: Bot detection
        print("\n🤖 EXAMPLE 4: Bot Detection")
        print("-" * 50)
        
        potential_bots = analyzer.detect_potential_bots(example_token, trade_threshold=20)
        
        if potential_bots and "error" not in potential_bots[0]:
            print(f"Found {len(potential_bots)} potential bots:")
            for i, bot in enumerate(potential_bots[:3], 1):
                print(f"{i}. {bot['wallet'][:8]}...{bot['wallet'][-8:]} "
                      f"({bot['trade_count']} trades, {bot['bot_confidence']} confidence)")
        else:
            print("No potential bots detected or analysis failed")
        
        print("\n✅ Advanced analysis examples completed!")
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    main()

