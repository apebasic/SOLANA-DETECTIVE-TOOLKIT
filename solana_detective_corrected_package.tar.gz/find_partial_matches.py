#!/usr/bin/env python3
"""
Find wallets that bought MOST of the specified tokens
Since comprehensive search found 0 wallets that bought ALL, let's find partial matches
"""

import requests
import json
from collections import defaultdict

def get_first_buyers_for_token(token_address, api_key):
    """Get first buyers for a token (faster approach)"""
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    try:
        response = requests.get(f'{base_url}/first-buyers/{token_address}', headers=headers, timeout=30)
        if response.status_code == 200:
            buyers_data = response.json()
            buyers = set()
            for buyer in buyers_data:
                wallet = buyer.get('wallet')
                if wallet:
                    buyers.add(wallet)
            return buyers
        return set()
    except:
        return set()

def find_partial_matches():
    """Find wallets that bought multiple tokens from the list"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    
    # Updated token list based on user's evidence
    tokens = {
        "PFP": "4yyJ3wRrXE2BCiMRB1rNZzGJ8WNtYE6CSnRBQuG5pump",
        "GIRLIES": "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump",
        "BCqpYnXF": "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS": "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump"
    }
    
    print(f"🔍 FINDING PARTIAL MATCHES")
    print("=" * 50)
    print("Looking for wallets that bought multiple tokens from the list")
    print("(Since comprehensive search found 0 that bought ALL)")
    print("=" * 50)
    
    # Get buyers for each token
    token_buyers = {}
    wallet_token_count = defaultdict(set)
    
    for name, token in tokens.items():
        print(f"\n📊 Getting buyers for {name}:")
        print(f"   {token}")
        
        buyers = get_first_buyers_for_token(token, api_key)
        token_buyers[name] = buyers
        
        print(f"   ✅ Found {len(buyers)} buyers")
        
        # Track which tokens each wallet bought
        for wallet in buyers:
            wallet_token_count[wallet].add(name)
    
    # Find wallets that bought multiple tokens
    print(f"\n🎯 PARTIAL MATCH ANALYSIS:")
    print("=" * 40)
    
    # Group wallets by number of tokens bought
    by_token_count = defaultdict(list)
    for wallet, tokens_bought in wallet_token_count.items():
        count = len(tokens_bought)
        by_token_count[count].append((wallet, tokens_bought))
    
    # Show results from highest to lowest
    for count in sorted(by_token_count.keys(), reverse=True):
        wallets = by_token_count[count]
        print(f"\n📋 {len(wallets)} WALLETS BOUGHT {count}/{len(tokens)} TOKENS:")
        
        for i, (wallet, tokens_bought) in enumerate(wallets, 1):
            print(f"\n{i}. {wallet}")
            print(f"   Tokens: {', '.join(sorted(tokens_bought))}")
            
        # If this is 3 or 4 tokens, show copy-paste list
        if count >= 3:
            print(f"\n📝 COPY-PASTE LIST ({count} tokens each):")
            for wallet, _ in wallets:
                print(wallet)

if __name__ == "__main__":
    find_partial_matches()
