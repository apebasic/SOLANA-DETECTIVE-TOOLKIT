#!/usr/bin/env python3
"""
Comprehensive KOL Pattern Analysis
Find wallets that bought before AND after KOL across all tokens
"""

import requests
import json
from datetime import datetime, timedelta
from collections import defaultdict
import time

class ComprehensiveKOLAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key
        self.headers = {'x-api-key': api_key, 'accept': 'application/json'}
        self.base_url = 'https://data.solanatracker.io'
        
    def get_wallet_trades(self, wallet_address):
        """Get wallet trades"""
        url = f'{self.base_url}/wallet/{wallet_address}/trades'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                data = response.json()
                return data.get('trades', [])
            else:
                print(f"❌ Error getting wallet trades: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting wallet trades: {e}")
            return []
    
    def get_first_buyers(self, token_address):
        """Get first buyers for a token"""
        url = f'{self.base_url}/first-buyers/{token_address}'
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Error getting first buyers for {token_address}: {response.text}")
                return []
        except Exception as e:
            print(f"❌ Exception getting first buyers: {e}")
            return []
    
    def find_kol_first_buy_time(self, wallet_trades, token_address):
        """Find when the KOL first bought a specific token"""
        first_buy_time = None
        
        for trade in wallet_trades:
            to_addr = trade.get('to', {}).get('address')
            if to_addr == token_address:
                trade_time = trade.get('time')
                if trade_time and (first_buy_time is None or trade_time < first_buy_time):
                    first_buy_time = trade_time
        
        return first_buy_time
    
    def get_token_trades_around_time(self, token_address, target_time, window_minutes=60):
        """Get all trades for a token around a specific time"""
        # Note: This would require a different API endpoint
        # For now, we'll use first-buyers data and filter by time
        first_buyers = self.get_first_buyers(token_address)
        
        # Filter buyers within time window
        start_time = target_time - (window_minutes * 60 * 1000)  # Convert to milliseconds
        end_time = target_time + (window_minutes * 60 * 1000)
        
        relevant_buyers = []
        for buyer in first_buyers:
            buy_time = buyer.get('first_buy_time')
            if buy_time and start_time <= buy_time <= end_time:
                relevant_buyers.append(buyer)
        
        return relevant_buyers
    
    def analyze_comprehensive_patterns(self, kol_wallet, tokens):
        """Comprehensive analysis of all patterns"""
        print(f"🕵️ COMPREHENSIVE KOL PATTERN ANALYSIS")
        print(f"📍 Target KOL Wallet: {kol_wallet}")
        print(f"🎯 Analyzing {len(tokens)} tokens")
        print("=" * 80)
        
        # Get KOL's trades once
        print(f"📊 Getting KOL's complete transaction history...")
        kol_trades = self.get_wallet_trades(kol_wallet)
        
        if not kol_trades:
            print("❌ Could not get KOL trades")
            return
        
        all_patterns = {
            'before_only': defaultdict(list),  # Wallets that bought only before KOL
            'after_only': defaultdict(list),   # Wallets that bought only after KOL  
            'both_before_after': defaultdict(list),  # Wallets that bought both before AND after
            'kol_buy_times': {}  # KOL's first buy time for each token
        }
        
        # Analyze each token
        for i, token_info in enumerate(tokens, 1):
            if isinstance(token_info, dict):
                token_address = token_info['address']
                token_name = token_info.get('name', f'Token {i}')
            else:
                token_address = token_info
                token_name = f'Token {i}'
            
            print(f"\n🔍 Analyzing {token_name} ({token_address})")
            
            # Find KOL's first buy time
            kol_first_buy = self.find_kol_first_buy_time(kol_trades, token_address)
            
            if not kol_first_buy:
                print(f"  ❌ KOL never bought this token")
                continue
            
            kol_date = datetime.fromtimestamp(kol_first_buy / 1000)
            print(f"  ✅ KOL first bought: {kol_date}")
            all_patterns['kol_buy_times'][token_address] = kol_first_buy
            
            # Get buyers around KOL's buy time (wider window)
            print(f"  📊 Getting buyers around KOL's buy time...")
            buyers_around_time = self.get_token_trades_around_time(token_address, kol_first_buy, 120)  # 2 hour window
            
            if not buyers_around_time:
                print(f"  ❌ No buyers found around KOL's time")
                continue
            
            print(f"  ✅ Found {len(buyers_around_time)} buyers around KOL's time")
            
            # Categorize buyers
            before_buyers = []
            after_buyers = []
            
            for buyer in buyers_around_time:
                buy_time = buyer.get('first_buy_time')
                wallet = buyer.get('wallet')
                
                if buy_time < kol_first_buy:
                    before_buyers.append(buyer)
                    all_patterns['before_only'][wallet].append({
                        'token': token_name,
                        'token_address': token_address,
                        'buy_time': buy_time,
                        'kol_time': kol_first_buy,
                        'advantage_seconds': (kol_first_buy - buy_time) / 1000,
                        'investment': buyer.get('total_invested', 0)
                    })
                elif buy_time > kol_first_buy:
                    after_buyers.append(buyer)
                    all_patterns['after_only'][wallet].append({
                        'token': token_name,
                        'token_address': token_address,
                        'buy_time': buy_time,
                        'kol_time': kol_first_buy,
                        'delay_seconds': (buy_time - kol_first_buy) / 1000,
                        'investment': buyer.get('total_invested', 0)
                    })
            
            print(f"  📈 Before KOL: {len(before_buyers)} wallets")
            print(f"  📉 After KOL: {len(after_buyers)} wallets")
            
            time.sleep(1)  # Be nice to API
        
        # Find wallets that appear in both before and after categories
        print(f"\n🔍 Cross-referencing patterns...")
        
        before_wallets = set(all_patterns['before_only'].keys())
        after_wallets = set(all_patterns['after_only'].keys())
        both_wallets = before_wallets.intersection(after_wallets)
        
        # Move wallets that appear in both to the 'both' category
        for wallet in both_wallets:
            all_patterns['both_before_after'][wallet] = {
                'before_trades': all_patterns['before_only'][wallet],
                'after_trades': all_patterns['after_only'][wallet]
            }
            # Remove from individual categories
            del all_patterns['before_only'][wallet]
            del all_patterns['after_only'][wallet]
        
        # Generate comprehensive report
        self.generate_comprehensive_report(all_patterns)
        
        return all_patterns
    
    def generate_comprehensive_report(self, patterns):
        """Generate detailed report of all patterns"""
        print(f"\n" + "="*80)
        print(f"📊 COMPREHENSIVE PATTERN ANALYSIS RESULTS")
        print(f"="*80)
        
        before_only = patterns['before_only']
        after_only = patterns['after_only'] 
        both_patterns = patterns['both_before_after']
        
        print(f"\n📈 BEFORE-ONLY PATTERNS:")
        print(f"   {len(before_only)} wallets bought only BEFORE KOL")
        
        print(f"\n📉 AFTER-ONLY PATTERNS:")
        print(f"   {len(after_only)} wallets bought only AFTER KOL")
        
        print(f"\n🎯 BOTH BEFORE & AFTER PATTERNS:")
        print(f"   {len(both_patterns)} wallets bought BOTH before AND after KOL")
        
        if both_patterns:
            print(f"\n🚨 MOST SUSPICIOUS: WALLETS WITH BOTH PATTERNS")
            print(f"="*60)
            
            for i, (wallet, data) in enumerate(both_patterns.items(), 1):
                before_trades = data['before_trades']
                after_trades = data['after_trades']
                
                print(f"\n#{i} WALLET: {wallet}")
                print(f"   📊 Before trades: {len(before_trades)} tokens")
                print(f"   📊 After trades: {len(after_trades)} tokens")
                print(f"   💰 Total before investment: ${sum(t['investment'] for t in before_trades):.2f}")
                print(f"   💰 Total after investment: ${sum(t['investment'] for t in after_trades):.2f}")
                
                print(f"   📋 BEFORE trades:")
                for trade in before_trades:
                    date = datetime.fromtimestamp(trade['buy_time'] / 1000)
                    print(f"      {trade['token']}: {date} ({trade['advantage_seconds']:.1f}s before) - ${trade['investment']:.2f}")
                
                print(f"   📋 AFTER trades:")
                for trade in after_trades:
                    date = datetime.fromtimestamp(trade['buy_time'] / 1000)
                    print(f"      {trade['token']}: {date} ({trade['delay_seconds']:.1f}s after) - ${trade['investment']:.2f}")
        
        # Show top before-only wallets
        if before_only:
            print(f"\n📈 TOP BEFORE-ONLY WALLETS (Top 10):")
            print(f"="*50)
            
            # Sort by number of tokens
            sorted_before = sorted(before_only.items(), key=lambda x: len(x[1]), reverse=True)
            
            for i, (wallet, trades) in enumerate(sorted_before[:10], 1):
                total_investment = sum(t['investment'] for t in trades)
                avg_advantage = sum(t['advantage_seconds'] for t in trades) / len(trades)
                
                print(f"\n#{i} {wallet}")
                print(f"   📊 Tokens: {len(trades)}")
                print(f"   💰 Total investment: ${total_investment:.2f}")
                print(f"   ⏰ Avg advantage: {avg_advantage:.1f} seconds")
                print(f"   🎪 Tokens: {', '.join(t['token'] for t in trades)}")
        
        # Show top after-only wallets  
        if after_only:
            print(f"\n📉 TOP AFTER-ONLY WALLETS (Top 10):")
            print(f"="*50)
            
            # Sort by number of tokens
            sorted_after = sorted(after_only.items(), key=lambda x: len(x[1]), reverse=True)
            
            for i, (wallet, trades) in enumerate(sorted_after[:10], 1):
                total_investment = sum(t['investment'] for t in trades)
                avg_delay = sum(t['delay_seconds'] for t in trades) / len(trades)
                
                print(f"\n#{i} {wallet}")
                print(f"   📊 Tokens: {len(trades)}")
                print(f"   💰 Total investment: ${total_investment:.2f}")
                print(f"   ⏰ Avg delay: {avg_delay:.1f} seconds")
                print(f"   🎪 Tokens: {', '.join(t['token'] for t in trades)}")

def main():
    # Configuration
    API_KEY = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    KOL_WALLET = "suqh5sHtr8HyJ7q8scBimULPkPpA557prMG47xCHQfK"
    
    # ALL tokens shared by user
    ALL_TOKENS = [
        # Original 4 tokens
        {"address": "3oQwNvAfZMuPWjVPC12ukY7RPA9JiGwLod6Pr4Lkpump", "name": "Original-1"},
        {"address": "B7N8qDpQcYTa2fHypYdMif3WGxWdahDCYiXZGj6moon", "name": "Original-2"},
        {"address": "7ADAuXkjjDhF2P5H4RJWRk7mndtGTcR62Vfi8V6wpump", "name": "Original-3"},
        {"address": "neA4KGDoctCQ5pUmgQMZszTtXkMmc3mqhp8QCy6moon", "name": "Original-4"},
        
        # Second batch of 6 tokens
        {"address": "GaaFpcCgytjcuMYspBtXNdbR4tAGsA3wDZHb9ZYYQW3k", "name": "Batch2-1"},
        {"address": "EHK46us5yZzSSnQSWhFHsM9kDZDyYAqUCeYJVfuhSEhC", "name": "Batch2-2"},
        {"address": "J4cHpEfamEdXAWEKPMViNVEd7obLdx7YEYkbny69QNYF", "name": "Batch2-3"},
        {"address": "7Qqc728YppYhNWhMRMH7td5j3pTuTJ86wc84ixnEUBq7", "name": "Batch2-4"},
        {"address": "7mXjvwXrkq4E9Tjppe3qUkRWUv6mpfqRXKYTz5Mmpump", "name": "Batch2-5"},
        {"address": "6ykM3BXmFbUvjin4aErsVxfJE7HfSnd5jCPuuqDgpump", "name": "Batch2-6"},
        
        # Third batch of 2 tokens
        {"address": "2zBpPCeCge75KrdscAeaEpdzRpvvbJ7q6XcV9xeKpump", "name": "Batch3-1"},
        {"address": "EKk5jUgWno1Y9sCNKgLeHgUbxXm9jPnVaP9fkEw1uV9m", "name": "Batch3-2"},
        
        # Single token
        {"address": "GZxo6raDU797Kkci1s4BKepwRPW7vhCK5fLstTYdpump", "name": "Single-1"}
    ]
    
    # Run comprehensive analysis
    analyzer = ComprehensiveKOLAnalyzer(API_KEY)
    results = analyzer.analyze_comprehensive_patterns(KOL_WALLET, ALL_TOKENS)
    
    print(f"\n✅ Comprehensive analysis complete!")

if __name__ == "__main__":
    main()

