#!/usr/bin/env python3
"""
Identify SYN and PUMPHOUSE tokens from the original list
"""

import requests
import json

def identify_tokens():
    """Identify which contract addresses correspond to SYN and PUMPHOUSE"""
    
    api_key = "d69a0997-86cb-4a69-8f0b-c3435a11b45b"
    headers = {'x-api-key': api_key, 'accept': 'application/json'}
    base_url = 'https://data.solanatracker.io'
    
    # Original list of 9 contract addresses
    tokens = [
        "qfyhNU2WmMAT1P5kc3isJNBKRpHec3ZLiLWxn38pump",
        "DFVeSFxNohR5CVuReaXSz6rGuJ62LsKhxFpWsDbbjups", 
        "EoD6LKTTpkLjpWaf9Dyemo7C4qEzsxWjPqCRa76apump",
        "8CDe8CVX74r3mEpcr2LsGGrNoGdJFt4uSYWyGfKUpump",
        "4dmQFkCM1WiUhC75UndLkmMtWj78fQJUvfc4xpMLpump",
        "FfoqzbWHM2U3cuTWtJvPBfVSyYHFsaUVyLHriVBHwYN",
        "BCqpYnXFrtJmbeaTYrztdmrdS1i7ru1gqkXn9Hkbonk",
        "9nDhuzqS4upxYCn3rdWvazRNDAwPHWhnBDHxPzUtpump",
        "DWVBoShguKgtLrM2sUyVe8kQZTEzwr9DN8TnbtUnpump"
    ]
    
    print(f"🔍 IDENTIFYING SYN AND PUMPHOUSE TOKENS")
    print("=" * 60)
    
    syn_address = None
    pumphouse_address = None
    
    for i, token in enumerate(tokens, 1):
        print(f"\n📊 {i}/9 Checking token: {token[:8]}...")
        
        try:
            token_url = f'{base_url}/tokens/{token}'
            response = requests.get(token_url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                token_data = response.json()
                
                name = token_data.get('name', '').upper()
                symbol = token_data.get('symbol', '').upper()
                
                print(f"   Name: {token_data.get('name', 'Unknown')}")
                print(f"   Symbol: {token_data.get('symbol', 'Unknown')}")
                
                # Check for SYN
                if 'SYN' in name or 'SYN' in symbol:
                    print(f"   ✅ FOUND SYN TOKEN!")
                    syn_address = token
                
                # Check for PUMPHOUSE
                if 'PUMPHOUSE' in name or 'PUMPHOUSE' in symbol or 'PUMP HOUSE' in name:
                    print(f"   ✅ FOUND PUMPHOUSE TOKEN!")
                    pumphouse_address = token
                    
            else:
                print(f"   ❌ Error: {response.text}")
                
        except Exception as e:
            print(f"   ❌ Exception: {e}")
    
    # Results
    print(f"\n🎯 IDENTIFICATION RESULTS:")
    print("=" * 40)
    
    if syn_address:
        print(f"✅ SYN Token Found:")
        print(f"   {syn_address}")
    else:
        print(f"❌ SYN Token NOT FOUND in the list")
    
    if pumphouse_address:
        print(f"✅ PUMPHOUSE Token Found:")
        print(f"   {pumphouse_address}")
    else:
        print(f"❌ PUMPHOUSE Token NOT FOUND in the list")
    
    return syn_address, pumphouse_address

if __name__ == "__main__":
    identify_tokens()
